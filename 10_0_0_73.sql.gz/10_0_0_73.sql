-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: 10.0.0.73:3306
-- Время создания: Май 21 2021 г., 13:27
-- Версия сервера: 10.1.40-MariaDB
-- Версия PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mediasphera_ojs`
--
CREATE DATABASE IF NOT EXISTS `mediasphera_ojs` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `mediasphera_ojs`;

-- --------------------------------------------------------

--
-- Структура таблицы `access_keys`
--

CREATE TABLE `access_keys` (
  `access_key_id` bigint(20) NOT NULL,
  `context` varchar(40) NOT NULL,
  `key_hash` varchar(40) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `assoc_id` bigint(20) DEFAULT NULL,
  `expiry_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `access_keys`
--

INSERT INTO `access_keys` (`access_key_id`, `context`, `key_hash`, `user_id`, `assoc_id`, `expiry_date`) VALUES
(1, '1', '230b82ed66ccbb6d3831735b87604d80', 2, 1, '2020-06-16 10:22:40');

-- --------------------------------------------------------

--
-- Структура таблицы `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` bigint(20) NOT NULL,
  `assoc_type` smallint(6) DEFAULT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `type_id` bigint(20) DEFAULT NULL,
  `date_expire` date DEFAULT NULL,
  `date_posted` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `announcement_settings`
--

CREATE TABLE `announcement_settings` (
  `announcement_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `announcement_types`
--

CREATE TABLE `announcement_types` (
  `type_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `announcement_type_settings`
--

CREATE TABLE `announcement_type_settings` (
  `type_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `antiplagiat_reports`
--

CREATE TABLE `antiplagiat_reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `score` double(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `antiplagiat_report_blocks`
--

CREATE TABLE `antiplagiat_report_blocks` (
  `id` int(10) UNSIGNED NOT NULL,
  `antiplagiat_report_id` int(11) NOT NULL,
  `offset` int(11) NOT NULL,
  `length` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `antiplagiat_report_services`
--

CREATE TABLE `antiplagiat_report_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `antiplagiat_report_id` int(11) NOT NULL,
  `score_white` double(8,2) DEFAULT NULL,
  `score_black` double(8,2) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `antiplagiat_report_service_sources`
--

CREATE TABLE `antiplagiat_report_service_sources` (
  `id` int(10) UNSIGNED NOT NULL,
  `antiplagiat_report_service_id` int(11) NOT NULL,
  `source_hash` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `score_by_report` double(8,2) DEFAULT NULL,
  `score_by_source` double(8,2) DEFAULT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `antiplagiat_report_statuses`
--

CREATE TABLE `antiplagiat_report_statuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

CREATE TABLE `authors` (
  `author_id` bigint(20) NOT NULL,
  `email` varchar(90) NOT NULL,
  `include_in_browse` tinyint(4) NOT NULL DEFAULT '1',
  `publication_id` bigint(20) NOT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `user_group_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`author_id`, `email`, `include_in_browse`, `publication_id`, `seq`, `user_group_id`) VALUES
(1, 'lukin@mediasphera.ru', 1, 1, 0, 14),
(2, 'natalya-molleker@yandex.ru', 1, 2, 0, 19),
(3, 'natalya-molleker@yandex.ru', 1, 3, 0, 31),
(4, 'natalya-molleker@yandex.ru', 1, 4, 0, 31);

-- --------------------------------------------------------

--
-- Структура таблицы `author_settings`
--

CREATE TABLE `author_settings` (
  `author_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `author_settings`
--

INSERT INTO `author_settings` (`author_id`, `locale`, `setting_name`, `setting_value`) VALUES
(1, 'ru_RU', 'familyName', 'superadmin'),
(1, 'ru_RU', 'givenName', 'superadmin'),
(2, '', 'country', 'RU'),
(2, '', 'orcid', ''),
(2, '', 'url', ''),
(2, 'ru_RU', 'affiliation', ''),
(2, 'ru_RU', 'biography', ''),
(2, 'ru_RU', 'familyName', 'Моллекер'),
(2, 'ru_RU', 'givenName', 'Наталья'),
(3, '', 'country', 'RU'),
(3, '', 'orcid', ''),
(3, '', 'url', ''),
(3, 'en_US', 'affiliation', ''),
(3, 'en_US', 'biography', ''),
(3, 'en_US', 'familyName', ''),
(3, 'en_US', 'givenName', ''),
(3, 'ru_RU', 'affiliation', ''),
(3, 'ru_RU', 'biography', ''),
(3, 'ru_RU', 'familyName', 'Моллекер'),
(3, 'ru_RU', 'givenName', 'Наталья'),
(4, '', 'country', 'RU'),
(4, '', 'orcid', ''),
(4, '', 'url', ''),
(4, 'en_US', 'affiliation', ''),
(4, 'en_US', 'biography', ''),
(4, 'en_US', 'familyName', ''),
(4, 'en_US', 'givenName', ''),
(4, 'ru_RU', 'affiliation', ''),
(4, 'ru_RU', 'biography', ''),
(4, 'ru_RU', 'familyName', 'Моллекер'),
(4, 'ru_RU', 'givenName', 'Наталья');

-- --------------------------------------------------------

--
-- Структура таблицы `auth_sources`
--

CREATE TABLE `auth_sources` (
  `auth_id` bigint(20) NOT NULL,
  `title` varchar(60) NOT NULL,
  `plugin` varchar(32) NOT NULL,
  `auth_default` tinyint(4) NOT NULL DEFAULT '0',
  `settings` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `category_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `seq` bigint(20) DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `image` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `category_settings`
--

CREATE TABLE `category_settings` (
  `category_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `citations`
--

CREATE TABLE `citations` (
  `citation_id` bigint(20) NOT NULL,
  `publication_id` bigint(20) NOT NULL DEFAULT '0',
  `raw_citation` text,
  `seq` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `citations`
--

INSERT INTO `citations` (`citation_id`, `publication_id`, `raw_citation`, `seq`) VALUES
(1, 1, 'Муминова А.И., Плужникова М.С., Рязанцева С.В. «Полипозные риносинуиты» Ташкент. «Медицина» УзССР, 1990, 152 с. [Muminova A.I., Pluzhnikova M.S., Ryazanceva S.V. «Polipoznye rinosinuity» Tashkent. «Medicina» UzSSR, 1990, 152 s. (In Russ.).]', 1),
(2, 1, 'European Position Paper on Rhinosinusitis and Nasal Polyps 2012, стр. 56', 2),
(3, 1, 'Рязанцев С.В. Современные взгляды на терапию полипозных риносинуситов. //Пульмунология и аллергология 2007 IV P. 22-25. [Ryazancev S.V. Sovremennye vzglyady na terapiyu polipoznyh rinosinusitov. //Pul\'munologiya i allergologiya 2007 IV P. 22-25. (In Russ.).]', 3),
(4, 1, 'Ланцов А.А. и др. Эпидемиология полипозных риносинуситов. СПБ., 1999 . [Lancov A.A. i dr. Epidemiologiya polipoznyh rinosinusitov. SPB., 1999 . (In Russ.).]', 4),
(5, 1, 'Пискунов Г.З. Полипозный риносинусит /Г. З. Пискунов – М. : ГЭОТАР-Медиа, 2016 . – 96 с. [Piskunov G.Z. Polipoznyj rinosinusit /G. Z. Piskunov – M. : GEHOTAR-Media, 2016 . – 96 s. (In Russ.).]', 5),
(6, 1, 'Whitney W. Stevens, Anju T. Peters, Lydia Suh, James E. Norton, Robert C. Kern and David B. Conley, et al. A retrospective, cross-sectional study reveals that women with CRSwNP have more severe disease than men. Immunity, Inflammation and Disease 2015; 3(1): 14–22. https://doi.org/10.1002/iid3.46', 6),
(7, 1, 'Helmy AM, EI Ghazzawi IF, Mandour MA, Shehata MA. The effect of estrogen on the nasal respiratory mucosa. An experimental histopatological and histochemical study. J. Laryngology Otology 1975 Dec: 89(12):1229-41 https://doi.org/10.1017/s0022215100081597', 7),
(8, 1, 'Parfyonova E.V. The linkage of 3Н estradiol with citozoles receptors rats’ olfactory tunica. Cytology, 28(5),1986, p. 570-572', 8),
(9, 1, 'Zhao X, Dong Z, Yang Z. An experimental observation on the influence of the different levels of estradiol on the nasal mucosa. Zhonghua Er Bi Yan Hou Ke Za Zhi, 1994 Apr: 29(2):98-100', 9),
(10, 1, 'Zhao X, Dong Z, Zhu J. A preliminary study on the effect of estrogen on nasal mucosal hyperreactivity. Zhonghua Er Bi Yan Hou Ke Za Zhi, 1997 Feb: 32(1):35-37.', 10),
(11, 1, 'D. Zabolotnyi, S. Yaremchuk .The new aspects of polyp fotmation. Recent Advances in Rhinosinusitis and Nasal Polyposis, 2015 Kugler Publications, Amsterdam, The Netherlands; pp. 29-31', 11),
(12, 1, 'Philpott CM, El-Alami M, Murty GE. The effect of the steroid sex hormones on the nasal airway during the normal menstrual cycle. Clin Otolaryngol Allied Sci 2004;29:138–42. https://doi.org/10.1111/j.1365-2273.2004.00801.x', 12),
(13, 1, 'Soylu Özler G, Akbay E, Akkoca AN, Karapınar OS, Şimşek GÖ. Does menopause effect nasal mucociliary clearance time? Eur Arch Otorhinolaryngol 2015;272:363–6 https://doi.org/10.1007/s00405-014-3118-z', 13),
(14, 1, 'Deveci HS, Deveci I, Habesoglu M, et al. Histological evaluation of rat larynx in experimental polycystic ovary syndrome model. Eur Arch Otorhinolaryngol 2012; 269:1945–50. https://doi.org/10.1007/s00405-012-1978-7', 14),
(15, 1, 'Suna Kabil Kucura, Ali Sevena, Beril Yuksela, et al. Alterations in nasal mucociliary activity in polycystic ovary syndrome. European Journal of Obstetrics & Gynecology and Reproductive Biology 207 (2016) 169–172. https://doi.org/10.1016/j.ejogrb.2016.10.023', 15),
(16, 1, 'Заболотный Д.И., Яремчук С.Э. Теоретическое обоснование влияния эстрогенов на рост и развитие полипов носа. Ринологія, №4, 2006', 16),
(17, 1, 'Kato, A., A. Peters, L. Suh, R. Carter, K. E. Harris, and R. Chandra, et al. 2008. Evidence of a role for B cell-activating factor of the TNF family in the pathogenesis of chronic rhinosinusitis with nasal polyps. J. Allergy Clin. Immunol. 121(6): 1385–1392, 1392.e 1381–1382. https://doi.org/10.1016/j.jaci.2008.03.002', 17),
(18, 1, 'Verthelyi,D.I., and S.A.Ahmed,1998. Estrogen in creases the number of plasma cells and enhances their autoantibody production in nonautoimmune C57BL/6 mice. Cell Immunol. 189(2): 125–134. https://doi.org/10.1006/cimm.1998.1372', 18),
(19, 1, 'Donald Dennis, David Robertson, Luke Curtis and Judson Black. Fungal exposure endocrinopathy in sinusitis with growth hormone deficiency: Dennis-Robertson syndrome. Toxicology and Industrial Health. 2009 Oct-Nov;25(9-10):669-80. https://doi.org/10.1177/0748233709348266', 19);

-- --------------------------------------------------------

--
-- Структура таблицы `citation_settings`
--

CREATE TABLE `citation_settings` (
  `citation_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `completed_payments`
--

CREATE TABLE `completed_payments` (
  `completed_payment_id` bigint(20) NOT NULL,
  `timestamp` datetime NOT NULL,
  `payment_type` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `assoc_id` bigint(20) DEFAULT NULL,
  `amount` double NOT NULL,
  `currency_code_alpha` varchar(3) DEFAULT NULL,
  `payment_method_plugin_name` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `controlled_vocabs`
--

CREATE TABLE `controlled_vocabs` (
  `controlled_vocab_id` bigint(20) NOT NULL,
  `symbolic` varchar(64) NOT NULL,
  `assoc_type` bigint(20) NOT NULL DEFAULT '0',
  `assoc_id` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `controlled_vocabs`
--

INSERT INTO `controlled_vocabs` (`controlled_vocab_id`, `symbolic`, `assoc_type`, `assoc_id`) VALUES
(8, 'interest', 0, 0),
(4, 'mods34-genre-marcgt', 0, 0),
(2, 'mods34-name-role-roleTerms-marcrelator', 0, 0),
(1, 'mods34-name-types', 0, 0),
(5, 'mods34-physicalDescription-form-marcform', 0, 0),
(3, 'mods34-typeOfResource', 0, 0),
(7, 'openurl10-book-genres', 0, 0),
(6, 'openurl10-journal-genres', 0, 0),
(19, 'submissionAgency', 1048588, 1),
(32, 'submissionAgency', 1048588, 2),
(77, 'submissionAgency', 1048588, 3),
(2965, 'submissionAgency', 1048588, 4),
(17, 'submissionDiscipline', 1048588, 1),
(30, 'submissionDiscipline', 1048588, 2),
(75, 'submissionDiscipline', 1048588, 3),
(2963, 'submissionDiscipline', 1048588, 4),
(15, 'submissionKeyword', 1048588, 1),
(28, 'submissionKeyword', 1048588, 2),
(73, 'submissionKeyword', 1048588, 3),
(2961, 'submissionKeyword', 1048588, 4),
(18, 'submissionLanguage', 1048588, 1),
(31, 'submissionLanguage', 1048588, 2),
(76, 'submissionLanguage', 1048588, 3),
(2964, 'submissionLanguage', 1048588, 4),
(16, 'submissionSubject', 1048588, 1),
(29, 'submissionSubject', 1048588, 2),
(74, 'submissionSubject', 1048588, 3),
(2962, 'submissionSubject', 1048588, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `controlled_vocab_entries`
--

CREATE TABLE `controlled_vocab_entries` (
  `controlled_vocab_entry_id` bigint(20) NOT NULL,
  `controlled_vocab_id` bigint(20) NOT NULL,
  `seq` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `controlled_vocab_entries`
--

INSERT INTO `controlled_vocab_entries` (`controlled_vocab_entry_id`, `controlled_vocab_id`, `seq`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 1),
(5, 2, 2),
(6, 2, 3),
(7, 2, 4),
(8, 2, 5),
(9, 2, 6),
(10, 2, 7),
(11, 3, 1),
(12, 3, 2),
(13, 3, 3),
(14, 4, 1),
(15, 4, 2),
(16, 4, 3),
(17, 4, 4),
(18, 4, 5),
(19, 4, 6),
(20, 4, 7),
(21, 4, 8),
(22, 4, 9),
(23, 4, 10),
(24, 4, 11),
(25, 4, 12),
(26, 5, 1),
(27, 5, 2),
(28, 6, 1),
(29, 6, 2),
(30, 6, 3),
(31, 6, 4),
(32, 6, 5),
(33, 6, 6),
(34, 6, 7),
(35, 7, 1),
(36, 7, 2),
(37, 7, 3),
(38, 7, 4),
(39, 7, 5),
(40, 7, 6),
(41, 7, 7),
(66, 15, 1),
(67, 15, 2),
(68, 15, 3),
(69, 16, 1),
(70, 17, 1),
(71, 18, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `controlled_vocab_entry_settings`
--

CREATE TABLE `controlled_vocab_entry_settings` (
  `controlled_vocab_entry_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `controlled_vocab_entry_settings`
--

INSERT INTO `controlled_vocab_entry_settings` (`controlled_vocab_entry_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, '', 'name', 'personal', 'string'),
(2, '', 'name', 'corporate', 'string'),
(3, '', 'name', 'conference', 'string'),
(4, '', 'description', 'Author', 'string'),
(4, '', 'name', 'aut', 'string'),
(5, '', 'description', 'Contributor', 'string'),
(5, '', 'name', 'ctb', 'string'),
(6, '', 'description', 'Editor', 'string'),
(6, '', 'name', 'edt', 'string'),
(7, '', 'description', 'Illustrator', 'string'),
(7, '', 'name', 'ill', 'string'),
(8, '', 'description', 'Photographer', 'string'),
(8, '', 'name', 'pht', 'string'),
(9, '', 'description', 'Sponsor', 'string'),
(9, '', 'name', 'spn', 'string'),
(10, '', 'description', 'Translator', 'string'),
(10, '', 'name', 'trl', 'string'),
(11, '', 'name', 'multimedia', 'string'),
(12, '', 'name', 'still image', 'string'),
(13, '', 'name', 'text', 'string'),
(14, '', 'name', 'article', 'string'),
(15, '', 'name', 'book', 'string'),
(16, '', 'name', 'conference publication', 'string'),
(17, '', 'name', 'issue', 'string'),
(18, '', 'name', 'journal', 'string'),
(19, '', 'name', 'newspaper', 'string'),
(20, '', 'name', 'picture', 'string'),
(21, '', 'name', 'review', 'string'),
(22, '', 'name', 'periodical', 'string'),
(23, '', 'name', 'series', 'string'),
(24, '', 'name', 'thesis', 'string'),
(25, '', 'name', 'web site', 'string'),
(26, '', 'name', 'electronic', 'string'),
(27, '', 'name', 'print', 'string'),
(28, '', 'name', 'journal', 'string'),
(29, '', 'name', 'issue', 'string'),
(30, '', 'name', 'article', 'string'),
(31, '', 'name', 'proceeding', 'string'),
(32, '', 'name', 'conference', 'string'),
(33, '', 'name', 'preprint', 'string'),
(34, '', 'name', 'unknown', 'string'),
(35, '', 'name', 'book', 'string'),
(36, '', 'name', 'bookitem', 'string'),
(37, '', 'name', 'proceeding', 'string'),
(38, '', 'name', 'conference', 'string'),
(39, '', 'name', 'report', 'string'),
(40, '', 'name', 'document', 'string'),
(41, '', 'name', 'unknown', 'string'),
(66, 'ru_RU', 'submissionKeyword', 'полипозный риносинусит', 'string'),
(67, 'ru_RU', 'submissionKeyword', 'гендерные особенности', 'string'),
(68, 'ru_RU', 'submissionKeyword', 'эстрадиол', 'string'),
(69, 'ru_RU', 'submissionSubject', 'Ринология', 'string'),
(70, 'ru_RU', 'submissionDiscipline', 'Ринология', 'string'),
(71, 'ru_RU', 'submissionLanguage', 'ru_RU', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `custom_issue_orders`
--

CREATE TABLE `custom_issue_orders` (
  `issue_id` bigint(20) NOT NULL,
  `journal_id` bigint(20) NOT NULL,
  `seq` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `custom_section_orders`
--

CREATE TABLE `custom_section_orders` (
  `issue_id` bigint(20) NOT NULL,
  `section_id` bigint(20) NOT NULL,
  `seq` double NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `data_object_tombstones`
--

CREATE TABLE `data_object_tombstones` (
  `tombstone_id` bigint(20) NOT NULL,
  `data_object_id` bigint(20) NOT NULL,
  `date_deleted` datetime NOT NULL,
  `set_spec` varchar(255) NOT NULL,
  `set_name` varchar(255) NOT NULL,
  `oai_identifier` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `data_object_tombstone_oai_set_objects`
--

CREATE TABLE `data_object_tombstone_oai_set_objects` (
  `object_id` bigint(20) NOT NULL,
  `tombstone_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `data_object_tombstone_settings`
--

CREATE TABLE `data_object_tombstone_settings` (
  `tombstone_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `edit_decisions`
--

CREATE TABLE `edit_decisions` (
  `edit_decision_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `review_round_id` bigint(20) DEFAULT NULL,
  `stage_id` bigint(20) DEFAULT NULL,
  `round` tinyint(4) NOT NULL,
  `editor_id` bigint(20) NOT NULL,
  `decision` tinyint(4) NOT NULL,
  `date_decided` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `edit_decisions`
--

INSERT INTO `edit_decisions` (`edit_decision_id`, `submission_id`, `review_round_id`, `stage_id`, `round`, `editor_id`, `decision`, `date_decided`) VALUES
(1, 1, 0, 1, 0, 2, 8, '2020-04-21 10:22:07'),
(2, 1, 1, 3, 1, 2, 1, '2020-04-21 11:15:48'),
(3, 1, 0, 4, 0, 2, 7, '2020-04-21 11:18:23'),
(4, 2, 0, 1, 0, 4, 8, '2021-01-27 20:55:14'),
(5, 2, 2, 3, 1, 4, 1, '2021-01-27 20:59:56'),
(6, 4, 0, 1, 0, 3, 8, '2021-05-06 14:48:33'),
(7, 3, 0, 1, 0, 3, 8, '2021-05-06 14:52:08'),
(8, 3, 4, 3, 1, 3, 3, '2021-05-06 14:57:21'),
(9, 3, 5, 3, 2, 3, 1, '2021-05-06 15:07:19');

-- --------------------------------------------------------

--
-- Структура таблицы `email_log`
--

CREATE TABLE `email_log` (
  `log_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `sender_id` bigint(20) NOT NULL,
  `date_sent` datetime NOT NULL,
  `event_type` bigint(20) DEFAULT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `recipients` text,
  `cc_recipients` text,
  `bcc_recipients` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `email_log`
--

INSERT INTO `email_log` (`log_id`, `assoc_type`, `assoc_id`, `sender_id`, `date_sent`, `event_type`, `from_address`, `recipients`, `cc_recipients`, `bcc_recipients`, `subject`, `body`) VALUES
(1, 1048585, 1, 2, '2020-04-21 10:21:13', NULL, '\"Владимир Влукин\" <stim.vov@gmail.com>', '\"Владимир Влукин\" <stim.vov@gmail.com>', NULL, NULL, '[РЖБ] Назначение редактором', '<p>Здравствуйте, Владимир Влукин!<br><br>В соответствии с Вашей ролью редактора раздела Вам поручен контроль прохождения через редакционный процесс материала «Участие половых гормонов в формировании назальных полипов. История вопроса» в журнале «Российский журнал боли».<br><br>URL материала: <a href=\'https://ojs-msph.ru/index.php/russian_journal_of_pain/workflow/access/1\' class=\'submissionUrl-style-class\'>https://ojs-msph.ru/index.php/russian_journal_of_pain/workflow/access/1</a><br>Имя пользователя: vllukin<br><br>Заранее благодарю.</p><br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>'),
(2, 1048585, 1, 2, '2020-04-21 10:22:40', NULL, '\"Владимир Влукин\" <stim.vov@gmail.com>', '\"Владимир Влукин\" <stim.vov@gmail.com>', NULL, NULL, '[РЖБ] Запрос на рецензирование статьи', '<p>Здравствуйте, Владимир Влукин!<br><br>Я полагаю, что Вы могли бы быть прекрасным рецензентом для материала «Участие половых гормонов в формировании назальных полипов. История вопроса», который был направлен в журнал «Российский журнал боли». Аннотация статьи приведена ниже, и я надеюсь, что Вы возьметесь выполнить эту важную задачу для нас.<br><br>Пожалуйста, войдите на сайт журнала до 2020-05-19, чтобы подтвердить Ваше согласие на рецензирование или отказаться от рецензирования, а также получить доступ к материалу и оставить свою рецензию и рекомендацию.<br><br>Сама рецензия должна быть предоставлена до 2020-05-19.<br><br>URL материала: <a href=\'https://ojs-msph.ru/index.php/russian_journal_of_pain/reviewer/submission?submissionId=1&reviewId=1&key=2ekEfx\' class=\'submissionReviewUrl-style-class\'>https://ojs-msph.ru/index.php/russian_journal_of_pain/reviewer/submission?submissionId=1&reviewId=1&key=2ekEfx</a><br><br>Заранее благодарю Вас,<br><br>Владимир Влукин<br>stim.vov@gmail.com<br><br>«Участие половых гормонов в формировании назальных полипов. История вопроса»<br><br></p>\r\n<p>Гормоны -&nbsp;<a href=\"https://ru.wikipedia.org/wiki/%D0%91%D0%B8%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F\">биологически</a>&nbsp;активные вещества, оказывающие регулирующее влияние на обмен веществ и&nbsp;<a href=\"https://ru.wikipedia.org/wiki/%D0%A4%D0%B8%D0%B7%D0%B8%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F\">физиологические</a>&nbsp;функции. В конце ХХ века ученые активно изучали влияние гормонов на различные органы и системы, в том числе на слизистую оболочку полости носа. Клиницисты стали замечать, что изменение уровня половых гормонов ведет к таким состояниям, как ринит беременных, заложенность носа в период овуляции. В ходе исследований были найдены рецепторы к эстрадиолу, описаны эффекты со стороны дыхательной системы, вызываемые его избытком и недостатком. Позднее учёные попытались найти связь развития полипозного риносинусита с изменением уровня половых гормонов, в частности эстрадиола, аргументируя это тем, что болезнь имеет гендерные и возрастные особенности. Полипоз, как правило, развивается у людей зрелого возраста и практически не встречается у детей, чаще им страдают мужчины, но наиболее тяжелым формам подвержены женщины. В связи с этим, исследователи предложили возможные патогенетические механизмы влияния гормонального фона на формирование назальных полипов, что отражено в данной статье.</p><br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>'),
(3, 1048585, 1, 2, '2020-04-21 10:24:20', 1073741829, '\"Владимир Влукин\" <stim.vov@gmail.com>', '\"Владимир Влукин\" <stim.vov@gmail.com>', NULL, NULL, '[РЖБ] Согласен дать рецензию', 'Уважаемые редакторы!<br />\n<br />\nЯ готов дать рецензию на материал «Участие половых гормонов в формировании назальных полипов. История вопроса» для журнала «Российский журнал боли». Благодарю Вас, что обратились ко мне; я планирую завершить рецензирование к указанному сроку, 2020-05-19, а возможно и раньше.<br />\n<br />\nВладимир Влукин<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>'),
(4, 1048585, 1, 2, '2020-04-21 10:26:42', NULL, '\"Владимир Влукин\" <stim.vov@gmail.com>', '\"Владимир Влукин\" <stim.vov@gmail.com>', NULL, NULL, '[РЖБ] Подтверждение получения рецензии', '<p>Здравствуйте, Владимир Влукин!<br><br>Благодарю Вас за рецензию на материал «Участие половых гормонов в формировании назальных полипов. История вопроса» для журнала «Российский журнал боли». Мы ценим Ваш вклад в качество работы, которую мы публикуем.</p><br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>'),
(5, 1048585, 1, 2, '2020-04-21 11:16:39', NULL, '\"Владимир Влукин\" <stim.vov@gmail.com>', '\"Владимир Влукин\" <stim.vov@gmail.com>', NULL, NULL, '[РЖБ] Запрос на литературное редактирование', '<p>Здравствуйте, Владимир Влукин!<br><br>Я хотел бы попросить Вас выполнить литературное редактирование материала «Участие половых гормонов в формировании назальных полипов. История вопроса» для журнала «Российский журнал боли», выполнив следующие шаги.<br>1. Щелкните на URL материала ниже.<br>2. Откройте все файлы, доступные в панели «Черновики», и выполните литературное редактирование, добавляя при необходимости Обсуждения литературного редактирования.<br>3. Сохраните отредактированные файлы и загрузите их в панель «Отредактированные».<br>4. Уведомите редактора о том, что все файлы были подготовлены и можно их запускать в производство.<br><br>URL журнала «Российский журнал боли»: <a class=\"contextUrl-style-class\" href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">https://ojs-msph.ru/index.php/russian_journal_of_pain</a><br>URL материала: <a href=\'https://ojs-msph.ru/index.php/russian_journal_of_pain/reviewer/submission/1\' class=\'submissionUrl-style-class\'>https://ojs-msph.ru/index.php/russian_journal_of_pain/reviewer/submission/1</a><br>Имя пользователя: vllukin</p><br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>'),
(6, 1048585, 2, 4, '2021-01-27 20:54:02', NULL, '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', NULL, NULL, '[ПРБ] Подтверждение отправки', 'Здравствуйте, Наталья Моллекер!<br />\n<br />\nБлагодарим Вас за отправку материала «Просто статья» в журнал «Пробный». С помощью онлайн-системы управления журналом, которую мы используем, Вы сможете отслеживать его прохождение через редакционный процесс, заходя на сайт журнала:<br />\n<br />\nURL материала: <a href=\'https://ojs-msph.ru/index.php/prb/authorDashboard/submission/2\' class=\'submissionUrl-style-class\'>https://ojs-msph.ru/index.php/prb/authorDashboard/submission/2</a><br />\nИмя пользователя: admin<br />\n<br />\nЕсли у Вас возникнут какие-то вопросы, пожалуйста, свяжитесь со мной. Спасибо за выбор нашего журнала для публикации Вашей работы.<br />\n<br />\nНаталья Моллекер<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>'),
(7, 1048585, 2, 4, '2021-01-27 20:57:14', 1073741829, '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', NULL, NULL, '[ПРБ] Согласен дать рецензию', 'Уважаемые редакторы!<br />\n<br />\nЯ готов дать рецензию на материал «Просто статья» для журнала «Пробный». Благодарю Вас, что обратились ко мне; я планирую завершить рецензирование к указанному сроку, 24-02-2021, а возможно и раньше.<br />\n<br />\nНаталья Моллекер<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>'),
(8, 1048585, 3, 4, '2021-05-06 14:32:10', NULL, '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', NULL, NULL, '[ПРБ] Подтверждение отправки', 'Здравствуйте, Наталья Моллекер!<br />\n<br />\nБлагодарим Вас за отправку материала «Тестовая статья 1» в журнал «Пробный». С помощью онлайн-системы управления журналом, которую мы используем, Вы сможете отслеживать его прохождение через редакционный процесс, заходя на сайт журнала:<br />\n<br />\nURL материала: <a href=\'https://ojs-msph.ru/index.php/prb/authorDashboard/submission/3\' class=\'submissionUrl-style-class\'>https://ojs-msph.ru/index.php/prb/authorDashboard/submission/3</a><br />\nИмя пользователя: admin<br />\n<br />\nЕсли у Вас возникнут какие-то вопросы, пожалуйста, свяжитесь со мной. Спасибо за выбор нашего журнала для публикации Вашей работы.<br />\n<br />\nНаталья Моллекер<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>'),
(9, 1048585, 4, 4, '2021-05-06 14:42:22', NULL, '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', NULL, NULL, '[ПРБ] Подтверждение отправки', 'Здравствуйте, Наталья Моллекер!<br />\n<br />\nБлагодарим Вас за отправку материала «Проверка» в журнал «Пробный». С помощью онлайн-системы управления журналом, которую мы используем, Вы сможете отслеживать его прохождение через редакционный процесс, заходя на сайт журнала:<br />\n<br />\nURL материала: <a href=\'https://ojs-msph.ru/index.php/prb/authorDashboard/submission/4\' class=\'submissionUrl-style-class\'>https://ojs-msph.ru/index.php/prb/authorDashboard/submission/4</a><br />\nИмя пользователя: admin<br />\n<br />\nЕсли у Вас возникнут какие-то вопросы, пожалуйста, свяжитесь со мной. Спасибо за выбор нашего журнала для публикации Вашей работы.<br />\n<br />\nНаталья Моллекер<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>'),
(10, 1048585, 3, 4, '2021-05-06 14:54:40', 1073741829, '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', '\"Иван Тестов\" <varmoch@mail.ru>', NULL, NULL, '[ПРБ] Согласен дать рецензию', 'Уважаемые редакторы!<br />\n<br />\nЯ готов дать рецензию на материал «Тестовая статья 1» для журнала «Пробный». Благодарю Вас, что обратились ко мне; я планирую завершить рецензирование к указанному сроку, 03-06-2021, а возможно и раньше.<br />\n<br />\nНаталья Моллекер<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>'),
(11, 1048585, 3, 4, '2021-05-06 15:02:14', 1073741829, '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', '\"Иван Тестов\" <varmoch@mail.ru>', NULL, NULL, '[ПРБ] Согласен дать рецензию', 'Уважаемые редакторы!<br />\n<br />\nЯ готов дать рецензию на материал «Тестовая статья 1» для журнала «Пробный». Благодарю Вас, что обратились ко мне; я планирую завершить рецензирование к указанному сроку, 03-06-2021, а возможно и раньше.<br />\n<br />\nНаталья Моллекер<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>'),
(12, 1048585, 4, 4, '2021-05-06 15:11:28', 1073741829, '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', '\"Наталья Моллекер\" <natalya-molleker@yandex.ru>', NULL, NULL, '[ПРБ] Согласен дать рецензию', 'Уважаемые редакторы!<br />\n<br />\nЯ готов дать рецензию на материал «Проверка» для журнала «Пробный». Благодарю Вас, что обратились ко мне; я планирую завершить рецензирование к указанному сроку, 03-06-2021, а возможно и раньше.<br />\n<br />\nНаталья Моллекер<br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>');

-- --------------------------------------------------------

--
-- Структура таблицы `email_log_users`
--

CREATE TABLE `email_log_users` (
  `email_log_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `email_log_users`
--

INSERT INTO `email_log_users` (`email_log_id`, `user_id`) VALUES
(1, 2),
(2, 2),
(3, 2),
(4, 2),
(5, 2),
(6, 4),
(7, 4),
(8, 4),
(9, 4),
(10, 3),
(11, 3),
(12, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `email_templates`
--

CREATE TABLE `email_templates` (
  `email_id` bigint(20) NOT NULL,
  `email_key` varchar(64) NOT NULL,
  `context_id` bigint(20) NOT NULL DEFAULT '0',
  `enabled` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `email_templates_default`
--

CREATE TABLE `email_templates_default` (
  `email_id` bigint(20) NOT NULL,
  `email_key` varchar(64) NOT NULL,
  `can_disable` tinyint(4) NOT NULL DEFAULT '1',
  `can_edit` tinyint(4) NOT NULL DEFAULT '1',
  `from_role_id` bigint(20) DEFAULT NULL,
  `to_role_id` bigint(20) DEFAULT NULL,
  `stage_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `email_templates_default`
--

INSERT INTO `email_templates_default` (`email_id`, `email_key`, `can_disable`, `can_edit`, `from_role_id`, `to_role_id`, `stage_id`) VALUES
(1, 'NOTIFICATION', 0, 1, NULL, NULL, NULL),
(2, 'NOTIFICATION_CENTER_DEFAULT', 0, 1, NULL, NULL, NULL),
(3, 'PASSWORD_RESET_CONFIRM', 0, 1, NULL, NULL, NULL),
(4, 'PASSWORD_RESET', 0, 1, NULL, NULL, NULL),
(5, 'USER_REGISTER', 0, 1, NULL, NULL, NULL),
(6, 'USER_VALIDATE', 0, 1, NULL, NULL, NULL),
(7, 'REVIEWER_REGISTER', 0, 1, NULL, NULL, NULL),
(8, 'PUBLISH_NOTIFY', 0, 1, NULL, NULL, NULL),
(9, 'LOCKSS_EXISTING_ARCHIVE', 0, 1, NULL, NULL, NULL),
(10, 'LOCKSS_NEW_ARCHIVE', 0, 1, NULL, NULL, NULL),
(11, 'SUBMISSION_ACK', 1, 1, NULL, 65536, 1),
(12, 'SUBMISSION_ACK_NOT_USER', 1, 1, NULL, 65536, 1),
(13, 'EDITOR_ASSIGN', 1, 1, 16, 16, 1),
(14, 'REVIEW_CANCEL', 1, 1, 16, 4096, 3),
(15, 'REVIEW_REINSTATE', 1, 1, 16, 4096, 3),
(16, 'REVIEW_REQUEST', 1, 1, 16, 4096, 3),
(17, 'REVIEW_REQUEST_SUBSEQUENT', 1, 1, 16, 4096, 3),
(18, 'REVIEW_REQUEST_ONECLICK', 1, 1, 16, 4096, 3),
(19, 'REVIEW_REQUEST_ONECLICK_SUBSEQUENT', 1, 1, 16, 4096, 3),
(20, 'REVIEW_REQUEST_ATTACHED', 0, 1, 16, 4096, 3),
(21, 'REVIEW_REQUEST_ATTACHED_SUBSEQUENT', 0, 1, 16, 4096, 3),
(22, 'REVIEW_REQUEST_REMIND_AUTO', 0, 1, NULL, 4096, 3),
(23, 'REVIEW_REQUEST_REMIND_AUTO_ONECLICK', 0, 1, NULL, 4096, 3),
(24, 'REVIEW_CONFIRM', 1, 1, 4096, 16, 3),
(25, 'REVIEW_DECLINE', 1, 1, 4096, 16, 3),
(26, 'REVIEW_ACK', 1, 1, 16, 4096, 3),
(27, 'REVIEW_REMIND', 0, 1, 16, 4096, 3),
(28, 'REVIEW_REMIND_AUTO', 0, 1, NULL, 4096, 3),
(29, 'REVIEW_REMIND_ONECLICK', 0, 1, 16, 4096, 3),
(30, 'REVIEW_REMIND_AUTO_ONECLICK', 0, 1, NULL, 4096, 3),
(31, 'EDITOR_DECISION_ACCEPT', 0, 1, 16, 65536, 3),
(32, 'EDITOR_DECISION_SEND_TO_EXTERNAL', 0, 1, 16, 65536, 3),
(33, 'EDITOR_DECISION_SEND_TO_PRODUCTION', 0, 1, 16, 65536, 5),
(34, 'EDITOR_DECISION_REVISIONS', 0, 1, 16, 65536, 3),
(35, 'EDITOR_DECISION_RESUBMIT', 0, 1, 16, 65536, 3),
(36, 'EDITOR_DECISION_DECLINE', 0, 1, 16, 65536, 3),
(37, 'EDITOR_DECISION_INITIAL_DECLINE', 0, 1, 16, 65536, 1),
(38, 'EDITOR_RECOMMENDATION', 0, 1, 16, 16, 3),
(39, 'COPYEDIT_REQUEST', 1, 1, 16, 4097, 4),
(40, 'LAYOUT_REQUEST', 1, 1, 16, 4097, 5),
(41, 'LAYOUT_COMPLETE', 1, 1, 4097, 16, 5),
(42, 'EMAIL_LINK', 0, 1, 1048576, NULL, NULL),
(43, 'SUBSCRIPTION_NOTIFY', 0, 1, NULL, 1048576, NULL),
(44, 'OPEN_ACCESS_NOTIFY', 0, 1, NULL, 1048576, NULL),
(45, 'SUBSCRIPTION_BEFORE_EXPIRY', 0, 1, NULL, 1048576, NULL),
(46, 'SUBSCRIPTION_AFTER_EXPIRY', 0, 1, NULL, 1048576, NULL),
(47, 'SUBSCRIPTION_AFTER_EXPIRY_LAST', 0, 1, NULL, 1048576, NULL),
(48, 'SUBSCRIPTION_PURCHASE_INDL', 0, 1, NULL, 2097152, NULL),
(49, 'SUBSCRIPTION_PURCHASE_INSTL', 0, 1, NULL, 2097152, NULL),
(50, 'SUBSCRIPTION_RENEW_INDL', 0, 1, NULL, 2097152, NULL),
(51, 'SUBSCRIPTION_RENEW_INSTL', 0, 1, NULL, 2097152, NULL),
(52, 'CITATION_EDITOR_AUTHOR_QUERY', 0, 1, NULL, NULL, 4),
(53, 'REVISED_VERSION_NOTIFY', 0, 1, NULL, 16, 3),
(54, 'STATISTICS_REPORT_NOTIFICATION', 0, 1, 16, 17, NULL),
(55, 'ORCID_COLLECT_AUTHOR_ID', 0, 1, NULL, NULL, NULL),
(56, 'ORCID_REQUEST_AUTHOR_AUTHORIZATION', 0, 1, NULL, NULL, NULL),
(57, 'PAYPAL_INVESTIGATE_PAYMENT', 0, 1, NULL, NULL, NULL),
(58, 'MANUAL_PAYMENT_NOTIFICATION', 0, 1, NULL, NULL, NULL),
(59, 'ANNOUNCEMENT', 0, 1, 16, 1048576, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `email_templates_default_data`
--

CREATE TABLE `email_templates_default_data` (
  `email_key` varchar(64) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT 'en_US',
  `subject` varchar(120) NOT NULL,
  `body` text,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `email_templates_default_data`
--

INSERT INTO `email_templates_default_data` (`email_key`, `locale`, `subject`, `body`, `description`) VALUES
('ANNOUNCEMENT', 'ar_IQ', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nقم بزيارة موقعنا للاطلاع على <a href=\"{$url}\">الإعلان بشكله الكامل</a>.', 'هذه الرسالة تُرسل إلى المشتركين في الموقع عند إنشاء إعلان جديد.'),
('ANNOUNCEMENT', 'ca_ES', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisiteu el nostre lloc web per llegir <a href=\"{$url}\">l\'avís complet</a>.', 'Aquest correu electrònic s\'envia quan es crea un avís nou.'),
('ANNOUNCEMENT', 'cs_CZ', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nNavštivte naši webovou stránku, pokud si chcete přečíst <a href=\"{$url}\">plný text</a>.', 'Tento email je posílán, pokud je vytvořeno nové oznámení.'),
('ANNOUNCEMENT', 'da_DK', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nBesøg vores websted  <a href=\"{$url}\">for at læse hele meddelelsen</a>.', 'Denne e-mail sendes, når der oprettes en ny meddelelse.'),
('ANNOUNCEMENT', 'en_US', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisit our website to read the <a href=\"{$url}\">full announcement</a>.', 'This email is sent when a new announcement is created.'),
('ANNOUNCEMENT', 'es_ES', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisite nuestro site para leer el <a href=\"{$url}\">anuncio completo</a>.', 'Se mandará este email tras la creación de un nuevo anuncio.'),
('ANNOUNCEMENT', 'fr_CA', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisiter notre site Web pour consulter <a href=\"{$url}\">l\'annonce complète</a>.', 'Ce courriel est envoyé lorsqu\'une nouvelle annonce est créée.'),
('ANNOUNCEMENT', 'id_ID', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nKunjungi website kami untuk melihat <a href=\"{$url}\">pengumuman selengkapnya</a>.', 'Surel ini dikirim ketika terdapat pengumuman baru.'),
('ANNOUNCEMENT', 'it_IT', '{$titolo}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisita il nostro sito per leggere la  <a href=\"{$url}\">news completa</a>.', 'Questo messaggio è inviato quando viene creata una nuova news.'),
('ANNOUNCEMENT', 'pt_BR', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisite nosso site para ler o <a href=\"{$url}\"> comunicado completo </a>.', 'Este email é enviado quando um novo comunicado é criado.'),
('ANNOUNCEMENT', 'pt_PT', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nVisite o nosso site para ler a <a href=\"{$url}\">notícia completa</a>.', 'Este email é enviado quando uma nova notícia é criada.'),
('ANNOUNCEMENT', 'ru_RU', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nПосетите наш веб-сайт, чтобы прочитать <a href=\"{$url}\">объявление полностью</a>.', 'Это письмо отправляется при создании нового объявления.'),
('ANNOUNCEMENT', 'sl_SI', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nObiščite našo spletno stran, da vidite <a href=\"{$url}\">celotno obvestilo</a>.', 'Email je poslan, ko je objavljeno novo obvestilo.'),
('ANNOUNCEMENT', 'sv_SE', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nBesök vår webbsida för att läsa <a href=\"{$url}\">hela meddelandet</a>.', 'Detta e-post-meddelande skickas när ett nytt publicerat meddelande skapas.'),
('ANNOUNCEMENT', 'tr_TR', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nWeb sitesini ziyaret et ve <a href=\"{$url}\">tüm duyuruyu</a> oku.', 'Bu e-posta, yeni bir duyuru oluşturulduğunda gönderilir.'),
('ANNOUNCEMENT', 'vi_VN', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\nGhé thăm trang web của chúng tôi để đọc <a href=\"{$url}\">thông báo đầy đủ</a>.', 'Email này được gửi khi một thông báo mới được tạo.'),
('ANNOUNCEMENT', 'zh_CN', '{$title}', '<b>{$title}</b><br />\n<br />\n{$summary}<br />\n<br />\n访问我们的网站查看<a href=\"{$url}\">公告全文</a>。.', '此邮件当公告发布时将会自动发送。'),
('CITATION_EDITOR_AUTHOR_QUERY', 'en_US', 'Citation Editing', '{$authorFirstName},<br />\n<br />\nCould you please verify or provide us with the proper citation for the following reference from your article, {$submissionTitle}:<br />\n<br />\n{$rawCitation}<br />\n<br />\nThanks!<br />\n<br />\n{$userFirstName}<br />\nCopy-Editor, {$contextName}<br />\n', 'This email allows copyeditors to request additional information about references from authors.'),
('CITATION_EDITOR_AUTHOR_QUERY', 'ru_RU', 'Редактирование библиографических ссылок', 'Здравствуйте, {$authorFirstName}!<br />\n<br />\nПожалуйста, проверьте или пришлите нам правильно оформленную библиографическую ссылку для следующей ссылки из Вашей статьи «{$submissionTitle}»:<br />\n<br />\n{$rawCitation}<br />\n<br />\nЗаранее благодарю Вас!<br />\n<br />\n{$userFirstName}<br />\nЛитературный редактор журнала «{$contextName}»<br />\n', 'Это письмо позволяет литературным редакторам запрашивать дополнительную информацию о ссылках у авторов.'),
('COPYEDIT_REQUEST', 'en_US', 'Copyediting Request', '{$participantName}:<br />\n<br />\nI would ask that you undertake the copyediting of &quot;{$submissionTitle}&quot; for {$contextName} by following these steps.<br />\n1. Click on the Submission URL below.<br />\n2. Open any files available under Draft Files and do your copyediting, while adding any Copyediting Discussions as needed.<br />\n3. Save copyedited file(s), and upload to Copyedited panel.<br />\n4. Notify the Editor that all files have been prepared, and that the Production process may begin.<br />\n<br />\n{$contextName} URL: {$contextUrl}<br />\nSubmission URL: {$submissionUrl}<br />\nUsername: {$participantUsername}', 'This email is sent by a Section Editor to a submission\'s Copyeditor to request that they begin the copyediting process. It provides information about the submission and how to access it.'),
('COPYEDIT_REQUEST', 'ru_RU', 'Запрос на литературное редактирование', 'Здравствуйте, {$participantName}!<br />\n<br />\nЯ хотел бы попросить Вас выполнить литературное редактирование материала «{$submissionTitle}» для журнала «{$contextName}», выполнив следующие шаги.<br />\n1. Щелкните на URL материала ниже.<br />\n2. Откройте все файлы, доступные в панели «Черновики», и выполните литературное редактирование, добавляя при необходимости Обсуждения литературного редактирования.<br />\n3. Сохраните отредактированные файлы и загрузите их в панель «Отредактированные».<br />\n4. Уведомите редактора о том, что все файлы были подготовлены и можно их запускать в производство.<br />\n<br />\nURL журнала «{$contextName}»: {$contextUrl}<br />\nURL материала: {$submissionUrl}<br />\nИмя пользователя: {$participantUsername}', 'Это письмо редактора раздела, отправляемое литературному редактору материала с запросом начала процесса литературного редактирования. В письме содержится информация о материале и о том, как получить к нему доступ.'),
('EDITOR_ASSIGN', 'en_US', 'Editorial Assignment', '{$editorialContactName}:<br />\n<br />\nThe submission, &quot;{$submissionTitle},&quot; to {$contextName} has been assigned to you to see through the editorial process in your role as Section Editor.<br />\n<br />\nSubmission URL: {$submissionUrl}<br />\nUsername: {$editorUsername}<br />\n<br />\nThank you.', 'This email notifies a Section Editor that the Editor has assigned them the task of overseeing a submission through the editing process. It provides information about the submission and how to access the journal site.'),
('EDITOR_ASSIGN', 'ru_RU', 'Назначение редактором', 'Здравствуйте, {$editorialContactName}!<br />\n<br />\nВ соответствии с Вашей ролью редактора раздела Вам поручен контроль прохождения через редакционный процесс материала «{$submissionTitle}» в журнале «{$contextName}».<br />\n<br />\nURL материала: {$submissionUrl}<br />\nИмя пользователя: {$editorUsername}<br />\n<br />\nЗаранее благодарю.', 'Это письмо уведомляет редактора раздела о том, что редактор поручил ему контроль прохождения материала через редакционный процесс. В письме содержится информация о материале и о том, как войти на сайт журнала.'),
('EDITOR_DECISION_ACCEPT', 'en_US', 'Editor Decision', '{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is to: Accept Submission', 'This email from the Editor or Section Editor to an Author notifies them of a final \"accept submission\" decision regarding their submission.'),
('EDITOR_DECISION_ACCEPT', 'ru_RU', 'Решение редакции', 'Здравствуйте, {$authorName}!<br />\n<br />\nМы приняли решение относительно Вашего материала «{$submissionTitle}», направленного в журнал «{$contextName}».<br />\n<br />\nНаше решение: Принять материал', 'Это письмо редактора или редактора раздела, отправляемое автору, чтобы уведомить его об окончательном решении «Принять материал» относительно присланного материала.'),
('EDITOR_DECISION_DECLINE', 'en_US', 'Editor Decision', '{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is to: Decline Submission', 'This email from the Editor or Section Editor to an Author notifies them of a final \"decline\" decision regarding their submission.'),
('EDITOR_DECISION_DECLINE', 'ru_RU', 'Решение редакции', 'Здравствуйте, {$authorName}!<br />\n<br />\nМы приняли решение относительно Вашего материала «{$submissionTitle}», направленного в журнал «{$contextName}».<br />\n<br />\nНаше решение: Отклонить материал', 'Это письмо редактора или редактора раздела, отправляемое автору, чтобы уведомить его об окончательном решении «Отклонить материал» относительно присланного материала.'),
('EDITOR_DECISION_INITIAL_DECLINE', 'en_US', 'Editor Decision', '\n			{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is to: Decline Submission', 'This email is sent to the author if the editor declines their submission initially, before the review stage'),
('EDITOR_DECISION_INITIAL_DECLINE', 'ru_RU', 'Решение редакции', '\n			Здравствуйте, {$authorName}!<br />\n<br />\nМы приняли решение относительно Вашего материала «{$submissionTitle}», направленного в журнал «{$contextName}».<br />\n<br />\nНаше решение: Отклонить материал', 'Это письмо отправляется автору, если редактор решает отклонить его материал на начальной стадии, до этапа рецензирования'),
('EDITOR_DECISION_RESUBMIT', 'en_US', 'Editor Decision', '{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is to: Resubmit for Review', 'This email from the Editor or Section Editor to an Author notifies them of a final \"resubmit\" decision regarding their submission.'),
('EDITOR_DECISION_RESUBMIT', 'ru_RU', 'Решение редакции', 'Здравствуйте, {$authorName}!<br />\n<br />\nМы приняли решение относительно Вашего материала «{$submissionTitle}», направленного в журнал «{$contextName}».<br />\n<br />\nНаше решение: Отправить на рецензирование повторно', 'Это письмо редактора или редактора раздела, отправляемое автору, чтобы уведомить его об окончательном решении «Отправить на рецензирование повторно» относительно присланного материала.'),
('EDITOR_DECISION_REVISIONS', 'en_US', 'Editor Decision', '{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is: Revisions Required', 'This email from the Editor or Section Editor to an Author notifies them of a final \"revisions required\" decision regarding their submission.'),
('EDITOR_DECISION_REVISIONS', 'ru_RU', 'Решение редакции', 'Здравствуйте, {$authorName}!<br />\n<br />\nМы приняли решение относительно Вашего материала «{$submissionTitle}», направленного в журнал «{$contextName}».<br />\n<br />\nНаше решение: Требуется корректировка', 'Это письмо редактора или редактора раздела, отправляемое автору, чтобы уведомить его об окончательном решении «Требуется корректировка» относительно присланного материала.'),
('EDITOR_DECISION_SEND_TO_EXTERNAL', 'en_US', 'Editor Decision', '{$authorName}:<br />\n<br />\nWe have reached a decision regarding your submission to {$contextName}, &quot;{$submissionTitle}&quot;.<br />\n<br />\nOur decision is to: Send to Review<br />\n<br />\nSubmission URL: {$submissionUrl}', 'This email from the Editor or Section Editor to an Author notifies them that their submission is being sent to an external review.'),
('EDITOR_DECISION_SEND_TO_EXTERNAL', 'ru_RU', 'Решение редакции', 'Здравствуйте, {$authorName}!<br />\n<br />\nМы приняли решение относительно Вашего материала «{$submissionTitle}», направленного в журнал «{$contextName}».<br />\n<br />\nНаше решение: Отправить на рецензирование<br />\n<br />\nURL материала: {$submissionUrl}', 'Это письмо редактора или редактора раздела, отправляемое автору, чтобы уведомить его об отправке материала на внешнее рецензирование.'),
('EDITOR_DECISION_SEND_TO_PRODUCTION', 'en_US', 'Editor Decision', '{$authorName}:<br />\n<br />\nThe editing of your submission, &quot;{$submissionTitle},&quot; is complete.  We are now sending it to production.<br />\n<br />\nSubmission URL: {$submissionUrl}', 'This email from the Editor or Section Editor to an Author notifies them that their submission is being sent to production.'),
('EDITOR_DECISION_SEND_TO_PRODUCTION', 'ru_RU', 'Решение редакции', 'Здравствуйте, {$authorName}!<br />\n<br />\nРедактирование Вашего материала «{$submissionTitle}» завершено. Теперь мы запускаем его в производство.<br />\n<br />\nURL материала: {$submissionUrl}', 'Это письмо редактора или редактора раздела, отправляемое автору, чтобы уведомить его о запуске материала в производство.'),
('EDITOR_RECOMMENDATION', 'en_US', 'Editor Recommendation', '{$editors}:<br />\n<br />\nThe recommendation regarding the submission to {$contextName}, &quot;{$submissionTitle}&quot; is: {$recommendation}', 'This email from the recommending Editor or Section Editor to the decision making Editors or Section Editors notifies them of a final recommendation regarding the submission.'),
('EDITOR_RECOMMENDATION', 'ru_RU', 'Рекомендация редактора', 'Здравствуйте, {$editors}!<br />\n<br />\nПо материалу «{$submissionTitle}», отправленному в «{$contextName}», могу рекомендовать следующее: {$recommendation}', 'Это письмо рекомендующего редактора или редактора раздела редакторам или редакторам раздела, принимающим решение, чтобы уведомить их об итоговой рекомендации относительного присланного материала.'),
('EMAIL_LINK', 'en_US', 'Article of Possible Interest', 'Thought you might be interested in seeing &quot;{$submissionTitle}&quot; by {$authorName} published in Vol {$volume}, No {$number} ({$year}) of {$contextName} at &quot;{$articleUrl}&quot;.', 'This email template provides a registered reader with the opportunity to send information about an article to somebody who may be interested. It is available via the Reading Tools and must be enabled by the Journal Manager in the Reading Tools Administration page.'),
('EMAIL_LINK', 'ru_RU', 'Эта статья будет Вам интересна', 'Полагаем, что Вам будет интересно посмотреть материал «{$submissionTitle}» (авторы: {$authorName}), опубликованную в Томе {$volume}, № {$number} ({$year}) журнала «{$contextName}» по адресу &quot;{$articleUrl}&quot;.', 'Этот шаблон письма позволяет зарегистрированному читателю возможность отправить информацию о статье тому, кому она может быть интересна. Возможность доступна через «Инструменты читателя» и должна быть включена управляющим журнала на странице «Инструменты читателя: Администрирование».'),
('LAYOUT_COMPLETE', 'en_US', 'Galleys Complete', '{$editorialContactName}:<br />\n<br />\nGalleys have now been prepared for the manuscript, &quot;{$submissionTitle},&quot; for {$contextName} and are ready for proofreading.<br />\n<br />\nIf you have any questions, please contact me.<br />\n<br />\n{$participantName}', 'This email from the Layout Editor to the Section Editor notifies them that the layout process has been completed.'),
('LAYOUT_COMPLETE', 'ru_RU', 'Гранки сделаны', 'Здравствуйте, {$editorialContactName}!<br />\n<br />\nГранки для материала «{$submissionTitle}» в журнал «{$contextName}» уже готовы, можно начинать корректуру.<br />\n<br />\nЕсли у Вас есть какие-либо вопросы, пожалуйста, свяжитесь со мной.<br />\n<br />\n{$participantName}', 'Это письмо верстальщика, отправляемое редактору раздела с уведомлением о том, что верстка завершена.'),
('LAYOUT_REQUEST', 'en_US', 'Request Galleys', '{$participantName}:<br />\n<br />\nThe submission &quot;{$submissionTitle}&quot; to {$contextName} now needs galleys laid out by following these steps.<br />\n1. Click on the Submission URL below.<br />\n2. Log into the journal and use the Production Ready files to create the galleys according to the journal\'s standards.<br />\n3. Upload the galleys to the Galley Files section.<br />\n4. Notify the Editor using Production Discussions that the galleys are uploaded and ready.<br />\n<br />\n{$contextName} URL: {$contextUrl}<br />\nSubmission URL: {$submissionUrl}<br />\nUsername: {$participantUsername}<br />\n<br />\nIf you are unable to undertake this work at this time or have any questions, please contact me. Thank you for your contribution to this journal.', 'This email from the Section Editor to the Layout Editor notifies them that they have been assigned the task of performing layout editing on a submission. It provides information about the submission and how to access it.'),
('LAYOUT_REQUEST', 'ru_RU', 'Запрос на верстку', 'Здравствуйте, {$participantName}!<br />\n<br />\nНеобходимо сверстать гранки материала «{$submissionTitle}» для журнала «{$contextName}», выполнив следующие шаги.<br />\n1. Щелкните на URL материала ниже.<br />\n2. Войдите в журнал и используйте файлы из панели «Готовые для производства» для подготовки гранок в в соответствии со стандартами журнала.<br />\n3. Загрузите файлы гранок в панели «Гранки».<br />\n4. Уведомите редактора с помощью Обсуждений производства, что гранки загружены и готовы.<br />\n<br />\nURL журнала «{$contextName}»: {$contextUrl}<br />\nURL материала: {$submissionUrl}<br />\nИмя пользователя: {$participantUsername}<br />\n<br />\nЕсли Вы не можете выполнить эту работу сейчас или у Вас есть какие-либо вопросы, пожалуйста, свяжитесь со мной. Спасибо за Ваш вклад в наш журнал.', 'Это письмо редактора раздела, отправляемое верстальщику с уведомлением о том, что ему поручено выполнить верстку материала. В письме содержится информация о материале и о том, как получить к нему доступ.'),
('LOCKSS_EXISTING_ARCHIVE', 'en_US', 'Archiving Request for {$contextName}', 'Dear [University Librarian]<br />\n<br />\n{$contextName} &amp;lt;{$contextUrl}&amp;gt;, is a journal for which a member of your faculty, [name of member], serves as a [title of position]. The journal is seeking to establish a LOCKSS (Lots of Copies Keep Stuff Safe) compliant archive with this and other university libraries.<br />\n<br />\n[Brief description of journal]<br />\n<br />\nThe URL to the LOCKSS Publisher Manifest for our journal is: {$contextUrl}/gateway/lockss<br />\n<br />\nWe understand that you are already participating in LOCKSS. If we can provide any additional metadata for purposes of registering our journal with your version of LOCKSS, we would be happy to provide it.<br />\n<br />\nThank you,<br />\n{$principalContactSignature}', 'This email requests the keeper of a LOCKSS archive to consider including this journal in their archive. It provides the URL to the journal\'s LOCKSS Publisher Manifest.'),
('LOCKSS_EXISTING_ARCHIVE', 'ru_RU', 'Запрос на архивацию для журнала «{$contextName}»', 'Уважаемый [библиотекарь университета]!<br />\n<br />\n«{$contextName}» &amp;lt;{$contextUrl}&amp;gt; — журнал, в котором сотрудник Вашего университета, [имя сотрудника], занимает должность [название должности]. Наш журнал хотел бы создать LOCKSS(Lots of Copies Keep Stuff Safe)-совместимый архив с библиотеками Вашего и других университетов.<br />\n<br />\n[Краткое описание журнала]<br />\n<br />\nURL манифеста издателя LOCKSS для нашего журнала: {$contextUrl}/gateway/lockss<br />\n<br />\nМы знаем, что Вы уже участвуете в LOCKSS. Если мы можем предоставить любые дополнительные метаданные для регистрации нашего журнала в Вашей версии LOCKSS, мы будем рады это сделать.<br />\n<br />\nС уважением,<br />\n{$principalContactSignature}', 'Это письмо является обращением к владельцу LOCKSS архива с просьбой рассмотреть возможность включения этого журнала в их архив. В письме сообщается адрес (URL) манифеста издателя LOCKSS для этого журнала.'),
('LOCKSS_NEW_ARCHIVE', 'en_US', 'Archiving Request for {$contextName}', 'Dear [University Librarian]<br />\n<br />\n{$contextName} &amp;lt;{$contextUrl}&amp;gt;, is a journal for which a member of your faculty, [name of member] serves as a [title of position]. The journal is seeking to establish a LOCKSS (Lots of Copies Keep Stuff Safe) compliant archive with this and other university libraries.<br />\n<br />\n[Brief description of journal]<br />\n<br />\nThe LOCKSS Program &amp;lt;http://lockss.org/&amp;gt;, an international library/publisher initiative, is a working example of a distributed preservation and archiving repository, additional details are below. The software, which runs on an ordinary personal computer is free; the system is easily brought on-line; very little ongoing maintenance is required.<br />\n<br />\nTo assist in the archiving of our journal, we invite you to become a member of the LOCKSS community, to help collect and preserve titles produced by your faculty and by other scholars worldwide. To do so, please have someone on your staff visit the LOCKSS site for information on how this system operates. I look forward to hearing from you on the feasibility of providing this archiving support for this journal.<br />\n<br />\nThank you,<br />\n{$principalContactSignature}', 'This email encourages the recipient to participate in the LOCKSS initiative and include this journal in the archive. It provides information about the LOCKSS initiative and ways to become involved.'),
('LOCKSS_NEW_ARCHIVE', 'ru_RU', 'Запрос на архивацию для журнала «{$contextName}»', 'Уважаемый [библиотекарь университета]!<br />\n<br />\n«{$contextName}» &amp;lt;{$contextUrl}&amp;gt; — журнал, в котором сотрудник Вашего университета, [имя сотрудника], занимает должность [название должности]. Наш журнал хотел бы создать LOCKSS(Lots of Copies Keep Stuff Safe)-совместимый архив с библиотеками Вашего и других университетов.<br />\n<br />\n[Краткое описание журнала]<br />\n<br />\nПрограмма LOCKSS &amp;lt;http://lockss.org/&amp;gt; — международная инициатива библиотек и издателей, работающий пример распределенного архивного хранилища (подробности об этом ниже). Программное обеспечение, запускаемое на обычном персональном компьютере, является бесплатным; система легко подключается к сети Интернет; практически не требует усилий под поддержанию в рабочем состоянии.<br />\n<br />\nЧтобы помочь в архивации нашего журнала, мы приглашаем Вас стать членом сообщества LOCKSS, чтобы помочь собирать и сохранять статьи, созданные сотрудниками Вашего университета и другими учеными по всему миру. Чтобы сделать это, пожалуйста, поручите кому-то из Вашего персонала зайти на сайт LOCKSS, чтобы узнать информацию о том, как работает эта система. Жду Вашего ответа о возможности предоставить эту архивную поддержку для нашего журнала.<br />\n<br />\nС уважением,<br />\n{$principalContactSignature}', 'Это письмо предлагает получателю принять участие в инициативе LOCKSS и включить этот журнал в архив. В письме содержится информация об инициативе LOCKSS initiative и способах к ней присоединиться.'),
('MANUAL_PAYMENT_NOTIFICATION', 'en_US', 'Manual Payment Notification', 'A manual payment needs to be processed for the journal {$contextName} and the user {$userFullName} (username &quot;{$userName}&quot;).<br />\n<br />\nThe item being paid for is &quot;{$itemName}&quot;.<br />\nThe cost is {$itemCost} ({$itemCurrencyCode}).<br />\n<br />\nThis email was generated by Open Journal Systems\' Manual Payment plugin.', 'This email template is used to notify a journal manager contact that a manual payment was requested.'),
('MANUAL_PAYMENT_NOTIFICATION', 'ru_RU', 'Уведомление о платеже', 'Необходимо вручную обработать платеж для журнала «{$contextName}» и пользователя {$userFullName} (имя пользователя «{$userName}»).<br />\n<br />\nОплата вносится за «{$itemName}».<br />\nСумма {$itemCost} ({$itemCurrencyCode}).<br />\n<br />\nЭто письмо сгенерировано модулем «Ввод оплаты вручную» системы Open Journal Systems.', 'Этот шаблон письма используется для уведомления управляющего журналом о том, что был запрошен ввод оплаты вручную.'),
('NOTIFICATION', 'en_US', 'New notification from {$siteTitle}', 'You have a new notification from {$siteTitle}:<br />\n<br />\n{$notificationContents}<br />\n<br />\nLink: {$url}<br />\n<br />\n{$principalContactSignature}', 'The email is sent to registered users that have selected to have this type of notification emailed to them.'),
('NOTIFICATION', 'ru_RU', 'Новое уведомление с сайта «{$siteTitle}»', 'Вы получили новое уведомление с сайта «{$siteTitle}»:<br />\n<br />\n{$notificationContents}<br />\n<br />\nСсылка: {$url}<br />\n<br />\n{$principalContactSignature}', 'Это письмо отправляется зарегистрированным пользователям, которые указали, что данный тип уведомления отправляется им электронной почтой.'),
('NOTIFICATION_CENTER_DEFAULT', 'en_US', 'A message regarding {$contextName}', 'Please enter your message.', 'The default (blank) message used in the Notification Center Message Listbuilder.'),
('NOTIFICATION_CENTER_DEFAULT', 'ru_RU', 'Сообщение о журнале «{$contextName}»', 'Пожалуйста, введите свое сообщение.', 'Сообщение по умолчанию (пустое) используется в редакторе списка сообщений Центра уведомлений.'),
('OPEN_ACCESS_NOTIFY', 'en_US', 'Issue Now Open Access', 'Readers:<br />\n<br />\n{$contextName} has just made available in an open access format the following issue. We invite you to review the Table of Contents here and then visit our web site ({$contextUrl}) to review articles and items of interest.<br />\n<br />\nThanks for the continuing interest in our work,<br />\n{$editorialContactSignature}', 'This email is sent to registered readers who have requested to receive a notification email when an issue becomes open access.'),
('OPEN_ACCESS_NOTIFY', 'ru_RU', 'Выпуск уже в открытом доступе', 'Уважаемые читатели!<br />\n<br />\nЖурнал «{$contextName}» только что предоставил открытый доступ к следующему выпуску. Мы предлагаем вам ознакомиться здесь с содержанием выпуска, а затем посетить наш веб-сайт ({$contextUrl}), чтобы прочитать статьи и сообщения на интересующие вас темы.<br />\n<br />\nБлагодарю вас за постоянный интерес к нашей работе,<br />\n{$editorialContactSignature}', 'Это письмо отправляется тем зарегистрированным читателям, которые подписались на получение уведомлений на электронную почту о том, что номер появился в открытом доступе.'),
('ORCID_COLLECT_AUTHOR_ID', 'en_US', 'Submission ORCID', 'Dear {$authorName},<br/>\n<br/>\nYou have been listed as an author on a manuscript submission to {$contextName}.<br/>\nTo confirm your authorship, please add your ORCID id to this submission by visiting the link provided below.<br/>\n<br/>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or connect your ORCID iD</a><br/>\n<br/>\n<br>\n<a href=\"{$orcidAboutUrl}\">More information about ORCID at {$contextName}</a><br/>\n<br/>\nIf you have any questions, please contact me.<br/>\n<br/>\n{$principalContactSignature}<br/>\n', 'This email template is used to collect the ORCID id\'s from authors.'),
('ORCID_COLLECT_AUTHOR_ID', 'ru_RU', 'ORCID материала', '{$authorName}!<br/>\n<br/>\nВы были указаны как автор материала, отправленного в «{$contextName}».<br/>\nЧтобы подтвердить свое авторство, пожалуйста, добавьте свой идентификатор ORCID к этому материалу, перейдя по приведенной ниже ссылке.<br/>\n<br/>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Создать или подключить ваш ORCID iD</a><br/>\n<br/>\n<br>\n<a href=\"{$orcidAboutUrl}\">Дополнительная информация об ORCID в «{$contextName}»</a><br/>\n<br/>\nЕсли у Вас есть какие-либо вопросы, пожалуйста, свяжитесь со мной.<br/>\n<br/>\n{$principalContactSignature}<br/>\n', 'Этот шаблон письма используется для сбора идентификаторов ORCID с авторов.'),
('ORCID_REQUEST_AUTHOR_AUTHORIZATION', 'en_US', 'Requesting ORCID record access', 'Dear {$authorName},<br>\n<br>\nYou have been listed as an author on the manuscript submission \"{$submissionTitle}\" to {$contextName}.\n<br>\n<br>\nPlease allow us to add your ORCID id to this submission and also to add the submission to your ORCID profile on publication.<br>\nVisit the link to the official ORCID website, login with your profile and authorize the access by following the instructions.<br>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or Connect your ORCID iD</a><br/>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\">More about ORCID at {$contextName}</a><br/>\n<br>\nIf you have any questions, please contact me.<br>\n<br>\n{$principalContactSignature}<br>\n', 'This email template is used to request ORCID record access from authors.'),
('ORCID_REQUEST_AUTHOR_AUTHORIZATION', 'ru_RU', 'Запрос доступа к записи ORCID', '{$authorName}!<br>\n<br>\nВы были указаны как автор материала «{$submissionTitle}», отправленного в «{$contextName}».\n<br>\n<br>\nПожалуйста, дайте нам возможность добавить ваш ORCID id к этому материалу, а также добавить материал в ваш профиль ORCID после публикации.<br>\nПерейдите по ссылке на официальном вебсайте ORCID, войдите в систему с вашей учетной записью и авторизуйте доступ, следуя инструкциям.<br>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://orcid.org/sites/default/files/images/orcid_16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Создать или подключить ваш ORCID iD</a><br/>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\">Подробнее об ORCID в «{$contextName}»</a><br/>\n<br>\nЕсли у Вас есть какие-либо вопросы, пожалуйста, свяжитесь со мной.<br>\n<br>\n{$principalContactSignature}<br>\n', 'Этот шаблон письма используется для запроса доступа к записи ORCID у авторов.'),
('PASSWORD_RESET', 'en_US', 'Password Reset', 'Your password has been successfully reset for use with the {$siteTitle} web site. Please retain this username and password, as it is necessary for all work with the journal.<br />\n<br />\nYour username: {$username}<br />\nPassword: {$password}<br />\n<br />\n{$principalContactSignature}', 'This email is sent to a registered user when they have successfully reset their password following the process described in the PASSWORD_RESET_CONFIRM email.'),
('PASSWORD_RESET', 'ru_RU', 'Пароль сброшен', 'Ваш пароль на сайте «{$siteTitle}» был успешно сброшен. Пожалуйста, сохраните имя пользователя и пароль, так как они требуются для работы с журналом.<br />\n<br />\nИмя пользователя: {$username}<br />\nПароль: {$password}<br />\n<br />\n{$principalContactSignature}', 'Это письмо отправляется зарегистрированному пользователю, когда он успешно сбросил свой пароль в соответствии с процедурой, описанной в письме PASSWORD_RESET_CONFIRM.'),
('PASSWORD_RESET_CONFIRM', 'en_US', 'Password Reset Confirmation', 'We have received a request to reset your password for the {$siteTitle} web site.<br />\n<br />\nIf you did not make this request, please ignore this email and your password will not be changed. If you wish to reset your password, click on the below URL.<br />\n<br />\nReset my password: {$url}<br />\n<br />\n{$principalContactSignature}', 'This email is sent to a registered user when they indicate that they have forgotten their password or are unable to login. It provides a URL they can follow to reset their password.'),
('PASSWORD_RESET_CONFIRM', 'ru_RU', 'Подтверждение сброса пароля', 'Мы получили запрос на сброс Вашего пароля на сайте «{$siteTitle}».<br />\n<br />\nЕсли Вы не отправляли этот запрос, пожалуйста, проигнорируйте это письмо и Ваш пароль не будет изменен. Если Вы хотите сбросить свой пароль, то щелкните по ссылке ниже.<br />\n<br />\nСбросить мой пароль: {$url}<br />\n<br />\n{$principalContactSignature}', 'Это письмо отправляется зарегистрированному пользователю, когда он сообщает, что забыл пароль или не может войти на сайт. В письме содержится ссылка (URL), перейдя по которой пользователь сможет сбросить свой пароль.'),
('PAYPAL_INVESTIGATE_PAYMENT', 'en_US', 'Unusual PayPal Activity', 'Open Journal Systems has encountered unusual activity relating to PayPal payment support for the journal {$contextName}. This activity may need further investigation or manual intervention.<br />\n                       <br />\nThis email was generated by Open Journal Systems\' PayPal plugin.<br />\n<br />\nFull post information for the request:<br />\n{$postInfo}<br />\n<br />\nAdditional information (if supplied):<br />\n{$additionalInfo}<br />\n<br />\nServer vars:<br />\n{$serverVars}<br />\n', 'This email template is used to notify a journal\'s primary contact that suspicious activity or activity requiring manual intervention was encountered by the PayPal plugin.'),
('PAYPAL_INVESTIGATE_PAYMENT', 'ru_RU', 'Необычная активность PayPal', 'Система Open Journal Systems обнаружила необычную активность, связанную с поддержкой платежей через PayPal для журнала «{$contextName}». Эта активность может требовать дополнительного изучения или вмешательства в ручном режиме.<br />\n                       <br />\nЭто письмо было сгенерировано модулем «Платежи через PayPal» системы Open Journal Systems.<br />\n<br />\nПолная информация для запроса:<br />\n{$postInfo}<br />\n<br />\nДополнительная информация (если есть):<br />\n{$additionalInfo}<br />\n<br />\nПеременные сервера:<br />\n{$serverVars}<br />\n', 'Этот шаблон письма используется для уведомления контактного лица редакции о том, что была зарегистрирована подозрительная активность или активность, требующая вмешательства в ручном режиме, вызванная модулем «Платежи через PayPal».'),
('PUBLISH_NOTIFY', 'en_US', 'New Issue Published', 'Readers:<br />\n<br />\n{$contextName} has just published its latest issue at {$contextUrl}. We invite you to review the Table of Contents here and then visit our web site to review articles and items of interest.<br />\n<br />\nThanks for the continuing interest in our work,<br />\n{$editorialContactSignature}', 'This email is sent to registered readers via the \"Notify Users\" link in the Editor\'s User Home. It notifies readers of a new issue and invites them to visit the journal at a supplied URL.'),
('PUBLISH_NOTIFY', 'ru_RU', 'Опубликован новый выпуск', 'Уважаемые читатели!<br />\n<br />\nЖурнал «{$contextName}» только что опубликовал свой последний выпуск на сайте {$contextUrl}. Мы предлагаем вам ознакомиться здесь с содержанием выпуска, а затем посетить наш веб-сайт, чтобы прочитать статьи и сообщения на интересующие вас темы.<br />\n<br />\nБлагодарю вас за постоянный интерес к нашей работе,<br />\n{$editorialContactSignature}', 'Это письмо отправляется зарегистрированным читателям по ссылке «Уведомить пользователей» на главной странице редактора. Оно сообшает читателям о выходе нового выпуска и приглашает их посетить сайт журнала по указанному адресу (URL).'),
('REVIEWER_REGISTER', 'en_US', 'Registration as Reviewer with {$contextName}', 'In light of your expertise, we have taken the liberty of registering your name in the reviewer database for {$contextName}. This does not entail any form of commitment on your part, but simply enables us to approach you with a submission to possibly review. On being invited to review, you will have an opportunity to see the title and abstract of the paper in question, and you\'ll always be in a position to accept or decline the invitation. You can also ask at any point to have your name removed from this reviewer list.<br />\n<br />\nWe are providing you with a username and password, which is used in all interactions with the journal through its website. You may wish, for example, to update your profile, including your reviewing interests.<br />\n<br />\nUsername: {$username}<br />\nPassword: {$password}<br />\n<br />\nThank you,<br />\n{$principalContactSignature}', 'This email is sent to a newly registered reviewer to welcome them to the system and provide them with a record of their username and password.'),
('REVIEWER_REGISTER', 'ru_RU', 'Регистрация в качестве рецензента в журнале «{$contextName}»', 'Принимая во внимание Ваш опыт, мы взяли на себя смелость зарегистрировать Вас в базе данных потенциальных рецензентов для журнала «{$contextName}». Это не налагает на Вас никаких обязательств, а просто позволяет нам обращаться к Вам при поступлении в наш журнал материалов, рецензентом которых Вы могли бы стать. Получив предложение дать рецензию, Вы сможете увидеть название и аннотацию рукописи в запросе, и у Вас всегда будет возможность принять или отклонить это предложение. Вы также, в любой момент, можете попросить, чтобы мы удалили Ваше имя из этого списка рецензентов.<br />\n<br />\nМы высылаем Вам имя пользователя и пароль, которые используются при любом взаимодействии с нашим журналом через веб-сайт. Например, Вы можете откорректировать свои данные в профиле пользователя, указав интересующую Вас как рецензента тематику.<br />\n<br />\nИмя пользователя: {$username}<br />\nПароль: {$password}<br />\n<br />\nС уважением,<br />\n{$principalContactSignature}', 'Это письмо отправляется вновь зарегистрированному рецензенту, приветствуя его в системе и сообщая ему имя пользователя и пароль для доступа к сайту.'),
('REVIEW_ACK', 'en_US', 'Article Review Acknowledgement', '{$reviewerName}:<br />\n<br />\nThank you for completing the review of the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We appreciate your contribution to the quality of the work that we publish.', 'This email is sent by a Section Editor to confirm receipt of a completed review and thank the reviewer for their contributions.'),
('REVIEW_ACK', 'ru_RU', 'Подтверждение получения рецензии', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nБлагодарю Вас за рецензию на материал «{$submissionTitle}» для журнала «{$contextName}». Мы ценим Ваш вклад в качество работы, которую мы публикуем.', 'Это письмо отправляется редактором раздела в качестве подтверждения получения рецензии на статью и благодарности рецензенту за его вклад.'),
('REVIEW_CANCEL', 'en_US', 'Request for Review Cancelled', '{$reviewerName}:<br />\n<br />\nWe have decided at this point to cancel our request for you to review the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We apologize for any inconvenience this may cause you and hope that we will be able to call on you to assist with this journal\'s review process in the future.<br />\n<br />\nIf you have any questions, please contact me.', 'This email is sent by the Section Editor to a Reviewer who has a submission review in progress to notify them that the review has been cancelled.'),
('REVIEW_CANCEL', 'ru_RU', 'Запрос на рецензирование отменен', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nНа данный момент мы решили отменить наш запрос на рецензирование Вами материала «{$submissionTitle}» для журнала «{$contextName}». Мы приносим свои извинения за причиненное Вам беспокойство и надеемся, что в будущем мы сможем к Вам обратиться за помощью в рецензировании материалов для нашего журнала.<br />\n<br />\nЕсли у Вас есть вопросы, пожалуйста, свяжитесь со мной.', 'Это письмо редактора раздела, отправляемое рецензенту, который начал рецензировать материал, с уведомлением о том, что рецензирование отменено.'),
('REVIEW_CONFIRM', 'en_US', 'Able to Review', 'Editors:<br />\n<br />\nI am able and willing to review the submission, &quot;{$submissionTitle},&quot; for {$contextName}. Thank you for thinking of me, and I plan to have the review completed by its due date, {$reviewDueDate}, if not before.<br />\n<br />\n{$reviewerName}', 'This email is sent by a Reviewer to the Section Editor in response to a review request to notify the Section Editor that the review request has been accepted and will be completed by the specified date.'),
('REVIEW_CONFIRM', 'ru_RU', 'Согласен дать рецензию', 'Уважаемые редакторы!<br />\n<br />\nЯ готов дать рецензию на материал «{$submissionTitle}» для журнала «{$contextName}». Благодарю Вас, что обратились ко мне; я планирую завершить рецензирование к указанному сроку, {$reviewDueDate}, а возможно и раньше.<br />\n<br />\n{$reviewerName}', 'Это письмо рецензента, отправляемое редактору раздела, в ответ на запрос на рецензирование статьи, чтобы уведомить редактора раздела о том, что запрос на рецензирование принят и рецензия будет предоставлена к указанной дате.'),
('REVIEW_DECLINE', 'en_US', 'Unable to Review', 'Editors:<br />\n<br />\nI am afraid that at this time I am unable to review the submission, &quot;{$submissionTitle},&quot; for {$contextName}. Thank you for thinking of me, and another time feel free to call on me.<br />\n<br />\n{$reviewerName}', 'This email is sent by a Reviewer to the Section Editor in response to a review request to notify the Section Editor that the review request has been declined.'),
('REVIEW_DECLINE', 'ru_RU', 'Не могу дать рецензию', 'Уважаемые редакторы!<br />\n<br />\nБоюсь, что в данный момент я не могу дать рецензию на материал «{$submissionTitle}» для журнала «{$contextName}». Благодарю вас, что обратились ко мне, в другой раз также не стесняйтесь, обращайтесь ко мне.<br />\n<br />\n{$reviewerName}', 'Это письмо рецензента, отправляемое редактору раздела, в ответ на запрос на рецензирование статьи, чтобы уведомить редактора раздела о том, что запрос на рецензирование отклонен.'),
('REVIEW_REINSTATE', 'en_US', 'Request for Review Reinstated', '{$reviewerName}:<br />\n<br />\nWe would like to reinstate our request for you to review the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We hope that you will be able to assist with this journal\'s review process.<br />\n<br />\nIf you have any questions, please contact me.', 'This email is sent by the Section Editor to a Reviewer who has a submission review in progress to notify them that a cancelled review has been reinstated.'),
('REVIEW_REINSTATE', 'ru_RU', 'Запрос на возобновление рецензирования', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nМы бы хотели возобновить наш запрос на рецензирование Вами материала «{$submissionTitle}» для журнала «{$contextName}». Мы надеемся, что Вы сможете помочь нам в процессе рецензирования для этого журнала.<br />\n<br />\nЕсли у Вас есть вопросы, пожалуйста, свяжитесь со мной.', 'Это письмо редактора раздела, отправляемое рецензенту, который начал рецензировать материал, с уведомлением о том, что ранее отмененное рецензирование было возобновлено.'),
('REVIEW_REMIND', 'en_US', 'Submission Review Reminder', '{$reviewerName}:<br />\n<br />\nJust a gentle reminder of our request for your review of the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We were hoping to have this review by {$reviewDueDate}, and would be pleased to receive it as soon as you are able to prepare it.<br />\n<br />\nIf you do not have your username and password for the journal\'s web site, you can use this link to reset your password (which will then be emailed to you along with your username). {$passwordResetUrl}<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nPlease confirm your ability to complete this vital contribution to the work of the journal. I look forward to hearing from you.<br />\n<br />\n{$editorialContactSignature}', 'This email is sent by a Section Editor to remind a reviewer that their review is due.'),
('REVIEW_REMIND', 'ru_RU', 'Напоминание о рецензии на материал', 'Здравствуйте, {$reviewerName}:<br />\n<br />\nЭто напоминание о нашем запросе Вашей рецензии на материал «{$submissionTitle}» для журнала «{$contextName}». Мы надеялись получить эту рецензию до {$reviewDueDate} и будем рады, если Вы как можно скорее ее подготовите.<br />\n<br />\nЕсли у Вас нет имени пользователя и пароля для доступа к сайту журнала, Вы можете воспользоваться этой ссылкой для сброса Вашего пароля (он будет направлен Вам вместе с Вашим именем пользователя на электронную почту). {$passwordResetUrl}<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nПожалуйста, подтвердите, что Вы сможете сделать этот важный вклад в работу нашего журнала. Жду вашего ответа.<br />\n<br />\n{$editorialContactSignature}', 'Это письмо отправляется редактором раздела, чтобы напомнить рецензенту о том, что срок предоставления рецензии уже прошел.'),
('REVIEW_REMIND_AUTO', 'en_US', 'Automated Submission Review Reminder', '{$reviewerName}:<br />\n<br />\nJust a gentle reminder of our request for your review of the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We were hoping to have this review by {$reviewDueDate}, and this email has been automatically generated and sent with the passing of that date. We would still be pleased to receive it as soon as you are able to prepare it.<br />\n<br />\nIf you do not have your username and password for the journal\'s web site, you can use this link to reset your password (which will then be emailed to you along with your username). {$passwordResetUrl}<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nPlease confirm your ability to complete this vital contribution to the work of the journal. I look forward to hearing from you.<br />\n<br />\n{$editorialContactSignature}', 'This email is automatically sent when a reviewer\'s due date elapses (see Review Options under Settings > Workflow > Review) and one-click reviewer access is disabled. Scheduled tasks must be enabled and configured (see the site configuration file).'),
('REVIEW_REMIND_AUTO', 'ru_RU', 'Автоматическое напоминание о рецензии на материал', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЭто напоминание о нашем запросе Вашей рецензии на материал «{$submissionTitle}» для журнала «{$contextName}». Мы надеялись получить эту рецензию до {$reviewDueDate}, и это письмо было автоматически сгенерировано и отправлено, так как эта дата уже прошла. Мы будем рады, если Вы как можно скорее ее подготовите.<br />\n<br />\nЕсли у Вас нет имени пользователя и пароля для доступа к сайту журнала, Вы можете воспользоваться этой ссылкой для сброса Вашего пароля (он будет направлен Вам вместе с Вашим именем пользователя на электронную почту). {$passwordResetUrl}<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nПожалуйста, подтвердите, что Вы сможете сделать этот важный вклад в работу нашего журнала. Жду вашего ответа.<br />\n<br />\n{$editorialContactSignature}', 'Это письмо отправляется автоматически, когда дата предоставления рецензии рецензентом прошла (смотрите Параметры рецензирования в Настройки > Рабочий процесс > Рецензирование) и прямой доступ рецензента по ссылке отключен. Запланированные задачи должны быть включены и настроены (смотрите файл конфигурации сайта).'),
('REVIEW_REMIND_AUTO_ONECLICK', 'en_US', 'Automated Submission Review Reminder', '{$reviewerName}:<br />\n<br />\nJust a gentle reminder of our request for your review of the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We were hoping to have this review by {$reviewDueDate}, and this email has been automatically generated and sent with the passing of that date. We would still be pleased to receive it as soon as you are able to prepare it.<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nPlease confirm your ability to complete this vital contribution to the work of the journal. I look forward to hearing from you.<br />\n<br />\n{$editorialContactSignature}', 'This email is automatically sent when a reviewer\'s due date elapses (see Review Options under Settings > Workflow > Review) and one-click reviewer access is enabled. Scheduled tasks must be enabled and configured (see the site configuration file).'),
('REVIEW_REMIND_AUTO_ONECLICK', 'ru_RU', 'Автоматическое напоминание о рецензии на материал', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЭто напоминание о нашем запросе Вашей рецензии на материал «{$submissionTitle}» для журнала «{$contextName}». Мы надеялись получить эту рецензию до {$reviewDueDate}, и это письмо было автоматически сгенерировано и отправлено, так как эта дата уже прошла. Мы будем рады, если Вы как можно скорее ее подготовите.<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nПожалуйста, подтвердите, что Вы сможете сделать этот важный вклад в работу нашего журнала. Жду вашего ответа.<br />\n<br />\n{$editorialContactSignature}', 'Это письмо отправляется автоматически, когда дата предоставления рецензии рецензентом прошла (смотрите Параметры рецензирования в Настройки > Рабочий процесс > Рецензирование) и прямой доступ рецензента по ссылке включен. Запланированные задачи должны быть включены и настроены (смотрите файл конфигурации сайта).');
INSERT INTO `email_templates_default_data` (`email_key`, `locale`, `subject`, `body`, `description`) VALUES
('REVIEW_REMIND_ONECLICK', 'en_US', 'Submission Review Reminder', '{$reviewerName}:<br />\n<br />\nJust a gentle reminder of our request for your review of the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We were hoping to have this review by {$reviewDueDate}, and would be pleased to receive it as soon as you are able to prepare it.<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nPlease confirm your ability to complete this vital contribution to the work of the journal. I look forward to hearing from you.<br />\n<br />\n{$editorialContactSignature}', 'This email is sent by a Section Editor to remind a reviewer that their review is due.'),
('REVIEW_REMIND_ONECLICK', 'ru_RU', 'Напоминание о рецензии на материал', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЭто напоминание о нашем запросе Вашей рецензии на материал «{$submissionTitle}» для журнала «{$contextName}». Мы надеялись получить эту рецензию до {$reviewDueDate} и будем рады, если Вы как можно скорее ее подготовите.<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nПожалуйста, подтвердите, что Вы сможете сделать этот важный вклад в работу нашего журнала. Жду вашего ответа.<br />\n<br />\n{$editorialContactSignature}', 'Это письмо отправляется редактором раздела, чтобы напомнить рецензенту о том, что срок предоставления рецензии уже прошел.'),
('REVIEW_REQUEST', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\n<br />\nI believe that you would serve as an excellent reviewer of the manuscript, &quot;{$submissionTitle},&quot; which has been submitted to {$contextName}. The submission\'s abstract is inserted below, and I hope that you will consider undertaking this important task for us.<br />\n<br />\nPlease log into the journal web site by {$responseDueDate} to indicate whether you will undertake the review or not, as well as to access the submission and to record your review and recommendation. The web site is {$contextUrl}<br />\n<br />\nThe review itself is due {$reviewDueDate}.<br />\n<br />\nIf you do not have your username and password for the journal\'s web site, you can use this link to reset your password (which will then be emailed to you along with your username). {$passwordResetUrl}<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n&quot;{$submissionTitle}&quot;<br />\n<br />\n{$submissionAbstract}', 'This email from the Section Editor to a Reviewer requests that the reviewer accept or decline the task of reviewing a submission. It provides information about the submission such as the title and abstract, a review due date, and how to access the submission itself. This message is used when the Standard Review Process is selected in Management > Settings > Workflow > Review. (Otherwise see REVIEW_REQUEST_ATTACHED.)'),
('REVIEW_REQUEST', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЯ полагаю, что Вы могли бы быть прекрасным рецензентом для материала «{$submissionTitle}», который был направлен в журнал «{$contextName}». Аннотация статьи приведена ниже, и я надеюсь, что Вы возьметесь выполнить эту важную задачу для нас.<br />\n<br />\nПожалуйста, войдите на сайт журнала до {$responseDueDate}, чтобы подтвердить Ваше согласие на рецензирование или отказаться от рецензирования, а также получить доступ к материалу и оставить свою рецензию и рекомендацию. Адрес сайта — {$contextUrl}<br />\n<br />\nСама рецензия должна быть предоставлена до {$reviewDueDate}.<br />\n<br />\nЕсли у Вас нет имени пользователя и пароля для доступа к сайту журнала, Вы можете воспользоваться этой ссылкой для сброса Вашего пароля (он будет направлен Вам вместе с Вашим именем пользователя на электронную почту). {$passwordResetUrl}<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n«{$submissionTitle}»<br />\n<br />\n{$submissionAbstract}', 'Это письмо редактора раздела, отправляемое рецензенту, с запросом согласия или отказа от выполнения рецензирования материала. В письме приводится информация о материале, такая как название и аннотация, срок выполнения рецензии и как получить доступ к самому материалу. Это сообщение используется, если выбран стандартный процесс рецензирования в Управление > Настройки > Рабочий процесс > Рецензирование. (В ином случае, смотрите REVIEW_REQUEST_ATTACHED.)'),
('REVIEW_REQUEST_ATTACHED', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\n<br />\nI believe that you would serve as an excellent reviewer of the manuscript, &quot;{$submissionTitle},&quot; and I am asking that you consider undertaking this important task for us. The Review Guidelines for this journal are appended below, and the submission is attached to this email. Your review of the submission, along with your recommendation, should be emailed to me by {$reviewDueDate}.<br />\n<br />\nPlease indicate in a return email by {$responseDueDate} whether you are able and willing to do the review.<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n<br />\nReview Guidelines<br />\n<br />\n{$reviewGuidelines}<br />\n', 'This email is sent by the Section Editor to a Reviewer to request that they accept or decline the task of reviewing a submission. It includes the submission as an attachment. This message is used when the Email-Attachment Review Process is selected in Management > Settings > Workflow > Review. (Otherwise see REVIEW_REQUEST.)'),
('REVIEW_REQUEST_ATTACHED', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЯ полагаю, что Вы могли бы быть прекрасным рецензентом для материала «{$submissionTitle}» и прошу Вас взяться выполнить эту важную задачу для нас. Руководство для рецензентов этого журнала добавлено ниже, материал для рецензирования приложен к этому письму. Ваша рецензия на материал, вместе с рекомендацией, должны быть отправлены мне электронной почтой до {$reviewDueDate}.<br />\n<br />\nПожалуйста, сообщите в ответном письме до {$responseDueDate} сможете ли Вы взяться за рецензирование.<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n<br />\nРуководство для рецензентов<br />\n<br />\n{$reviewGuidelines}<br />\n', 'Это письмо редактора раздела, отправляемое рецензенту, с запросом согласия или отказа от выполнения рецензирования материала. К письму приложен сам материал для рецензирования. Это сообщение используется, если выбран процесс рецензирования через электронную почту в Управление > Настройки > Рабочий процесс > Рецензирование. (В ином случае, смотрите REVIEW_REQUEST.)'),
('REVIEW_REQUEST_ATTACHED_SUBSEQUENT', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\n<br />\nThis regards the manuscript &quot;{$submissionTitle},&quot; which is under consideration by {$contextName}.<br />\n<br />\nFollowing the review of the previous version of the manuscript, the authors have now submitted a revised version of their paper. We would appreciate it if you could help evaluate it.<br />\n<br />\nThe Review Guidelines for this journal are appended below, and the submission is attached to this email. Your review of the submission, along with your recommendation, should be emailed to me by {$reviewDueDate}.<br />\n<br />\nPlease indicate in a return email by {$responseDueDate} whether you are able and willing to do the review.<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n<br />\nReview Guidelines<br />\n<br />\n{$reviewGuidelines}<br />\n', 'This email is sent by the Section Editor to a Reviewer to request that they accept or decline the task of reviewing a submission for a second or greater round of review. It includes the submission as an attachment. This message is used when the Email-Attachment Review Process is selected in Management > Settings > Workflow > Review. (Otherwise see REVIEW_REQUEST_SUBSEQUENT.)'),
('REVIEW_REQUEST_ATTACHED_SUBSEQUENT', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЭто письмо касается материала «{$submissionTitle}», который рассматривается журналом «{$contextName}».<br />\n<br />\nПо результатам рецензирования предыдущей версии материала авторы прислали откорректированную версию их статьи. Мы были бы рады, если бы Вы помогли оценить ее.<br />\n<br />\nРуководство для рецензентов этого журнала добавлено ниже, материал для рецензирования приложен к этому письму. Ваша рецензия на материал, вместе с рекомендацией, должны быть отправлены мне электронной почтой до {$reviewDueDate}.<br />\n<br />\nПожалуйста, сообщите в ответном письме до {$responseDueDate} сможете ли Вы взяться за рецензирование.<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n<br />\nРуководство для рецензентов<br />\n<br />\n{$reviewGuidelines}<br />\n', 'Это письмо редактора раздела, отправляемое рецензенту, с запросом согласия или отказа от выполнения рецензирования материала во втором или последующих раундах рецензирования. К письму приложен сам материал для рецензирования. Это сообщение используется, если выбран процесс рецензирования через электронную почту в Управление > Настройки > Рабочий процесс > Рецензирование. (В ином случае, смотрите REVIEW_REQUEST_SUBSEQUENT.)'),
('REVIEW_REQUEST_ONECLICK', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\n<br />\nI believe that you would serve as an excellent reviewer of the manuscript, &quot;{$submissionTitle},&quot; which has been submitted to {$contextName}. The submission\'s abstract is inserted below, and I hope that you will consider undertaking this important task for us.<br />\n<br />\nPlease log into the journal web site by {$responseDueDate} to indicate whether you will undertake the review or not, as well as to access the submission and to record your review and recommendation.<br />\n<br />\nThe review itself is due {$reviewDueDate}.<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n&quot;{$submissionTitle}&quot;<br />\n<br />\n{$submissionAbstract}', 'This email from the Section Editor to a Reviewer requests that the reviewer accept or decline the task of reviewing a submission. It provides information about the submission such as the title and abstract, a review due date, and how to access the submission itself. This message is used when the Standard Review Process is selected in Management > Settings > Workflow > Review, and one-click reviewer access is enabled.'),
('REVIEW_REQUEST_ONECLICK', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЯ полагаю, что Вы могли бы быть прекрасным рецензентом для материала «{$submissionTitle}», который был направлен в журнал «{$contextName}». Аннотация статьи приведена ниже, и я надеюсь, что Вы возьметесь выполнить эту важную задачу для нас.<br />\n<br />\nПожалуйста, войдите на сайт журнала до {$responseDueDate}, чтобы подтвердить Ваше согласие на рецензирование или отказаться от рецензирования, а также получить доступ к материалу и оставить свою рецензию и рекомендацию.<br />\n<br />\nСама рецензия должна быть предоставлена до {$reviewDueDate}.<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n«{$submissionTitle}»<br />\n<br />\n{$submissionAbstract}', 'Это письмо редактора раздела, отправляемое рецензенту, с запросом согласия или отказа от выполнения рецензирования материала. В письме приводится информация о материале, такая как название и аннотация, срок выполнения рецензии и как получить доступ к самому материалу. Это сообщение используется, если выбран стандартный процесс рецензирования в Управление > Настройки > Рабочий процесс > Рецензирование и включен прямой доступ рецензента по ссылке.'),
('REVIEW_REQUEST_ONECLICK_SUBSEQUENT', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\n<br />\nThis regards the manuscript &quot;{$submissionTitle},&quot; which is under consideration by {$contextName}.<br />\n<br />\nFollowing the review of the previous version of the manuscript, the authors have now submitted a revised version of their paper. We would appreciate it if you could help evaluate it.<br />\n<br />\nPlease log into the journal web site by {$responseDueDate} to indicate whether you will undertake the review or not, as well as to access the submission and to record your review and recommendation.<br />\n<br />\nThe review itself is due {$reviewDueDate}.<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n&quot;{$submissionTitle}&quot;<br />\n<br />\n{$submissionAbstract}', 'This email from the Section Editor to a Reviewer requests that the reviewer accept or decline the task of reviewing a submission for a second or greater round of review. It provides information about the submission such as the title and abstract, a review due date, and how to access the submission itself. This message is used when the Standard Review Process is selected in Management > Settings > Workflow > Review, and one-click reviewer access is enabled.'),
('REVIEW_REQUEST_ONECLICK_SUBSEQUENT', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЭто письмо касается материала «{$submissionTitle}», который рассматривается журналом «{$contextName}».<br />\n<br />\nПо результатам рецензирования предыдущей версии материала авторы прислали откорректированную версию их статьи. Мы были бы рады, если бы Вы помогли оценить ее.<br />\n<br />\nПожалуйста, войдите на сайт журнала до {$responseDueDate}, чтобы подтвердить Ваше согласие на рецензирование или отказаться от рецензирования, а также получить доступ к материалу и оставить свою рецензию и рекомендацию.<br />\n<br />\nСама рецензия должна быть предоставлена до {$reviewDueDate}.<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n«{$submissionTitle}»<br />\n<br />\n{$submissionAbstract}', 'Это письмо редактора раздела, отправляемое рецензенту, с запросом согласия или отказа от выполнения рецензирования материала во втором или последующих раундах рецензирования. В письме приводится информация о материале, такая как название и аннотация, срок выполнения рецензии и как получить доступ к самому материалу. Это сообщение используется, если выбран стандартный процесс рецензирования в Управление > Настройки > Рабочий процесс > Рецензирование и включен прямой доступ рецензента по ссылке.'),
('REVIEW_REQUEST_REMIND_AUTO', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\nJust a gentle reminder of our request for your review of the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We were hoping to have your response by {$responseDueDate}, and this email has been automatically generated and sent with the passing of that date.\n<br />\nI believe that you would serve as an excellent reviewer of the manuscript. The submission\'s abstract is inserted below, and I hope that you will consider undertaking this important task for us.<br />\n<br />\nPlease log into the journal web site to indicate whether you will undertake the review or not, as well as to access the submission and to record your review and recommendation. The web site is {$contextUrl}<br />\n<br />\nThe review itself is due {$reviewDueDate}.<br />\n<br />\nIf you do not have your username and password for the journal\'s web site, you can use this link to reset your password (which will then be emailed to you along with your username). {$passwordResetUrl}<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n&quot;{$submissionTitle}&quot;<br />\n<br />\n{$submissionAbstract}', 'This email is automatically sent when a reviewer\'s confirmation due date elapses (see Review Options under Settings > Workflow > Review) and one-click reviewer access is disabled. Scheduled tasks must be enabled and configured (see the site configuration file).'),
('REVIEW_REQUEST_REMIND_AUTO', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\nЭто напоминание о нашем запросе Вашей рецензии на материал «{$submissionTitle}» для журнала «{$contextName}». Мы ожидали получить Ваш ответ до {$responseDueDate}, и это письмо было автоматически сгенерировано и отправлено, так как эта дата уже прошла.\n<br />\nЯ полагаю, что Вы могли бы быть прекрасным рецензентом для материала. Аннотация статьи приведена ниже, и я надеюсь, что Вы возьметесь выполнить эту важную задачу для нас.<br />\n<br />\nПожалуйста, войдите на сайт журнала, чтобы подтвердить Ваше согласие на рецензирование или отказаться от рецензирования, а также получить доступ к материалу и оставить свою рецензию и рекомендацию. Адрес сайта — {$contextUrl}<br />\n<br />\nСама рецензия должна быть предоставлена до {$reviewDueDate}.<br />\n<br />\nЕсли у Вас нет имени пользователя и пароля для доступа к сайту журнала, Вы можете воспользоваться этой ссылкой для сброса Вашего пароля (он будет направлен Вам вместе с Вашим именем пользователя на электронную почту). {$passwordResetUrl}<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n«{$submissionTitle}»<br />\n<br />\n{$submissionAbstract}', 'Это письмо отправляется автоматически, когда дата подтверждения рецензентом участия в рецензировании прошла (смотрите Параметры рецензирования в Настройки > Рабочий процесс > Рецензирование) и прямой доступ рецензента по ссылке отключен. Запланированные задачи должны быть включены и настроены (смотрите файл конфигурации сайта).'),
('REVIEW_REQUEST_REMIND_AUTO_ONECLICK', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\nJust a gentle reminder of our request for your review of the submission, &quot;{$submissionTitle},&quot; for {$contextName}. We were hoping to have your response by {$responseDueDate}, and this email has been automatically generated and sent with the passing of that date.\n<br />\nI believe that you would serve as an excellent reviewer of the manuscript. The submission\'s abstract is inserted below, and I hope that you will consider undertaking this important task for us.<br />\n<br />\nPlease log into the journal web site to indicate whether you will undertake the review or not, as well as to access the submission and to record your review and recommendation.<br />\n<br />\nThe review itself is due {$reviewDueDate}.<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n&quot;{$submissionTitle}&quot;<br />\n<br />\n{$submissionAbstract}', 'This email is automatically sent when a reviewer\'s confirmation due date elapses (see Review Options under Settings > Workflow > Review) and one-click reviewer access is enabled. Scheduled tasks must be enabled and configured (see the site configuration file).'),
('REVIEW_REQUEST_REMIND_AUTO_ONECLICK', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\nЭто напоминание о нашем запросе Вашей рецензии на материал «{$submissionTitle}» для журнала «{$contextName}». Мы ожидали получить Ваш ответ до {$responseDueDate}, и это письмо было автоматически сгенерировано и отправлено, так как эта дата уже прошла.\n<br />\nЯ полагаю, что Вы могли бы быть прекрасным рецензентом для материала. Аннотация статьи приведена ниже, и я надеюсь, что Вы возьметесь выполнить эту важную задачу для нас.<br />\n<br />\nПожалуйста, войдите на сайт журнала, чтобы подтвердить Ваше согласие на рецензирование или отказаться от рецензирования, а также получить доступ к материалу и оставить свою рецензию и рекомендацию.<br />\n<br />\nСама рецензия должна быть предоставлена до {$reviewDueDate}.<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n«{$submissionTitle}»<br />\n<br />\n{$submissionAbstract}', 'Это письмо отправляется автоматически, когда дата подтверждения рецензентом участия в рецензировании прошла (смотрите Параметры рецензирования в Настройки > Рабочий процесс > Рецензирование) и прямой доступ рецензента по ссылке включен. Запланированные задачи должны быть включены и настроены (смотрите файл конфигурации сайта).'),
('REVIEW_REQUEST_SUBSEQUENT', 'en_US', 'Article Review Request', '{$reviewerName}:<br />\n<br />\nThis regards the manuscript &quot;{$submissionTitle},&quot; which is under consideration by {$contextName}.<br />\n<br />\nFollowing the review of the previous version of the manuscript, the authors have now submitted a revised version of their paper. We would appreciate it if you could help evaluate it.<br />\n<br />\nPlease log into the journal web site by {$responseDueDate} to indicate whether you will undertake the review or not, as well as to access the submission and to record your review and recommendation. The web site is {$contextUrl}<br />\n<br />\nThe review itself is due {$reviewDueDate}.<br />\n<br />\nIf you do not have your username and password for the journal\'s web site, you can use this link to reset your password (which will then be emailed to you along with your username). {$passwordResetUrl}<br />\n<br />\nSubmission URL: {$submissionReviewUrl}<br />\n<br />\nThank you for considering this request.<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n&quot;{$submissionTitle}&quot;<br />\n<br />\n{$submissionAbstract}', 'This email from the Section Editor to a Reviewer requests that the reviewer accept or decline the task of reviewing a submission for a second or greater round of review. It provides information about the submission such as the title and abstract, a review due date, and how to access the submission itself. This message is used when the Standard Review Process is selected in Management > Settings > Workflow > Review. (Otherwise see REVIEW_REQUEST_ATTACHED_SUBSEQUENT.)'),
('REVIEW_REQUEST_SUBSEQUENT', 'ru_RU', 'Запрос на рецензирование статьи', 'Здравствуйте, {$reviewerName}!<br />\n<br />\nЭто письмо касается материала «{$submissionTitle}», который рассматривается журналом «{$contextName}».<br />\n<br />\nПо результатам рецензирования предыдущей версии материала авторы прислали откорректированную версию их статьи. Мы были бы рады, если бы Вы помогли оценить ее.<br />\n<br />\nПожалуйста, войдите на сайт журнала до {$responseDueDate}, чтобы подтвердить Ваше согласие на рецензирование или отказаться от рецензирования, а также получить доступ к материалу и оставить свою рецензию и рекомендацию. Адрес сайта — {$contextUrl}<br />\n<br />\nСама рецензия должна быть предоставлена до {$reviewDueDate}.<br />\n<br />\nЕсли у Вас нет имени пользователя и пароля для доступа к сайту журнала, Вы можете воспользоваться этой ссылкой для сброса Вашего пароля (он будет направлен Вам вместе с Вашим именем пользователя на электронную почту). {$passwordResetUrl}<br />\n<br />\nURL материала: {$submissionReviewUrl}<br />\n<br />\nЗаранее благодарю Вас,<br />\n<br />\n{$editorialContactSignature}<br />\n<br />\n«{$submissionTitle}»<br />\n<br />\n{$submissionAbstract}', 'Это письмо редактора раздела, отправляемое рецензенту, с запросом согласия или отказа от выполнения рецензирования материала во втором или последующих раундах рецензирования. В письме приводится информация о материале, такая как название и аннотация, срок выполнения рецензии и как получить доступ к самому материалу. Это сообщение используется, если выбран стандартный процесс рецензирования в Управление > Настройки > Рабочий процесс > Рецензирование. (В ином случае, смотрите RREVIEW_REQUEST_ATTACHED_SUBSEQUENT.)'),
('REVISED_VERSION_NOTIFY', 'en_US', 'Revised Version Uploaded', 'Editors:<br />\n<br />\nA revised version of &quot;{$submissionTitle}&quot; has been uploaded by the author {$authorName}.<br />\n<br />\nSubmission URL: {$submissionUrl}<br />\n<br />\n{$editorialContactSignature}', 'This email is automatically sent to the assigned editor when author uploads a revised version of an article.'),
('REVISED_VERSION_NOTIFY', 'ru_RU', 'Загружена исправленная версия', 'Уважаемые редакторы!<br />\n<br />\nИсправленная версия материала «{$submissionTitle}» была загружена на сайт (автор — {$authorName}).<br />\n<br />\nURL материала: {$submissionUrl}<br />\n<br />\n{$editorialContactSignature}', 'Это письмо автоматически отправляется назначенному редактору, когда автор загружает исправленную версию статьи.'),
('STATISTICS_REPORT_NOTIFICATION', 'en_US', 'Editorial activity for {$month}, {$year}', '\n{$name}, <br />\n<br />\nYour journal health report for {$month}, {$year} is now available. Your key stats for this month are below.<br />\n<ul>\n	<li>New submissions this month: {$newSubmissions}</li>\n	<li>Declined submissions this month: {$declinedSubmissions}</li>\n	<li>Accepted submissions this month: {$acceptedSubmissions}</li>\n	<li>Total submissions in the system: {$totalSubmissions}</li>\n</ul>\nLogin to the journal to view more detailed <a href=\"{$editorialStatsLink}\">editorial trends</a> and <a href=\"{$publicationStatsLink}\">published article stats</a>. A full copy of this month\'s editorial trends is attached.<br />\n<br />\nSincerely,<br />\n{$principalContactSignature}', 'This email is automatically sent monthly to editors and journal managers to provide them a system health overview.'),
('STATISTICS_REPORT_NOTIFICATION', 'ru_RU', 'Активность журнала за {$month} {$year} года', '\nЗдравствуйте, {$name}! <br />\n<br />\nОтчёт об активности журнала за {$month} {$year} года уже доступен. Ключевые статистические параметры этого месяца приведены ниже.<br />\n<ul>\n	<li>Новых материалов за месяц: {$newSubmissions}</li>\n	<li>Отклонено материалов за месяц: {$declinedSubmissions}</li>\n	<li>Принято материалов за месяц: {$acceptedSubmissions}</li>\n	<li>Общее число материалов в системе: {$totalSubmissions}</li>\n</ul>\nВойдите в систему, чтобы посмотреть более подробные отчёты о <a href=\"{$editorialStatsLink}\">тенденциях редакции</a> и <a href=\"{$publicationStatsLink}\">статистике опубликованных статей</a>. Полная копия отчёта о тенденциях редакции за данный месяц прилагается к письму.<br />\n<br />\nС уважением,<br />\n{$principalContactSignature}', 'Это письмо каждый месяц автоматически отправляется редакторам и управляющим журнала, чтобы у них было представление о работе системы.'),
('SUBMISSION_ACK', 'en_US', 'Submission Acknowledgement', '{$authorName}:<br />\n<br />\nThank you for submitting the manuscript, &quot;{$submissionTitle}&quot; to {$contextName}. With the online journal management system that we are using, you will be able to track its progress through the editorial process by logging in to the journal web site:<br />\n<br />\nSubmission URL: {$submissionUrl}<br />\nUsername: {$authorUsername}<br />\n<br />\nIf you have any questions, please contact me. Thank you for considering this journal as a venue for your work.<br />\n<br />\n{$editorialContactSignature}', 'This email, when enabled, is automatically sent to an author when he or she completes the process of submitting a manuscript to the journal. It provides information about tracking the submission through the process and thanks the author for the submission.'),
('SUBMISSION_ACK', 'ru_RU', 'Подтверждение отправки', 'Здравствуйте, {$authorName}!<br />\n<br />\nБлагодарим Вас за отправку материала «{$submissionTitle}» в журнал «{$contextName}». С помощью онлайн-системы управления журналом, которую мы используем, Вы сможете отслеживать его прохождение через редакционный процесс, заходя на сайт журнала:<br />\n<br />\nURL материала: {$submissionUrl}<br />\nИмя пользователя: {$authorUsername}<br />\n<br />\nЕсли у Вас возникнут какие-то вопросы, пожалуйста, свяжитесь со мной. Спасибо за выбор нашего журнала для публикации Вашей работы.<br />\n<br />\n{$editorialContactSignature}', 'Это письмо (если эта возможность включена) автоматически отправляется автору, когда он завершает процесс отправки материала в журнал. В письме содержится информация об отслеживании прохождения материала через редакционный процесс и благодарность автору за присланный материал.'),
('SUBMISSION_ACK_NOT_USER', 'en_US', 'Submission Acknowledgement', 'Hello,<br />\n<br />\n{$submitterName} has submitted the manuscript, &quot;{$submissionTitle}&quot; to {$contextName}. <br />\n<br />\nIf you have any questions, please contact me. Thank you for considering this journal as a venue for your work.<br />\n<br />\n{$editorialContactSignature}', 'This email, when enabled, is automatically sent to the other authors who are not users within OJS specified during the submission process.'),
('SUBMISSION_ACK_NOT_USER', 'ru_RU', 'Подтверждение отправки', 'Здравствуйте!<br />\n<br />\nПользователь {$submitterName} отправил материал «{$submissionTitle}» в журнал «{$contextName}». <br />\n<br />\nЕсли у Вас возникнут какие-то вопросы, пожалуйста, свяжитесь со мной. Спасибо за выбор нашего журнала для публикации Вашей работы.<br />\n<br />\n{$editorialContactSignature}', 'Это письмо (если эта возможность включена) автоматически отправляется другим авторам, которые не являются пользователями OJS, указанным в процессе отправки материала.'),
('SUBSCRIPTION_AFTER_EXPIRY', 'en_US', 'Subscription Expired', '{$subscriberName}:<br />\n<br />\nYour {$contextName} subscription has expired.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo renew your subscription, please go to the journal website. You are able to log in to the system with your username, &quot;{$username}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionContactSignature}', 'This email notifies a subscriber that their subscription has expired. It provides the journal\'s URL along with instructions for access.'),
('SUBSCRIPTION_AFTER_EXPIRY', 'ru_RU', 'уведомление об окончании срока подписки', 'Здравствуйте, {$subscriberName}!<br />\n<br />\nСрок Вашей подписки на журнал «{$contextName}» истек.<br />\n<br />\n{$subscriptionType}<br />\nДата окончания подписки: {$expiryDate}<br />\n<br />\nДля продления Вашей подписки, пожалуйста, перейдите на сайт журнала. Вы можете войти на сайт журнала со своим именем пользователя «{$username}».<br />\n<br />\nЕсли у Вас есть какие-либо вопросы, пожалуйста, не стесняйтесь, связывайтесь со мной.<br />\n<br />\n{$subscriptionContactSignature}', 'Это письмо уведомляет подписчика о том, что срок его подписки закончился. В письме содержится URL журнала и инструкции по доступу.'),
('SUBSCRIPTION_AFTER_EXPIRY_LAST', 'en_US', 'Subscription Expired - Final Reminder', '{$subscriberName}:<br />\n<br />\nYour {$contextName} subscription has expired.<br />\nPlease note that this is the final reminder that will be emailed to you.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo renew your subscription, please go to the journal website. You are able to log in to the system with your username, &quot;{$username}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionContactSignature}', 'This email notifies a subscriber that their subscription has expired. It provides the journal\'s URL along with instructions for access.'),
('SUBSCRIPTION_AFTER_EXPIRY_LAST', 'ru_RU', 'Срок подписки истек — последнее напоминание', 'Здравствуйте, {$subscriberName}!<br />\n<br />\nСрок Вашей подписки на журнал «{$contextName}» истек.<br />\nПожалуйста, обратите внимание, что это — последнее напоминание, которое будет отправлено Вам электронной почтой.<br />\n<br />\n{$subscriptionType}<br />\nДата окончания подписки: {$expiryDate}<br />\n<br />\nДля продления Вашей подписки, пожалуйста, перейдите на сайт журнала. Вы можете войти на сайт журнала со своим именем пользователя «{$username}».<br />\n<br />\nЕсли у Вас есть какие-либо вопросы, пожалуйста, не стесняйтесь, связывайтесь со мной.<br />\n<br />\n{$subscriptionContactSignature}', 'Это письмо уведомляет подписчика о том, что срок его подписки закончился. В письме содержится URL журнала и инструкции по доступу.'),
('SUBSCRIPTION_BEFORE_EXPIRY', 'en_US', 'Notice of Subscription Expiry', '{$subscriberName}:<br />\n<br />\nYour {$contextName} subscription is about to expire.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo ensure the continuity of your access to this journal, please go to the journal website and renew your subscription. You are able to log in to the system with your username, &quot;{$username}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionContactSignature}', 'This email notifies a subscriber that their subscription will soon expire. It provides the journal\'s URL along with instructions for access.'),
('SUBSCRIPTION_BEFORE_EXPIRY', 'ru_RU', 'Уведомление об окончании срока подписки', 'Здравствуйте, {$subscriberName}!<br />\n<br />\nВаша подписка на журнал «{$contextName}» истекает в ближайшее время.<br />\n<br />\n{$subscriptionType}<br />\nДата окончания подписки: {$expiryDate}<br />\n<br />\nЧтобы Ваш доступ к этому журналу не прерывался, пожалуйста, перейдите на сайт журнала и продлите Вашу подписку. Вы можете войти на сайт журнала со своим именем пользователя «{$username}».<br />\n<br />\nЕсли у Вас есть какие-либо вопросы, пожалуйста, не стесняйтесь, связывайтесь со мной.<br />\n<br />\n{$subscriptionContactSignature}', 'Это письмо уведомляет подписчика о том, что его подписка вскоре закончится. В письме содержится URL журнала и инструкции по доступу.'),
('SUBSCRIPTION_NOTIFY', 'en_US', 'Subscription Notification', '{$subscriberName}:<br />\n<br />\nYou have now been registered as a subscriber in our online journal management system for {$contextName}, with the following subscription:<br />\n<br />\n{$subscriptionType}<br />\n<br />\nTo access content that is available only to subscribers, simply log in to the system with your username, &quot;{$username}&quot;.<br />\n<br />\nOnce you have logged in to the system you can change your profile details and password at any point.<br />\n<br />\nPlease note that if you have an institutional subscription, there is no need for users at your institution to log in, since requests for subscription content will be automatically authenticated by the system.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionContactSignature}', 'This email notifies a registered reader that the Manager has created a subscription for them. It provides the journal\'s URL along with instructions for access.'),
('SUBSCRIPTION_NOTIFY', 'ru_RU', 'Уведомление о подписке', 'Здравствуйте, {$subscriberName}!<br />\n<br />\nВы теперь зарегистрированы в нашей онлайн-системе управления журналом как подписчик журнала «{$contextName}» со следующей подпиской:<br />\n<br />\n{$subscriptionType}<br />\n<br />\nЧтобы получить доступ к контенту, который доступен только для подписчиков, просто войдите на сайт журнала со своим именем пользователя «{$username}».<br />\n<br />\nКак только Вы войдете в систему, Вы можете в любой момент изменить Ваш профиль пользователя и пароль.<br />\n<br />\nПожалуйста, обратите внимание, что если у Вас есть подписка на всю организацию, то пользователям Вашей организации не нужно будет входить в систему, так как запросы на контент, предоставляемый по подписке, автоматически будут аутентифицированы системой.<br />\n<br />\nЕсли у Вас есть какие-либо вопросы, пожалуйста, не стесняйтесь, связывайтесь со мной.<br />\n<br />\n{$subscriptionContactSignature}', 'Это письмо уведомляет зарегистрированного читателя, что менеджер создал для него подписку. В письме содержится URL журнала и инструкции по доступу.'),
('SUBSCRIPTION_PURCHASE_INDL', 'en_US', 'Subscription Purchase: Individual', 'An individual subscription has been purchased online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nUser:<br />\n{$userDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n', 'This email notifies the Subscription Manager that an individual subscription has been purchased online. It provides summary information about the subscription and a quick access link to the purchased subscription.'),
('SUBSCRIPTION_PURCHASE_INDL', 'ru_RU', 'Покупка подписки: индивидуальная', 'На сайте была приобретена индивидуальная подписка на журнал «{$contextName}» со следующими деталями.<br />\n<br />\nТип подписки:<br />\n{$subscriptionType}<br />\n<br />\nПользователь:<br />\n{$userDetails}<br />\n<br />\nИнформация о членстве (если указана):<br />\n{$membership}<br />\n<br />\nДля просмотра или редактирования этой подписки, пожалуйста, используйте следующий URL.<br />\n<br />\nURL подписки: {$subscriptionUrl}<br />\n', 'Это письмо уведомляет менеджера по подписке, что через сайт была куплена индивидуальная подписка. В письме содержится общая информация о подписке и ссылка быстрого доступа к приобретенной подписке.'),
('SUBSCRIPTION_PURCHASE_INSTL', 'en_US', 'Subscription Purchase: Institutional', 'An institutional subscription has been purchased online for {$contextName} with the following details. To activate this subscription, please use the provided Subscription URL and set the subscription status to \'Active\'.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nInstitution:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nDomain (if provided):<br />\n{$domain}<br />\n<br />\nIP Ranges (if provided):<br />\n{$ipRanges}<br />\n<br />\nContact Person:<br />\n{$userDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n', 'This email notifies the Subscription Manager that an institutional subscription has been purchased online. It provides summary information about the subscription and a quick access link to the purchased subscription.'),
('SUBSCRIPTION_PURCHASE_INSTL', 'ru_RU', 'Покупка подписки: на организацию', 'На сайте была приобретена для организации подписка на журнал «{$contextName}» со следующими деталями. Для активации подписки, пожалуйста, используйте приведенный URL подписки и установите статус подписки в «Активна».<br />\n<br />\nТип подписки:<br />\n{$subscriptionType}<br />\n<br />\nОрганизация:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nДоменное имя (если указано):<br />\n{$domain}<br />\n<br />\nIP-диапазоны (если указаны):<br />\n{$ipRanges}<br />\n<br />\nКонтактное лицо:<br />\n{$userDetails}<br />\n<br />\nИнформация о членстве (если указана):<br />\n{$membership}<br />\n<br />\nДля просмотра или редактирования этой подписки, пожалуйста, используйте следующий URL.<br />\n<br />\nURL подписки: {$subscriptionUrl}<br />\n', 'Это письмо уведомляет менеджера по подписке, что через сайт была куплена подписка на организацию. В письме содержится общая информация о подписке и ссылка быстрого доступа к приобретенной подписке.'),
('SUBSCRIPTION_RENEW_INDL', 'en_US', 'Subscription Renewal: Individual', 'An individual subscription has been renewed online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nUser:<br />\n{$userDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n', 'This email notifies the Subscription Manager that an individual subscription has been renewed online. It provides summary information about the subscription and a quick access link to the renewed subscription.'),
('SUBSCRIPTION_RENEW_INDL', 'ru_RU', 'Продление подписки: индивидуальная', 'На сайте была продлена индивидуальная подписка на журнал «{$contextName}» со следующими деталями.<br />\n<br />\nТип подписки:<br />\n{$subscriptionType}<br />\n<br />\nПользователь:<br />\n{$userDetails}<br />\n<br />\nИнформация о членстве (если указана):<br />\n{$membership}<br />\n<br />\nДля просмотра или редактирования этой подписки, пожалуйста, используйте следующий URL.<br />\n<br />\nURL подписки: {$subscriptionUrl}<br />\n', 'Это письмо уведомляет менеджера по подписке, что через сайт была продлена индивидуальная подписка. В письме содержится общая информация о подписке и ссылка быстрого доступа к продленной подписке.'),
('SUBSCRIPTION_RENEW_INSTL', 'en_US', 'Subscription Renewal: Institutional', 'An institutional subscription has been renewed online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nInstitution:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nDomain (if provided):<br />\n{$domain}<br />\n<br />\nIP Ranges (if provided):<br />\n{$ipRanges}<br />\n<br />\nContact Person:<br />\n{$userDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n', 'This email notifies the Subscription Manager that an institutional subscription has been renewed online. It provides summary information about the subscription and a quick access link to the renewed subscription.'),
('SUBSCRIPTION_RENEW_INSTL', 'ru_RU', 'Продление подписки: на организацию', 'На сайте для организации была продлена подписка на журнал «{$contextName}» со следующими деталями.<br />\n<br />\nТип подписки:<br />\n{$subscriptionType}<br />\n<br />\nОрганизация:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nДоменное имя (если указано):<br />\n{$domain}<br />\n<br />\nIP-диапазоны (если указаны):<br />\n{$ipRanges}<br />\n<br />\nКонтактное лицо:<br />\n{$userDetails}<br />\n<br />\nИнформация о членстве (если указана):<br />\n{$membership}<br />\n<br />\nДля просмотра или редактирования этой подписки, пожалуйста, используйте следующий URL.<br />\n<br />\nURL подписки: {$subscriptionUrl}<br />\n', 'Это письмо уведомляет менеджера по подписке, что через сайт была продлена подписка на организацию. В письме содержится общая информация о подписке и ссылка быстрого доступа к продленной подписке.'),
('USER_REGISTER', 'en_US', 'Journal Registration', '{$userFullName}<br />\n<br />\nYou have now been registered as a user with {$contextName}. We have included your username and password in this email, which are needed for all work with this journal through its website. At any point, you can ask to be removed from the journal\'s list of users by contacting me.<br />\n<br />\nUsername: {$username}<br />\nPassword: {$password}<br />\n<br />\nThank you,<br />\n{$principalContactSignature}', 'This email is sent to a newly registered user to welcome them to the system and provide them with a record of their username and password.'),
('USER_REGISTER', 'ru_RU', 'Регистрация в журнале', 'Здравствуйте, {$userFullName}!<br />\n<br />\nТеперь Вы зарегистрированы как пользователь в журнале «{$contextName}». В этом письме мы указали Ваши имя пользователя и пароль, которые потребуются для работы с этим журналом через сайт. Вы в любой момент можете попросить, чтобы Вас удалили из списка пользователей журнала, для этого просто свяжитесь со мной.<br />\n<br />\nИмя пользователя: {$username}<br />\nПароль: {$password}<br />\n<br />\nС уважением,<br />\n{$principalContactSignature}', 'Это письмо отправляется вновь зарегистрированному пользователю, приветствуя его в системе и сообщая ему имя пользователя и пароль для доступа к сайту.'),
('USER_VALIDATE', 'en_US', 'Validate Your Account', '{$userFullName}<br />\n<br />\nYou have created an account with {$contextName}, but before you can start using it, you need to validate your email account. To do this, simply follow the link below:<br />\n<br />\n{$activateUrl}<br />\n<br />\nThank you,<br />\n{$principalContactSignature}', 'This email is sent to a newly registered user to validate their email account.'),
('USER_VALIDATE', 'ru_RU', 'Подтвердите свою учетную запись', 'Здравствуйте, {$userFullName}!<br />\n<br />\nВы создали учетную запись в журнале «{$contextName}», но перед тем как начать ее использовать, Вам нужно подтвердить адрес электронной почты. Чтобы сделать это, просто пройдите по ссылке ниже:<br />\n<br />\n{$activateUrl}<br />\n<br />\nС уважением,<br />\n{$principalContactSignature}', 'Это письмо отправляется вновь зарегистрированному пользователю для подтверждения его адреса электронной почты.');

-- --------------------------------------------------------

--
-- Структура таблицы `email_templates_settings`
--

CREATE TABLE `email_templates_settings` (
  `email_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `event_log`
--

CREATE TABLE `event_log` (
  `log_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `date_logged` datetime NOT NULL,
  `event_type` bigint(20) DEFAULT NULL,
  `message` text,
  `is_translated` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `event_log`
--

INSERT INTO `event_log` (`log_id`, `assoc_type`, `assoc_id`, `user_id`, `date_logged`, `event_type`, `message`, `is_translated`) VALUES
(1, 1048585, 1, 1, '2020-04-21 09:40:17', 268435458, 'submission.event.general.metadataUpdated', 0),
(2, 515, 1, 1, '2020-04-21 09:44:32', 1342177281, 'submission.event.fileUploaded', 0),
(3, 515, 1, 1, '2020-04-21 09:44:50', 1342177282, 'submission.event.fileDeleted', 0),
(4, 1048585, 1, 1, '2020-04-21 09:44:50', 1342177283, 'submission.event.lastRevisionDeleted', 0),
(5, 515, 2, 1, '2020-04-21 09:44:50', 1342177281, 'submission.event.fileUploaded', 0),
(6, 515, 2, 1, '2020-04-21 09:44:53', 1342177282, 'submission.event.fileDeleted', 0),
(7, 1048585, 1, 1, '2020-04-21 09:44:53', 1342177283, 'submission.event.lastRevisionDeleted', 0),
(8, 515, 3, 1, '2020-04-21 09:45:06', 1342177281, 'submission.event.fileUploaded', 0),
(9, 1048585, 1, 1, '2020-04-21 09:45:13', 1342177281, 'submission.event.fileUploaded', 0),
(10, 515, 4, 1, '2020-04-21 09:45:30', 1342177281, 'submission.event.fileUploaded', 0),
(11, 1048585, 1, 1, '2020-04-21 09:49:50', 1342177281, 'submission.event.fileUploaded', 0),
(12, 1048585, 1, 1, '2020-04-21 09:55:12', 268435458, 'submission.event.general.metadataUpdated', 0),
(13, 1048585, 1, 1, '2020-04-21 09:55:33', 268435457, 'submission.event.submissionSubmitted', 0),
(14, 1048585, 1, 1, '2020-04-21 10:07:27', 1342177281, 'submission.event.fileUploaded', 0),
(15, 1048585, 1, 1, '2020-04-21 10:07:46', 1342177281, 'submission.event.fileUploaded', 0),
(16, 1048585, 1, 2, '2020-04-21 10:21:13', 16777217, 'informationCenter.history.messageSent', 0),
(17, 1048585, 1, 2, '2020-04-21 10:21:13', 268435459, 'submission.event.participantAdded', 0),
(18, 1048585, 1, 2, '2020-04-21 10:22:07', 805306371, 'log.editor.decision', 0),
(19, 1048585, 1, 2, '2020-04-21 10:22:40', 1073741825, 'log.review.reviewerAssigned', 0),
(20, 1048585, 1, 2, '2020-04-21 10:24:20', 1073741830, 'log.review.reviewAccepted', 0),
(21, 1048585, 1, 2, '2020-04-21 10:25:03', 1073741848, 'log.review.reviewReady', 0),
(22, 1048585, 1, 2, '2020-04-21 10:26:28', 1073741849, 'log.review.reviewConfirmed', 0),
(23, 1048585, 1, 2, '2020-04-21 10:26:31', 1073741849, 'log.review.reviewConfirmed', 0),
(24, 1048585, 1, 2, '2020-04-21 11:15:48', 805306371, 'log.editor.decision', 0),
(25, 1048585, 1, 2, '2020-04-21 11:16:39', 16777217, 'informationCenter.history.messageSent', 0),
(26, 1048585, 1, 2, '2020-04-21 11:16:39', 268435459, 'submission.event.participantAdded', 0),
(27, 1048585, 1, 2, '2020-04-21 11:18:23', 805306371, 'log.editor.decision', 0),
(28, 1048585, 1, 1, '2020-04-22 11:48:55', 268435458, 'submission.event.general.metadataUpdated', 0),
(29, 1048585, 1, 1, '2020-04-22 11:51:18', 268435458, 'submission.event.general.metadataUpdated', 0),
(30, 1048585, 1, 1, '2020-04-22 11:51:40', 268435462, 'publication.event.scheduled', 0),
(31, 1048585, 2, 4, '2021-01-27 20:52:49', 268435458, 'submission.event.general.metadataUpdated', 0),
(32, 515, 9, 4, '2021-01-27 20:53:05', 1342177281, 'submission.event.fileUploaded', 0),
(33, 1048585, 2, 4, '2021-01-27 20:53:09', 1342177281, 'submission.event.fileUploaded', 0),
(34, 1048585, 2, 4, '2021-01-27 20:53:58', 268435458, 'submission.event.general.metadataUpdated', 0),
(35, 1048585, 2, 4, '2021-01-27 20:54:02', 268435457, 'submission.event.submissionSubmitted', 0),
(36, 1048585, 2, 4, '2021-01-27 20:54:41', 268435459, 'submission.event.participantAdded', 0),
(37, 1048585, 2, 4, '2021-01-27 20:55:14', 805306371, 'log.editor.decision', 0),
(38, 1048585, 2, 4, '2021-01-27 20:55:58', 1073741825, 'log.review.reviewerAssigned', 0),
(39, 1048585, 2, 4, '2021-01-27 20:57:14', 1073741830, 'log.review.reviewAccepted', 0),
(40, 1048585, 2, 4, '2021-01-27 20:58:26', 1073741848, 'log.review.reviewReady', 0),
(41, 1048585, 2, 4, '2021-01-27 20:59:56', 805306371, 'log.editor.decision', 0),
(42, 1048585, 3, 4, '2021-05-06 14:31:11', 268435458, 'submission.event.general.metadataUpdated', 0),
(43, 515, 11, 4, '2021-05-06 14:31:22', 1342177281, 'submission.event.fileUploaded', 0),
(44, 1048585, 3, 4, '2021-05-06 14:31:25', 1342177281, 'submission.event.fileUploaded', 0),
(45, 1048585, 3, 4, '2021-05-06 14:32:07', 268435458, 'submission.event.general.metadataUpdated', 0),
(46, 1048585, 3, 4, '2021-05-06 14:32:10', 268435457, 'submission.event.submissionSubmitted', 0),
(47, 1048585, 2, 4, '2021-05-06 14:38:57', 1073741846, 'log.review.reviewRecommendationSetByProxy', 0),
(48, 1048585, 2, 4, '2021-05-06 14:38:57', 1073741849, 'log.review.reviewConfirmed', 0),
(49, 1048585, 3, 4, '2021-05-06 14:39:31', 1342177281, 'submission.event.fileUploaded', 0),
(50, 1048585, 4, 4, '2021-05-06 14:41:16', 268435458, 'submission.event.general.metadataUpdated', 0),
(51, 515, 12, 4, '2021-05-06 14:41:29', 1342177281, 'submission.event.fileUploaded', 0),
(52, 1048585, 4, 4, '2021-05-06 14:41:32', 1342177281, 'submission.event.fileUploaded', 0),
(53, 1048585, 4, 4, '2021-05-06 14:42:19', 268435458, 'submission.event.general.metadataUpdated', 0),
(54, 1048585, 4, 4, '2021-05-06 14:42:22', 268435457, 'submission.event.submissionSubmitted', 0),
(55, 1048585, 4, 4, '2021-05-06 14:48:20', 268435459, 'submission.event.participantAdded', 0),
(56, 1048585, 4, 4, '2021-05-06 14:48:33', 805306371, 'log.editor.decision', 0),
(57, 1048585, 3, 4, '2021-05-06 14:51:38', 268435459, 'submission.event.participantAdded', 0),
(58, 1048585, 3, 4, '2021-05-06 14:52:08', 805306371, 'log.editor.decision', 0),
(59, 1048585, 3, 4, '2021-05-06 14:52:56', 1073741825, 'log.review.reviewerAssigned', 0),
(60, 1048585, 3, 4, '2021-05-06 14:54:40', 1073741830, 'log.review.reviewAccepted', 0),
(61, 515, 15, 4, '2021-05-06 14:55:22', 1342177281, 'submission.event.fileUploaded', 0),
(62, 1048585, 3, 4, '2021-05-06 14:55:24', 1342177281, 'submission.event.fileUploaded', 0),
(63, 1048585, 3, 4, '2021-05-06 14:55:33', 1073741848, 'log.review.reviewReady', 0),
(64, 515, 16, 3, '2021-05-06 14:57:08', 1342177281, 'submission.event.fileUploaded', 0),
(65, 1048585, 3, 4, '2021-05-06 14:57:10', 1342177281, 'submission.event.fileUploaded', 0),
(66, 1048585, 3, 4, '2021-05-06 14:57:21', 805306371, 'log.editor.decision', 0),
(67, 1048585, 3, 4, '2021-05-06 14:58:09', 1073741825, 'log.review.reviewerAssigned', 0),
(68, 1048585, 3, 4, '2021-05-06 15:02:14', 1073741830, 'log.review.reviewAccepted', 0),
(69, 515, 18, 4, '2021-05-06 15:04:42', 1342177281, 'submission.event.fileUploaded', 0),
(70, 1048585, 3, 4, '2021-05-06 15:04:44', 1342177281, 'submission.event.fileUploaded', 0),
(71, 1048585, 3, 4, '2021-05-06 15:04:53', 1073741848, 'log.review.reviewReady', 0),
(72, 1048585, 3, 4, '2021-05-06 15:07:19', 805306371, 'log.editor.decision', 0),
(73, 1048585, 3, 4, '2021-05-06 15:07:49', 268435459, 'submission.event.participantAdded', 0),
(74, 1048585, 4, 4, '2021-05-06 15:10:32', 1073741825, 'log.review.reviewerAssigned', 0),
(75, 1048585, 4, 4, '2021-05-06 15:11:28', 1073741830, 'log.review.reviewAccepted', 0),
(76, 515, 19, 4, '2021-05-06 15:11:43', 1342177281, 'submission.event.fileUploaded', 0),
(77, 1048585, 4, 4, '2021-05-06 15:11:46', 1342177281, 'submission.event.fileUploaded', 0),
(78, 1048585, 4, 4, '2021-05-06 15:12:02', 1073741848, 'log.review.reviewReady', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `event_log_settings`
--

CREATE TABLE `event_log_settings` (
  `log_id` bigint(20) NOT NULL,
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `event_log_settings`
--

INSERT INTO `event_log_settings` (`log_id`, `setting_name`, `setting_value`, `setting_type`) VALUES
(2, 'fileId', '1', 'int'),
(2, 'fileStage', '2', 'int'),
(2, 'originalFileName', 'Тест - текст.docx', 'string'),
(2, 'revisedFileId', NULL, 'string'),
(2, 'submissionFileId', '1', 'string'),
(2, 'submissionId', '1', 'int'),
(2, 'username', 'superadmin', 'string'),
(3, 'fileId', '1', 'int'),
(3, 'fileStage', '2', 'int'),
(3, 'originalFileName', 'Тест - текст.docx', 'string'),
(3, 'sourceFileId', NULL, 'string'),
(3, 'submissionFileId', '1', 'int'),
(3, 'submissionId', '1', 'int'),
(3, 'username', 'superadmin', 'string'),
(4, 'submissionId', '1', 'int'),
(4, 'title', 'Тест - текст.docx', 'string'),
(4, 'username', 'superadmin', 'string'),
(5, 'fileId', '1', 'int'),
(5, 'fileStage', '2', 'int'),
(5, 'originalFileName', 'Тест.docx', 'string'),
(5, 'revisedFileId', NULL, 'string'),
(5, 'submissionFileId', '2', 'string'),
(5, 'submissionId', '1', 'int'),
(5, 'username', 'superadmin', 'string'),
(6, 'fileId', '1', 'int'),
(6, 'fileStage', '2', 'int'),
(6, 'originalFileName', 'Тест.docx', 'string'),
(6, 'sourceFileId', NULL, 'string'),
(6, 'submissionFileId', '2', 'int'),
(6, 'submissionId', '1', 'int'),
(6, 'username', 'superadmin', 'string'),
(7, 'submissionId', '1', 'int'),
(7, 'title', 'Тест.docx', 'string'),
(7, 'username', 'superadmin', 'string'),
(8, 'fileId', '1', 'int'),
(8, 'fileStage', '2', 'int'),
(8, 'originalFileName', 'Тест - текст.docx', 'string'),
(8, 'revisedFileId', NULL, 'string'),
(8, 'submissionFileId', '3', 'string'),
(8, 'submissionId', '1', 'int'),
(8, 'username', 'superadmin', 'string'),
(9, 'fileId', '1', 'int'),
(9, 'fileStage', '2', 'int'),
(9, 'name', 'superadmin, Тест - текст.docx', 'string'),
(9, 'originalFileName', 'Тест - текст.docx', 'string'),
(9, 'submissionFileId', '3', 'int'),
(9, 'submissionId', '1', 'int'),
(9, 'username', 'superadmin', 'string'),
(10, 'fileId', '2', 'int'),
(10, 'fileStage', '2', 'int'),
(10, 'originalFileName', 'Тест.docx', 'string'),
(10, 'revisedFileId', NULL, 'string'),
(10, 'submissionFileId', '4', 'string'),
(10, 'submissionId', '1', 'int'),
(10, 'username', 'superadmin', 'string'),
(11, 'fileId', '2', 'int'),
(11, 'fileStage', '2', 'int'),
(11, 'name', 'superadmin, Тест.docx', 'string'),
(11, 'originalFileName', 'Тест.docx', 'string'),
(11, 'submissionFileId', '4', 'int'),
(11, 'submissionId', '1', 'int'),
(11, 'username', 'superadmin', 'string'),
(14, 'fileId', '1', 'int'),
(14, 'fileStage', '2', 'int'),
(14, 'name', 'Test - text.docx', 'string'),
(14, 'originalFileName', 'Тест - текст.docx', 'string'),
(14, 'submissionFileId', '3', 'int'),
(14, 'submissionId', '1', 'int'),
(14, 'username', 'superadmin', 'string'),
(15, 'fileId', '2', 'int'),
(15, 'fileStage', '2', 'int'),
(15, 'name', 'Test.docx', 'string'),
(15, 'originalFileName', 'Тест.docx', 'string'),
(15, 'submissionFileId', '4', 'int'),
(15, 'submissionId', '1', 'int'),
(15, 'username', 'superadmin', 'string'),
(17, 'name', 'Владимир Влукин', 'string'),
(17, 'userGroupName', 'Редактор журнала', 'string'),
(17, 'username', 'vllukin', 'string'),
(18, 'decision', 'Отправить на рецензию', 'string'),
(18, 'editorName', 'Владимир Влукин', 'string'),
(18, 'submissionId', '1', 'int'),
(19, 'reviewAssignmentId', '1', 'string'),
(19, 'reviewerName', 'Владимир Влукин', 'string'),
(19, 'round', '1', 'int'),
(19, 'stageId', '3', 'int'),
(19, 'submissionId', '1', 'int'),
(20, 'reviewAssignmentId', '1', 'int'),
(20, 'reviewerName', 'Владимир Влукин', 'string'),
(20, 'round', '1', 'int'),
(20, 'submissionId', '1', 'int'),
(21, 'reviewAssignmentId', '1', 'int'),
(21, 'reviewerName', 'Владимир Влукин', 'string'),
(21, 'round', '1', 'int'),
(21, 'submissionId', '1', 'int'),
(22, 'round', '1', 'int'),
(22, 'submissionId', '1', 'int'),
(22, 'userName', 'Владимир Влукин', 'string'),
(23, 'round', '1', 'int'),
(23, 'submissionId', '1', 'int'),
(23, 'userName', 'Владимир Влукин', 'string'),
(24, 'decision', 'Принять материал', 'string'),
(24, 'editorName', 'Владимир Влукин', 'string'),
(24, 'submissionId', '1', 'int'),
(26, 'name', 'Владимир Влукин', 'string'),
(26, 'userGroupName', 'Литературный редактор', 'string'),
(26, 'username', 'vllukin', 'string'),
(27, 'decision', 'Отправить на публикацию', 'string'),
(27, 'editorName', 'Владимир Влукин', 'string'),
(27, 'submissionId', '1', 'int'),
(32, 'fileId', '7', 'int'),
(32, 'fileStage', '2', 'int'),
(32, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(32, 'revisedFileId', NULL, 'string'),
(32, 'submissionFileId', '9', 'string'),
(32, 'submissionId', '2', 'int'),
(32, 'username', 'admin', 'string'),
(33, 'fileId', '7', 'int'),
(33, 'fileStage', '2', 'int'),
(33, 'name', 'admin, 4090-33487-3-CE.doc', 'string'),
(33, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(33, 'submissionFileId', '9', 'int'),
(33, 'submissionId', '2', 'int'),
(33, 'username', 'admin', 'string'),
(36, 'name', 'Наталья Моллекер', 'string'),
(36, 'userGroupName', 'Редактор журнала', 'string'),
(36, 'username', 'admin', 'string'),
(37, 'decision', 'Отправить на рецензию', 'string'),
(37, 'editorName', 'Наталья Моллекер', 'string'),
(37, 'submissionId', '2', 'int'),
(38, 'reviewAssignmentId', '2', 'string'),
(38, 'reviewerName', 'Наталья Моллекер', 'string'),
(38, 'round', '1', 'int'),
(38, 'stageId', '3', 'int'),
(38, 'submissionId', '2', 'int'),
(39, 'reviewAssignmentId', '2', 'int'),
(39, 'reviewerName', 'Наталья Моллекер', 'string'),
(39, 'round', '1', 'int'),
(39, 'submissionId', '2', 'int'),
(40, 'reviewAssignmentId', '2', 'int'),
(40, 'reviewerName', 'Наталья Моллекер', 'string'),
(40, 'round', '1', 'int'),
(40, 'submissionId', '2', 'int'),
(41, 'decision', 'Принять материал', 'string'),
(41, 'editorName', 'Наталья Моллекер', 'string'),
(41, 'submissionId', '2', 'int'),
(43, 'fileId', '9', 'int'),
(43, 'fileStage', '2', 'int'),
(43, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(43, 'revisedFileId', NULL, 'string'),
(43, 'submissionFileId', '11', 'string'),
(43, 'submissionId', '3', 'int'),
(43, 'username', 'admin', 'string'),
(44, 'fileId', '9', 'int'),
(44, 'fileStage', '2', 'int'),
(44, 'name', 'admin, 4090-33487-3-CE.doc', 'string'),
(44, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(44, 'submissionFileId', '11', 'int'),
(44, 'submissionId', '3', 'int'),
(44, 'username', 'admin', 'string'),
(47, 'editorName', 'Наталья Моллекер', 'string'),
(47, 'reviewerName', 'Наталья Моллекер', 'string'),
(47, 'round', '1', 'int'),
(47, 'submissionId', '2', 'int'),
(48, 'round', '1', 'int'),
(48, 'submissionId', '2', 'int'),
(48, 'userName', 'Наталья Моллекер', 'string'),
(49, 'fileId', '9', 'int'),
(49, 'fileStage', '2', 'int'),
(49, 'name', 'admin, 4090-33487-3-CE.doc', 'string'),
(49, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(49, 'submissionFileId', '11', 'int'),
(49, 'submissionId', '3', 'int'),
(49, 'username', 'admin', 'string'),
(51, 'fileId', '10', 'int'),
(51, 'fileStage', '2', 'int'),
(51, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(51, 'revisedFileId', NULL, 'string'),
(51, 'submissionFileId', '12', 'string'),
(51, 'submissionId', '4', 'int'),
(51, 'username', 'admin', 'string'),
(52, 'fileId', '10', 'int'),
(52, 'fileStage', '2', 'int'),
(52, 'name', 'admin, 4090-33487-3-CE.doc', 'string'),
(52, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(52, 'submissionFileId', '12', 'int'),
(52, 'submissionId', '4', 'int'),
(52, 'username', 'admin', 'string'),
(55, 'name', 'Наталья Моллекер', 'string'),
(55, 'userGroupName', 'Редактор журнала', 'string'),
(55, 'username', 'admin', 'string'),
(56, 'decision', 'Отправить на рецензию', 'string'),
(56, 'editorName', 'Иван Тестов', 'string'),
(56, 'submissionId', '4', 'int'),
(57, 'name', 'Иван Тестов', 'string'),
(57, 'userGroupName', 'Редактор журнала', 'string'),
(57, 'username', 'test', 'string'),
(58, 'decision', 'Отправить на рецензию', 'string'),
(58, 'editorName', 'Иван Тестов', 'string'),
(58, 'submissionId', '3', 'int'),
(59, 'reviewAssignmentId', '3', 'string'),
(59, 'reviewerName', 'Наталья Моллекер', 'string'),
(59, 'round', '1', 'int'),
(59, 'stageId', '3', 'int'),
(59, 'submissionId', '3', 'int'),
(60, 'reviewAssignmentId', '3', 'int'),
(60, 'reviewerName', 'Наталья Моллекер', 'string'),
(60, 'round', '1', 'int'),
(60, 'submissionId', '3', 'int'),
(61, 'fileId', '13', 'int'),
(61, 'fileStage', '5', 'int'),
(61, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(61, 'revisedFileId', NULL, 'string'),
(61, 'submissionFileId', '15', 'string'),
(61, 'submissionId', '3', 'int'),
(61, 'username', 'admin', 'string'),
(62, 'fileId', '13', 'int'),
(62, 'fileStage', '5', 'int'),
(62, 'name', ', 4090-33487-3-CE.doc', 'string'),
(62, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(62, 'submissionFileId', '15', 'int'),
(62, 'submissionId', '3', 'int'),
(62, 'username', 'admin', 'string'),
(63, 'reviewAssignmentId', '3', 'int'),
(63, 'reviewerName', 'Наталья Моллекер', 'string'),
(63, 'round', '1', 'int'),
(63, 'submissionId', '3', 'int'),
(64, 'fileId', '14', 'int'),
(64, 'fileStage', '15', 'int'),
(64, 'originalFileName', '9627-57577-1-SM.docx', 'string'),
(64, 'revisedFileId', NULL, 'string'),
(64, 'submissionFileId', '16', 'string'),
(64, 'submissionId', '3', 'int'),
(64, 'username', 'test', 'string'),
(65, 'fileId', '14', 'int'),
(65, 'fileStage', '15', 'int'),
(65, 'name', 'Текст статьи, 9627-57577-1-SM.docx', 'string'),
(65, 'originalFileName', '9627-57577-1-SM.docx', 'string'),
(65, 'submissionFileId', '16', 'int'),
(65, 'submissionId', '3', 'int'),
(65, 'username', 'test', 'string'),
(66, 'decision', 'Отправить повторно на рецензию', 'string'),
(66, 'editorName', 'Иван Тестов', 'string'),
(66, 'submissionId', '3', 'int'),
(67, 'reviewAssignmentId', '4', 'string'),
(67, 'reviewerName', 'Наталья Моллекер', 'string'),
(67, 'round', '2', 'int'),
(67, 'stageId', '3', 'int'),
(67, 'submissionId', '3', 'int'),
(68, 'reviewAssignmentId', '4', 'int'),
(68, 'reviewerName', 'Наталья Моллекер', 'string'),
(68, 'round', '2', 'int'),
(68, 'submissionId', '3', 'int'),
(69, 'fileId', '16', 'int'),
(69, 'fileStage', '5', 'int'),
(69, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(69, 'revisedFileId', NULL, 'string'),
(69, 'submissionFileId', '18', 'string'),
(69, 'submissionId', '3', 'int'),
(69, 'username', 'admin', 'string'),
(70, 'fileId', '16', 'int'),
(70, 'fileStage', '5', 'int'),
(70, 'name', ', 4090-33487-3-CE.doc', 'string'),
(70, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(70, 'submissionFileId', '18', 'int'),
(70, 'submissionId', '3', 'int'),
(70, 'username', 'admin', 'string'),
(71, 'reviewAssignmentId', '4', 'int'),
(71, 'reviewerName', 'Наталья Моллекер', 'string'),
(71, 'round', '2', 'int'),
(71, 'submissionId', '3', 'int'),
(72, 'decision', 'Принять материал', 'string'),
(72, 'editorName', 'Иван Тестов', 'string'),
(72, 'submissionId', '3', 'int'),
(73, 'name', 'Наталья Моллекер', 'string'),
(73, 'userGroupName', 'Литературный редактор', 'string'),
(73, 'username', 'admin', 'string'),
(74, 'reviewAssignmentId', '5', 'string'),
(74, 'reviewerName', 'Наталья Моллекер', 'string'),
(74, 'round', '1', 'int'),
(74, 'stageId', '3', 'int'),
(74, 'submissionId', '4', 'int'),
(75, 'reviewAssignmentId', '5', 'int'),
(75, 'reviewerName', 'Наталья Моллекер', 'string'),
(75, 'round', '1', 'int'),
(75, 'submissionId', '4', 'int'),
(76, 'fileId', '17', 'int'),
(76, 'fileStage', '5', 'int'),
(76, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(76, 'revisedFileId', NULL, 'string'),
(76, 'submissionFileId', '19', 'string'),
(76, 'submissionId', '4', 'int'),
(76, 'username', 'admin', 'string'),
(77, 'fileId', '17', 'int'),
(77, 'fileStage', '5', 'int'),
(77, 'name', ', 4090-33487-3-CE.doc', 'string'),
(77, 'originalFileName', '4090-33487-3-CE.doc', 'string'),
(77, 'submissionFileId', '19', 'int'),
(77, 'submissionId', '4', 'int'),
(77, 'username', 'admin', 'string'),
(78, 'reviewAssignmentId', '5', 'int'),
(78, 'reviewerName', 'Наталья Моллекер', 'string'),
(78, 'round', '1', 'int'),
(78, 'submissionId', '4', 'int');

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--

CREATE TABLE `files` (
  `file_id` bigint(20) UNSIGNED NOT NULL,
  `path` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `files`
--

INSERT INTO `files` (`file_id`, `path`, `mimetype`) VALUES
(1, 'journals/1/articles/1/submission/1-1-3-1-2-20200421.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(2, 'journals/1/articles/1/submission/1-8-4-1-2-20200421.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(3, 'journals/1/articles/1/submission/review/1-1-5-1-4-20200421.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(4, 'journals/1/articles/1/submission/final/1-1-6-1-6-20200421.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(5, 'journals/1/articles/1/submission/copyedit/1-1-7-1-9-20200421.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(6, 'journals/1/articles/1/submission/productionReady/1-1-8-1-11-20200421.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(7, 'journals/2/articles/2/submission/2-13-9-1-2-20210127.doc', 'application/msword'),
(8, 'journals/2/articles/2/submission/review/2-13-10-1-4-20210127.doc', 'application/msword'),
(9, 'journals/2/articles/3/submission/3-13-11-1-2-20210506.doc', 'application/msword'),
(10, 'journals/2/articles/4/submission/4-13-12-1-2-20210506.doc', 'application/msword'),
(11, 'journals/2/articles/4/submission/review/4-13-13-1-4-20210506.doc', 'application/msword'),
(12, 'journals/2/articles/3/submission/review/3-13-14-1-4-20210506.doc', 'application/msword'),
(13, 'journals/2/articles/3/submission/review/attachment/3--15-1-5-20210506.doc', 'application/msword'),
(14, 'journals/2/articles/3/submission/review/revision/3-13-16-1-15-20210506.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(15, 'journals/2/articles/3/submission/review/3-13-17-1-4-20210506.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(16, 'journals/2/articles/3/submission/review/attachment/3--18-1-5-20210506.doc', 'application/msword'),
(17, 'journals/2/articles/4/submission/review/attachment/4--19-1-5-20210506.doc', 'application/msword');

-- --------------------------------------------------------

--
-- Структура таблицы `filters`
--

CREATE TABLE `filters` (
  `filter_id` bigint(20) NOT NULL,
  `filter_group_id` bigint(20) NOT NULL DEFAULT '0',
  `context_id` bigint(20) NOT NULL DEFAULT '0',
  `display_name` varchar(255) DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `is_template` tinyint(4) NOT NULL DEFAULT '0',
  `parent_filter_id` bigint(20) NOT NULL DEFAULT '0',
  `seq` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `filters`
--

INSERT INTO `filters` (`filter_id`, `filter_group_id`, `context_id`, `display_name`, `class_name`, `is_template`, `parent_filter_id`, `seq`) VALUES
(1, 1, 0, 'MODS 3.4', 'lib.pkp.plugins.metadata.mods34.filter.Mods34DescriptionXmlFilter', 0, 0, 0),
(4, 4, 0, 'Extract metadata from a(n) Submission', 'plugins.metadata.dc11.filter.Dc11SchemaArticleAdapter', 0, 0, 0),
(5, 5, 0, 'DataCite XML export', 'plugins.importexport.datacite.filter.DataciteXmlFilter', 0, 0, 0),
(6, 6, 0, 'DataCite XML export', 'plugins.importexport.datacite.filter.DataciteXmlFilter', 0, 0, 0),
(7, 7, 0, 'DataCite XML export', 'plugins.importexport.datacite.filter.DataciteXmlFilter', 0, 0, 0),
(8, 8, 0, 'DOAJ XML export', 'plugins.importexport.doaj.filter.DOAJXmlFilter', 0, 0, 0),
(9, 9, 0, 'DOAJ JSON export', 'plugins.importexport.doaj.filter.DOAJJsonFilter', 0, 0, 0),
(13, 13, 0, 'Native XML submission export', 'plugins.importexport.native.filter.ArticleNativeXmlFilter', 0, 0, 0),
(14, 14, 0, 'Native XML submission import', 'plugins.importexport.native.filter.NativeXmlArticleFilter', 0, 0, 0),
(15, 15, 0, 'Native XML issue export', 'plugins.importexport.native.filter.IssueNativeXmlFilter', 0, 0, 0),
(16, 16, 0, 'Native XML issue import', 'plugins.importexport.native.filter.NativeXmlIssueFilter', 0, 0, 0),
(17, 17, 0, 'Native XML issue galley export', 'plugins.importexport.native.filter.IssueGalleyNativeXmlFilter', 0, 0, 0),
(18, 18, 0, 'Native XML issue galley import', 'plugins.importexport.native.filter.NativeXmlIssueGalleyFilter', 0, 0, 0),
(19, 19, 0, 'Native XML author export', 'plugins.importexport.native.filter.AuthorNativeXmlFilter', 0, 0, 0),
(20, 20, 0, 'Native XML author import', 'plugins.importexport.native.filter.NativeXmlAuthorFilter', 0, 0, 0),
(21, 24, 0, 'Native XML submission file import', 'plugins.importexport.native.filter.NativeXmlArticleFileFilter', 0, 0, 0),
(22, 25, 0, 'Native XML submission file import', 'plugins.importexport.native.filter.NativeXmlArtworkFileFilter', 0, 0, 0),
(23, 26, 0, 'Native XML submission file import', 'plugins.importexport.native.filter.NativeXmlSupplementaryFileFilter', 0, 0, 0),
(24, 21, 0, 'Native XML submission file export', 'lib.pkp.plugins.importexport.native.filter.SubmissionFileNativeXmlFilter', 0, 0, 0),
(25, 22, 0, 'Native XML submission file export', 'plugins.importexport.native.filter.ArtworkFileNativeXmlFilter', 0, 0, 0),
(26, 23, 0, 'Native XML submission file export', 'plugins.importexport.native.filter.SupplementaryFileNativeXmlFilter', 0, 0, 0),
(27, 27, 0, 'Native XML representation export', 'plugins.importexport.native.filter.ArticleGalleyNativeXmlFilter', 0, 0, 0),
(28, 28, 0, 'Native XML representation import', 'plugins.importexport.native.filter.NativeXmlArticleGalleyFilter', 0, 0, 0),
(29, 29, 0, 'Native XML Publication export', 'plugins.importexport.native.filter.PublicationNativeXmlFilter', 0, 0, 0),
(30, 30, 0, 'Native XML publication import', 'plugins.importexport.native.filter.NativeXmlPublicationFilter', 0, 0, 0),
(31, 31, 0, 'Crossref XML issue export', 'plugins.importexport.crossref.filter.IssueCrossrefXmlFilter', 0, 0, 0),
(32, 32, 0, 'Crossref XML issue export', 'plugins.importexport.crossref.filter.ArticleCrossrefXmlFilter', 0, 0, 0),
(33, 33, 0, 'User XML user export', 'lib.pkp.plugins.importexport.users.filter.PKPUserUserXmlFilter', 0, 0, 0),
(34, 34, 0, 'User XML user import', 'lib.pkp.plugins.importexport.users.filter.UserXmlPKPUserFilter', 0, 0, 0),
(35, 35, 0, 'Native XML user group export', 'lib.pkp.plugins.importexport.users.filter.UserGroupNativeXmlFilter', 0, 0, 0),
(36, 36, 0, 'Native XML user group import', 'lib.pkp.plugins.importexport.users.filter.NativeXmlUserGroupFilter', 0, 0, 0),
(37, 37, 0, 'ArticlePubMedXmlFilter', 'plugins.importexport.pubmed.filter.ArticlePubMedXmlFilter', 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `filter_groups`
--

CREATE TABLE `filter_groups` (
  `filter_group_id` bigint(20) NOT NULL,
  `symbolic` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `input_type` varchar(255) DEFAULT NULL,
  `output_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `filter_groups`
--

INSERT INTO `filter_groups` (`filter_group_id`, `symbolic`, `display_name`, `description`, `input_type`, `output_type`) VALUES
(1, 'mods34=>mods34-xml', 'plugins.metadata.mods34.mods34XmlOutput.displayName', 'plugins.metadata.mods34.mods34XmlOutput.description', 'metadata::plugins.metadata.mods34.schema.Mods34Schema(*)', 'xml::schema(lib/pkp/plugins/metadata/mods34/filter/mods34.xsd)'),
(4, 'article=>dc11', 'plugins.metadata.dc11.articleAdapter.displayName', 'plugins.metadata.dc11.articleAdapter.description', 'class::classes.submission.Submission', 'metadata::plugins.metadata.dc11.schema.Dc11Schema(ARTICLE)'),
(5, 'issue=>datacite-xml', 'plugins.importexport.datacite.displayName', 'plugins.importexport.datacite.description', 'class::classes.issue.Issue', 'xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),
(6, 'article=>datacite-xml', 'plugins.importexport.datacite.displayName', 'plugins.importexport.datacite.description', 'class::classes.submission.Submission', 'xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),
(7, 'galley=>datacite-xml', 'plugins.importexport.datacite.displayName', 'plugins.importexport.datacite.description', 'class::classes.article.ArticleGalley', 'xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),
(8, 'article=>doaj-xml', 'plugins.importexport.doaj.displayName', 'plugins.importexport.doaj.description', 'class::classes.submission.Submission[]', 'xml::schema(plugins/importexport/doaj/doajArticles.xsd)'),
(9, 'article=>doaj-json', 'plugins.importexport.doaj.displayName', 'plugins.importexport.doaj.description', 'class::classes.submission.Submission', 'primitive::string'),
(13, 'article=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::classes.submission.Submission[]', 'xml::schema(plugins/importexport/native/native.xsd)'),
(14, 'native-xml=>article', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::classes.submission.Submission[]'),
(15, 'issue=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::classes.issue.Issue[]', 'xml::schema(plugins/importexport/native/native.xsd)'),
(16, 'native-xml=>issue', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::classes.issue.Issue[]'),
(17, 'issuegalley=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::classes.issue.IssueGalley[]', 'xml::schema(plugins/importexport/native/native.xsd)'),
(18, 'native-xml=>issuegalley', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::classes.issue.IssueGalley[]'),
(19, 'author=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::classes.article.Author[]', 'xml::schema(plugins/importexport/native/native.xsd)'),
(20, 'native-xml=>author', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::classes.article.Author[]'),
(21, 'SubmissionFile=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::lib.pkp.classes.submission.SubmissionFile', 'xml::schema(plugins/importexport/native/native.xsd)'),
(22, 'SubmissionArtworkFile=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::lib.pkp.classes.submission.SubmissionArtworkFile', 'xml::schema(plugins/importexport/native/native.xsd)'),
(23, 'SupplementaryFile=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::lib.pkp.classes.submission.SupplementaryFile', 'xml::schema(plugins/importexport/native/native.xsd)'),
(24, 'native-xml=>SubmissionFile', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::lib.pkp.classes.submission.SubmissionFile'),
(25, 'native-xml=>SubmissionArtworkFile', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::lib.pkp.classes.submission.SubmissionArtworkFile'),
(26, 'native-xml=>SupplementaryFile', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::lib.pkp.classes.submission.SupplementaryFile'),
(27, 'article-galley=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::classes.article.ArticleGalley', 'xml::schema(plugins/importexport/native/native.xsd)'),
(28, 'native-xml=>ArticleGalley', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::classes.article.ArticleGalley[]'),
(29, 'publication=>native-xml', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'class::classes.publication.Publication', 'xml::schema(plugins/importexport/native/native.xsd)'),
(30, 'native-xml=>Publication', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(plugins/importexport/native/native.xsd)', 'class::classes.publication.Publication'),
(31, 'issue=>crossref-xml', 'plugins.importexport.crossref.displayName', 'plugins.importexport.crossref.description', 'class::classes.issue.Issue[]', 'xml::schema(https://www.crossref.org/schemas/crossref4.3.6.xsd)'),
(32, 'article=>crossref-xml', 'plugins.importexport.crossref.displayName', 'plugins.importexport.crossref.description', 'class::classes.submission.Submission[]', 'xml::schema(https://www.crossref.org/schemas/crossref4.3.6.xsd)'),
(33, 'user=>user-xml', 'plugins.importexport.users.displayName', 'plugins.importexport.users.description', 'class::lib.pkp.classes.user.User[]', 'xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)'),
(34, 'user-xml=>user', 'plugins.importexport.users.displayName', 'plugins.importexport.users.description', 'xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)', 'class::classes.users.User[]'),
(35, 'usergroup=>user-xml', 'plugins.importexport.users.displayName', 'plugins.importexport.users.description', 'class::lib.pkp.classes.security.UserGroup[]', 'xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)'),
(36, 'user-xml=>usergroup', 'plugins.importexport.native.displayName', 'plugins.importexport.native.description', 'xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)', 'class::lib.pkp.classes.security.UserGroup[]'),
(37, 'article=>pubmed-xml', 'plugins.importexport.pubmed.displayName', 'plugins.importexport.pubmed.description', 'class::classes.submission.Submission[]', 'xml::dtd');

-- --------------------------------------------------------

--
-- Структура таблицы `filter_settings`
--

CREATE TABLE `filter_settings` (
  `filter_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `genres`
--

CREATE TABLE `genres` (
  `genre_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `seq` bigint(20) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  `category` bigint(20) NOT NULL DEFAULT '1',
  `dependent` tinyint(4) NOT NULL DEFAULT '0',
  `supplementary` smallint(6) NOT NULL DEFAULT '0',
  `entry_key` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `genres`
--

INSERT INTO `genres` (`genre_id`, `context_id`, `seq`, `enabled`, `category`, `dependent`, `supplementary`, `entry_key`) VALUES
(1, 1, 0, 1, 1, 0, 0, 'SUBMISSION'),
(2, 1, 1, 1, 3, 0, 1, 'RESEARCHINSTRUMENT'),
(3, 1, 2, 1, 3, 0, 1, 'RESEARCHMATERIALS'),
(4, 1, 3, 1, 3, 0, 1, 'RESEARCHRESULTS'),
(5, 1, 4, 1, 3, 0, 1, 'TRANSCRIPTS'),
(6, 1, 5, 1, 3, 0, 1, 'DATAANALYSIS'),
(7, 1, 6, 1, 3, 0, 1, 'DATASET'),
(8, 1, 7, 1, 3, 0, 1, 'SOURCETEXTS'),
(9, 1, 8, 1, 1, 1, 1, 'MULTIMEDIA'),
(10, 1, 9, 1, 2, 1, 0, 'IMAGE'),
(11, 1, 10, 1, 1, 1, 0, 'STYLE'),
(12, 1, 11, 1, 3, 0, 1, 'OTHER'),
(13, 2, 0, 1, 1, 0, 0, 'SUBMISSION'),
(14, 2, 1, 1, 3, 0, 1, 'RESEARCHINSTRUMENT'),
(15, 2, 2, 1, 3, 0, 1, 'RESEARCHMATERIALS'),
(16, 2, 3, 1, 3, 0, 1, 'RESEARCHRESULTS'),
(17, 2, 4, 1, 3, 0, 1, 'TRANSCRIPTS'),
(18, 2, 5, 1, 3, 0, 1, 'DATAANALYSIS'),
(19, 2, 6, 1, 3, 0, 1, 'DATASET'),
(20, 2, 7, 1, 3, 0, 1, 'SOURCETEXTS'),
(21, 2, 8, 1, 1, 1, 1, 'MULTIMEDIA'),
(22, 2, 9, 1, 2, 1, 0, 'IMAGE'),
(23, 2, 10, 1, 1, 1, 0, 'STYLE'),
(24, 2, 11, 1, 3, 0, 1, 'OTHER');

-- --------------------------------------------------------

--
-- Структура таблицы `genre_settings`
--

CREATE TABLE `genre_settings` (
  `genre_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `genre_settings`
--

INSERT INTO `genre_settings` (`genre_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, 'en_US', 'name', 'Article Text', 'string'),
(1, 'ru_RU', 'name', 'Текст статьи', 'string'),
(2, 'en_US', 'name', 'Research Instrument', 'string'),
(2, 'ru_RU', 'name', 'Инструмент исследования', 'string'),
(3, 'en_US', 'name', 'Research Materials', 'string'),
(3, 'ru_RU', 'name', 'Материалы исследования', 'string'),
(4, 'en_US', 'name', 'Research Results', 'string'),
(4, 'ru_RU', 'name', 'Результаты исследования', 'string'),
(5, 'en_US', 'name', 'Transcripts', 'string'),
(5, 'ru_RU', 'name', 'Транскрипты', 'string'),
(6, 'en_US', 'name', 'Data Analysis', 'string'),
(6, 'ru_RU', 'name', 'Анализ данных', 'string'),
(7, 'en_US', 'name', 'Data Set', 'string'),
(7, 'ru_RU', 'name', 'Набор данных', 'string'),
(8, 'en_US', 'name', 'Source Texts', 'string'),
(8, 'ru_RU', 'name', 'Исходные тексты', 'string'),
(9, 'en_US', 'name', 'Multimedia', 'string'),
(9, 'ru_RU', 'name', 'Мультимедиа', 'string'),
(10, 'en_US', 'name', 'Image', 'string'),
(10, 'ru_RU', 'name', 'Изображение', 'string'),
(11, 'en_US', 'name', 'HTML Stylesheet', 'string'),
(11, 'ru_RU', 'name', 'Таблица стилей HTML', 'string'),
(12, 'en_US', 'name', 'Other', 'string'),
(12, 'ru_RU', 'name', 'Другое', 'string'),
(13, 'en_US', 'name', 'Article Text', 'string'),
(13, 'ru_RU', 'name', 'Текст статьи', 'string'),
(14, 'en_US', 'name', 'Research Instrument', 'string'),
(14, 'ru_RU', 'name', 'Инструмент исследования', 'string'),
(15, 'en_US', 'name', 'Research Materials', 'string'),
(15, 'ru_RU', 'name', 'Материалы исследования', 'string'),
(16, 'en_US', 'name', 'Research Results', 'string'),
(16, 'ru_RU', 'name', 'Результаты исследования', 'string'),
(17, 'en_US', 'name', 'Transcripts', 'string'),
(17, 'ru_RU', 'name', 'Транскрипты', 'string'),
(18, 'en_US', 'name', 'Data Analysis', 'string'),
(18, 'ru_RU', 'name', 'Анализ данных', 'string'),
(19, 'en_US', 'name', 'Data Set', 'string'),
(19, 'ru_RU', 'name', 'Набор данных', 'string'),
(20, 'en_US', 'name', 'Source Texts', 'string'),
(20, 'ru_RU', 'name', 'Исходные тексты', 'string'),
(21, 'en_US', 'name', 'Multimedia', 'string'),
(21, 'ru_RU', 'name', 'Мультимедиа', 'string'),
(22, 'en_US', 'name', 'Image', 'string'),
(22, 'ru_RU', 'name', 'Изображение', 'string'),
(23, 'en_US', 'name', 'HTML Stylesheet', 'string'),
(23, 'ru_RU', 'name', 'Таблица стилей HTML', 'string'),
(24, 'en_US', 'name', 'Other', 'string'),
(24, 'ru_RU', 'name', 'Другое', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `institutional_subscriptions`
--

CREATE TABLE `institutional_subscriptions` (
  `institutional_subscription_id` bigint(20) NOT NULL,
  `subscription_id` bigint(20) NOT NULL,
  `institution_name` varchar(255) NOT NULL,
  `mailing_address` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `institutional_subscription_ip`
--

CREATE TABLE `institutional_subscription_ip` (
  `institutional_subscription_ip_id` bigint(20) NOT NULL,
  `subscription_id` bigint(20) NOT NULL,
  `ip_string` varchar(40) NOT NULL,
  `ip_start` bigint(20) NOT NULL,
  `ip_end` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `issues`
--

CREATE TABLE `issues` (
  `issue_id` bigint(20) NOT NULL,
  `journal_id` bigint(20) NOT NULL,
  `volume` smallint(6) DEFAULT NULL,
  `number` varchar(40) DEFAULT NULL,
  `year` smallint(6) DEFAULT NULL,
  `published` tinyint(4) NOT NULL DEFAULT '0',
  `current` tinyint(4) NOT NULL DEFAULT '0',
  `date_published` datetime DEFAULT NULL,
  `date_notified` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `access_status` tinyint(4) NOT NULL DEFAULT '1',
  `open_access_date` datetime DEFAULT NULL,
  `show_volume` tinyint(4) NOT NULL DEFAULT '0',
  `show_number` tinyint(4) NOT NULL DEFAULT '0',
  `show_year` tinyint(4) NOT NULL DEFAULT '0',
  `show_title` tinyint(4) NOT NULL DEFAULT '0',
  `style_file_name` varchar(90) DEFAULT NULL,
  `original_style_file_name` varchar(255) DEFAULT NULL,
  `url_path` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `issues`
--

INSERT INTO `issues` (`issue_id`, `journal_id`, `volume`, `number`, `year`, `published`, `current`, `date_published`, `date_notified`, `last_modified`, `access_status`, `open_access_date`, `show_volume`, `show_number`, `show_year`, `show_title`, `style_file_name`, `original_style_file_name`, `url_path`) VALUES
(1, 1, 18, '1', 2020, 0, 0, NULL, NULL, '2020-04-22 11:49:54', 1, NULL, 1, 1, 1, 1, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Структура таблицы `issue_files`
--

CREATE TABLE `issue_files` (
  `file_id` bigint(20) NOT NULL,
  `issue_id` bigint(20) NOT NULL,
  `file_name` varchar(90) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `content_type` bigint(20) NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `issue_galleys`
--

CREATE TABLE `issue_galleys` (
  `galley_id` bigint(20) NOT NULL,
  `locale` varchar(14) DEFAULT NULL,
  `issue_id` bigint(20) NOT NULL,
  `file_id` bigint(20) NOT NULL,
  `label` varchar(32) DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `url_path` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `issue_galley_settings`
--

CREATE TABLE `issue_galley_settings` (
  `galley_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `issue_settings`
--

CREATE TABLE `issue_settings` (
  `issue_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `issue_settings`
--

INSERT INTO `issue_settings` (`issue_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, 'ru_RU', 'description', '', 'string'),
(1, 'ru_RU', 'title', 'РЖБ №1, 2020', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `item_views`
--

CREATE TABLE `item_views` (
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_last_viewed` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `item_views`
--

INSERT INTO `item_views` (`assoc_type`, `assoc_id`, `user_id`, `date_last_viewed`) VALUES
(516, 1, 2, '2020-04-21 10:26:31'),
(516, 2, 4, '2021-05-06 14:38:57');

-- --------------------------------------------------------

--
-- Структура таблицы `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `journals`
--

CREATE TABLE `journals` (
  `journal_id` bigint(20) NOT NULL,
  `path` varchar(32) NOT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `primary_locale` varchar(14) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `journals`
--

INSERT INTO `journals` (`journal_id`, `path`, `seq`, `primary_locale`, `enabled`) VALUES
(1, 'russian_journal_of_pain', 3, 'ru_RU', 0),
(2, 'prb', 1, 'ru_RU', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `journal_settings`
--

CREATE TABLE `journal_settings` (
  `journal_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `journal_settings`
--

INSERT INTO `journal_settings` (`journal_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, '', 'agencies', 'request', NULL),
(1, '', 'citations', 'request', NULL),
(1, '', 'copyrightYearBasis', 'issue', NULL),
(1, '', 'coverage', 'enable', NULL),
(1, '', 'defaultReviewMode', '2', NULL),
(1, '', 'disciplines', 'request', NULL),
(1, '', 'emailSignature', '<br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>', NULL),
(1, '', 'enableOai', '0', NULL),
(1, '', 'enablePublisherId', '[\"publication\"]', NULL),
(1, '', 'itemsPerPage', '25', NULL),
(1, '', 'keywords', 'request', NULL),
(1, '', 'languages', 'request', NULL),
(1, '', 'membershipFee', '0', NULL),
(1, '', 'numPageLinks', '10', NULL),
(1, '', 'numWeeksPerResponse', '4', NULL),
(1, '', 'numWeeksPerReview', '4', NULL),
(1, '', 'onlineIssn', '2618-9860', NULL),
(1, '', 'printIssn', '2219-5297', NULL),
(1, '', 'publicationFee', '0', NULL),
(1, '', 'publisherInstitution', 'Издательство \"Медиа Сфера\"', NULL),
(1, '', 'publishingMode', '2', NULL),
(1, '', 'purchaseArticleFee', '0', NULL),
(1, '', 'restrictReviewerFileAccess', '1', NULL),
(1, '', 'reviewerAccessKeysEnabled', '1', NULL),
(1, '', 'rights', '0', NULL),
(1, '', 'source', '0', NULL),
(1, '', 'subjects', 'request', NULL),
(1, '', 'supportedFormLocales', '[\"ru_RU\"]', 'object'),
(1, '', 'supportedLocales', '[\"en_US\",\"ru_RU\"]', NULL),
(1, '', 'supportedSubmissionLocales', '[\"ru_RU\"]', 'object'),
(1, '', 'themePluginPath', 'default', NULL),
(1, '', 'type', 'request', NULL),
(1, 'en_US', 'about', '<p><strong>Founder:</strong></p>\n<p><a href=\"https://painrussia.ru/\" target=\"_blank\" rel=\"noopener\"><img style=\"margin-right: 10px;\" src=\"https://ojs-msph.ru/public/site/images/vllukin/logo-pr.png\" alt=\" Russian Association for the Study of Pain (Moscow, Russia)\" width=\"70\" height=\"64\" /></a>Russian Association for the Study of Pain (Moscow, Russia)</p>\n<p><strong>Language of publication:</strong></p>\n<ul>\n<li><strong>metadata - in Russian and English,</strong></li>\n<li><strong>articles - in Russian,</strong></li>\n<li><strong>selected articles in electronic form - in English.</strong></li>\n</ul>\n<p><em>Subscription distribution model</em>: articles on the site go to open access one year after publication.</p>\n<p>The journal was founded in Founded in 2010. Previously published under the title \"Pain\" from 2003 to 2009.</p>\n<p>Since 2020, the magazine has been published by Media Sphere Publishing House.</p>\n<p>It publishes articles of authors-applicants of a scientific degree of candidate of medical Sciences. The journal is dedicated to the problem of pain, and covers many research areas related to the physiology and pathophysiology of pain, methods of assessment and diagnosis of pain, features of clinic nociceptive, neuropathic and psychogenic pain syndromes and methods of treatment.</p>\n<p>The articles reflected the most current ideas on the pathogenesis of pain syndromes, the clinical picture, modern methods of drug and non-drug therapy, prevention and rehabilitation of patients with various forms of chronic pain. Regularly published scientific literature reviews and lectures on the problem of pain. All articles are accompanied by a bibliography with full citation of the source.</p>\n<p>The journal is included in the list of the leading peer-reviewed journals and editions of the Higher Attestation Commission under the Ministry of Education and Science of the Russian Federation, in which scientific results of dissertations for the degree of Candidate of Science and Doctor of Science should be published. Included in the RSCI database.</p>\n<p><strong>The main sections of the magazine</strong></p>\n<ul>\n<li>Lecture</li>\n<li>Original article</li>\n<li>Clinical Case Description</li>\n<li>Overview</li>\n<li>Review of Foreign Literature</li>\n<li>Organization Algological Care</li>\n<li>Reviews</li>\n</ul>\n<p>Fee for publication of articles is not charged. Each received article is registered and will be considered after peer review to the editorial Board meeting, which decided the question of its publication.</p>\n<p><strong>Head Edited by</strong> – Viktoriya V. Charechanskaya</p>\n<p><strong>A4<br />Frequency - 4 times a year</strong></p>\n<p><strong>About journal:</strong></p>\n<p><a href=\"https://elibrary.ru/title_about.asp?id=32168\" target=\"_blank\" rel=\"noopener\"><img src=\"https://ojs-msph.ru/public/site/images/vllukin/-elib-0.jpg\" alt=\"eLibrary.ru\" width=\"180\" height=\"57\" /></a></p>\n<p><strong>Russian Science Citation Index: <a href=\"https://elibrary.ru/title_about.asp?id=32168\" target=\"_blank\" rel=\"noopener\">https://elibrary.ru/title_about.asp?id=32168</a></strong></p>', NULL),
(1, 'en_US', 'acronym', 'RusPain', NULL),
(1, 'en_US', 'description', '<p>The journal was founded in Founded in 2010. Previously published under the title \"Pain\" from 2003 to 2009.</p>\n<p>Since 2020, the magazine has been published by Media Sphere Publishing House.</p>\n<p>It publishes articles of authors-applicants of a scientific degree of candidate of medical Sciences. The journal is dedicated to the problem of pain, and covers many research areas related to the physiology and pathophysiology of pain, methods of assessment and diagnosis of pain, features of clinic nociceptive, neuropathic and psychogenic pain syndromes and methods of treatment.</p>\n<p>The articles reflected the most current ideas on the pathogenesis of pain syndromes, the clinical picture, modern methods of drug and non-drug therapy, prevention and rehabilitation of patients with various forms of chronic pain. Regularly published scientific literature reviews and lectures on the problem of pain. All articles are accompanied by a bibliography with full citation of the source.</p>\n<p>The journal is included in the list of the leading peer-reviewed journals and editions of the Higher Attestation Commission under the Ministry of Education and Science of the Russian Federation, in which scientific results of dissertations for the degree of Candidate of Science and Doctor of Science should be published. Included in the RSCI database.</p>\n<p><strong>The main sections of the magazine</strong></p>\n<ul>\n<li>Lecture</li>\n<li>Original article</li>\n<li>Clinical Case Description</li>\n<li>Overview</li>\n<li>Review of Foreign Literature</li>\n<li>Organization Algological Care</li>\n<li>Reviews</li>\n</ul>\n<p>Fee for publication of articles is not charged. Each received article is registered and will be considered after peer review to the editorial Board meeting, which decided the question of its publication.</p>', NULL),
(1, 'en_US', 'editorialTeam', '<h3>Editors</h3>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/239/preview/%D0%9A%D1%83%D0%BA%D1%83%D1%88%D0%BA%D0%B8%D0%BD%D0%9C%D0%9B.jpg?1584012228\" alt=\"%d0%9a%d1%83%d0%ba%d1%83%d1%88%d0%ba%d0%b8%d0%bd%d0%9c%d0%9b\" />\n<h3>Kukushkin Mikhail L.</h3>\n</div>\n<h4>Editor-in-Chief, Prof., MD, PhD</h4>\n<p>- Head of the Laboratory of Fundamental and Applied Pain Problems, Research Institute of General Pathology and Pathophysiology (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=2810-1998\" target=\"_blank\" rel=\"noopener\">2810-1998</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7003806134\" target=\"_blank\" rel=\"noopener\">7003806134</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-9406-5846\" target=\"_blank\" rel=\"noopener\">0000-0002-9406-5846</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/242/preview/%D0%AF%D1%85%D0%BD%D0%BE%D0%9D.%D0%9D.jpg?1584020899\" alt=\"%d0%af%d1%85%d0%bd%d0%be%d0%9d.%d0%9d\" />\n<h3>Yakhno Nikolay N.</h3>\n</div>\n<h4>Chairman of the Editorial Advisory Board, Member of the RAS, Prof., MD, PhD</h4>\n<p>- Head of the Research Department of Neurology, I.M. Sechenov First Moscow State Medical University, President of the Russian Society for the Study of Pain (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=6438-3370\" target=\"_blank\" rel=\"noopener\">6438-3370</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7004210424\" target=\"_blank\" rel=\"noopener\">7004210424</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-8255-5645\" target=\"_blank\" rel=\"noopener\">0000-0002-8255-5645<br style=\"margin-right: 10px;\" /></a>ResearcherID: <a href=\"http://www.researcherid.com/rid/L-6615-2018\" target=\"_blank\" rel=\"noopener\">L-6615-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/243/preview/%D0%94%D0%B0%D0%B2%D1%8B%D0%B4%D0%BE%D0%B2%D0%9E.%D0%A1.jpg?1584021553\" alt=\"%d0%94%d0%b0%d0%b2%d1%8b%d0%b4%d0%be%d0%b2%d0%9e.%d0%a1\" />\n<h3>Davydov Oleg S.</h3>\n</div>\n<h4>Executive Secretary, PhD</h4>\n<p>- Leading researcher at the Laboratory of Fundamental and Applied Pain Problems, Research Institute of General Pathology and Pathophysiology (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=6861-2707\" target=\"_blank\" rel=\"noopener\">6861-2707</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=55759482400\" target=\"_blank\" rel=\"noopener\">55759482400</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-3252-4311\" target=\"_blank\" rel=\"noopener\">0000-0003-3252-4311</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/P-5361-2017\" target=\"_blank\" rel=\"noopener\">P-5361-2017</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/244/preview/%D0%9C%D0%B5%D0%B4%D0%B2%D0%B5%D0%B4%D0%B5%D0%B2%D0%B0%D0%9B.%D0%90.jpg?1584022539\" alt=\"%d0%9c%d0%b5%d0%b4%d0%b2%d0%b5%d0%b4%d0%b5%d0%b2%d0%b0%d0%9b.%d0%90\" />\n<h3>Medvedeva Ludmila A.</h3>\n</div>\n<h4>Executive Secretary, MD, PhD</h4>\n<p>- Chief Researcher, Clinic for the Study and Treatment of Pain, B.V. Petrovsky Russian Scientific Center of Surgery (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=9850-6910\" target=\"_blank\" rel=\"noopener\">9850-6910</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=56593537900\" target=\"_blank\" rel=\"noopener\">56593537900</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-4191-7224\" target=\"_blank\" rel=\"noopener\">0000-0002-4191-7224</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/I-5578-2017\" target=\"_blank\" rel=\"noopener\">I-5578-2017</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/245/preview/%D0%A7%D1%83%D1%80%D1%8E%D0%BA%D0%B0%D0%BD%D0%BE%D0%B2%D0%9C.%D0%92.jpg?1584022991\" alt=\"%d0%a7%d1%83%d1%80%d1%8e%d0%ba%d0%b0%d0%bd%d0%be%d0%b2%d0%9c.%d0%92\" />\n<h3>Churyukanov Maksim V.</h3>\n</div>\n<h4>Executive Secretary, Assoc. Prof., PhD</h4>\n<p>- Department of Nervous Diseases and Neurosurgery, I.M. Sechenov First Moscow State Medical University; Senior Researcher, Clinic for Pain Research and Treatment, B.V. Petrovsky Russian Research Center of Surgery; Member of the Board of the European Pain Federation EFIC (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=7968-2812\" target=\"_blank\" rel=\"noopener\">7968-2812</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=15047727300\" target=\"_blank\" rel=\"noopener\">15047727300</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-6542-1963\" target=\"_blank\" rel=\"noopener\">0000-0001-6542-1963</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/G-9255-2018\" target=\"_blank\" rel=\"noopener\">G-9255-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/240/preview/%D0%90%D0%B1%D1%83%D0%B7%D0%B0%D1%80%D0%BE%D0%B2%D0%B0%D0%93.%D0%A0.jpg?1584013038\" alt=\"%d0%90%d0%b1%d1%83%d0%b7%d0%b0%d1%80%d0%be%d0%b2%d0%b0%d0%93.%d0%a0\" />\n<h3>Abuzarova Guzal R.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Department of Oncology and Palliative Care, Russian Medical Academy of Continuing Professional Education; Head of the Center for Palliative Care for Cancer Patients, P.A. Herzen Moscow Research Cancer Institute (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=9876-4680\" target=\"_blank\" rel=\"noopener\">9876-4680</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6506455155\" target=\"_blank\" rel=\"noopener\">6506455155</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-6146-2706\" target=\"_blank\" rel=\"noopener\">0000-0002-6146-2706</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/AAA-1500-2020\" target=\"_blank\" rel=\"noopener\">AAA-1500-2020</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/241/preview/%D0%90%D0%BC%D0%B5%D0%BB%D0%B8%D0%BD%D0%90.%D0%92.jpg?1584016456\" alt=\"%d0%90%d0%bc%d0%b5%d0%bb%d0%b8%d0%bd%d0%90.%d0%92\" />\n<h3>Amelin Aleksandr V.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Department of Neurology, I.P. Pavlov St. Petersburg State Medical University; Head of the Laboratory of Neurophysiology and Pain Pharmacology, A.V. Waldman Institute of Pharmacology (St. Petersburg, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=2402-7452\" target=\"_blank\" rel=\"noopener\">2402-7452</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7007120162\" target=\"_blank\" rel=\"noopener\">7007120162</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/246/preview/%D0%91%D0%B0%D0%BB%D1%8F%D0%B7%D0%B8%D0%BD%D0%92.%D0%90.jpg?1584023859\" alt=\"%d0%91%d0%b0%d0%bb%d1%8f%d0%b7%d0%b8%d0%bd%d0%92.%d0%90\" />\n<h3>Balyazin Viktor A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Neurology and Neurosurgery, Rostov State Medical University, Vice-President of the Russian Society for the Study of Pain (Rostov-on-Don, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=7054-9452\" target=\"_blank\" rel=\"noopener\">7054-9452</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6506095562\" target=\"_blank\" rel=\"noopener\">6506095562</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-8381-8876\" target=\"_blank\" rel=\"noopener\">0000-0001-8381-8876</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/AAG-6725-2020\" target=\"_blank\" rel=\"noopener\">AAG-6725-2020</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/247/preview/%D0%91%D0%B5%D0%BB%D1%8F%D0%B5%D0%B2%D0%90.%D0%A4.jpg?1584024469\" alt=\"%d0%91%d0%b5%d0%bb%d1%8f%d0%b5%d0%b2%d0%90.%d0%a4\" />\n<h3>Belyaev Anatoliy F.</h3>\n</div>\n<h4>Member of the Editorial Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Restorative Medicine, Vladivostok State Medical University (Vladivostok, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=7144-4831\" target=\"_blank\" rel=\"noopener\">7144-4831</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/248/preview/Bouhassira_Didier.jpg?1584024886\" alt=\"Bouhassira didier\" />\n<h3>Bouhassira Didier</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD</h4>\n<p>- Centre for the Study and Treatment of Pain, University of Versailles Saint Quentin (Versailles, France).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7006708423\" target=\"_blank\" rel=\"noopener\">7006708423</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-6446-8719\" target=\"_blank\" rel=\"noopener\">0000-0001-6446-8719</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/Y-8403-2018\" target=\"_blank\" rel=\"noopener\">Y-8403-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/249/preview/%D0%92%D0%B5%D0%BB%D1%8C%D1%82%D0%B8%D1%89%D0%B5%D0%B2%D0%94.%D0%AE.jpg?1584025337\" alt=\"%d0%92%d0%b5%d0%bb%d1%8c%d1%82%d0%b8%d1%89%d0%b5%d0%b2%d0%94.%d0%ae\" />\n<h3>Veltishchev Dmitriy Yu.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Stress Disorders, Moscow Research Institute of Psychiatry - branch of the Scientific Center of Mental Health (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=2454-7931\" target=\"_blank\" rel=\"noopener\">2454-7931</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=36700770300\" target=\"_blank\" rel=\"noopener\">36700770300</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-5210-2605\" target=\"_blank\" rel=\"noopener\">0000-0001-5210-2605</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/C-6188-2013\" target=\"_blank\" rel=\"noopener\">C-6188-2013</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/250/preview/%D0%94%D1%80%D0%B5%D0%B2%D0%B0%D0%BB%D1%8C%D0%9E.%D0%9D.jpg?1584025699\" alt=\"%d0%94%d1%80%d0%b5%d0%b2%d0%b0%d0%bb%d1%8c%d0%9e.%d0%9d\" />\n<h3>Dreval Oleg N.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Neurosurgery, Russian Medical Academy of Continuing Professional Education (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=8190-3431\" target=\"_blank\" rel=\"noopener\">8190-3431</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6508261842\" target=\"_blank\" rel=\"noopener\">6508261842</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-8944-9837\" target=\"_blank\" rel=\"noopener\">0000-0002-8944-9837</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/251/preview/%D0%95%D0%B2%D0%B7%D0%B8%D0%BA%D0%BE%D0%B2%D0%93.%D0%AE.jpg?1584087655\" alt=\"%d0%95%d0%b2%d0%b7%d0%b8%d0%ba%d0%be%d0%b2%d0%93.%d0%ae\" />\n<h3>Evzikov Grigoriy Yu.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Professor of the Department of Nervous Diseases and Neurosurgery, I.M. Sechenova First Moscow State Medical University (Sechenov University) (Moscow, Russia).</p>\n<p>RSCI AuthorID: <a href=\"http://elibrary.ru/author_profile.asp?id=228859\" target=\"_blank\" rel=\"noopener\">228859</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=57205219900\" target=\"_blank\" rel=\"noopener\">57205219900</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-6715-6021\" target=\"_blank\" rel=\"noopener\">0000-0002-6715-6021</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/V-8510-2018\" target=\"_blank\" rel=\"noopener\">V-8510-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/252/preview/%D0%95%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%BA%D0%BE%D0%90.%D0%90.jpg?1584088119\" alt=\"%d0%95%d1%80%d0%b5%d0%bc%d0%b5%d0%bd%d0%ba%d0%be%d0%90.%d0%90\" />\n<h3>Eremenko Aleksandr A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Corr. Member of the RAS, Prof., MD, PhD</h4>\n<p>- Honored Scientist of Russia, Head of the Department of Cardio Animation and Intensive Care, B.V. Petrovsky Russian Scientific Center of Surgery (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=5661-3290\" target=\"_blank\" rel=\"noopener\">5661-3290</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7102260042\" target=\"_blank\" rel=\"noopener\">7102260042</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-5809-8563\" target=\"_blank\" rel=\"noopener\">0000-0001-5809-8563</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/B-3152-2018\" target=\"_blank\" rel=\"noopener\">B-3152-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/253/preview/%D0%97%D0%B0%D0%B3%D0%BE%D1%80%D1%83%D0%BB%D1%8C%D0%BA%D0%BE%D0%9E.%D0%98.jpg?1584089199\" alt=\"%d0%97%d0%b0%d0%b3%d0%be%d1%80%d1%83%d0%bb%d1%8c%d0%ba%d0%be%d0%9e.%d0%98\" />\n<h3>Zagorulko Oleg I.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Clinic for the Study and Treatment of Pain, B.V. Petrovsky Russian Scientific Center for Surgery (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=8208-4501\" target=\"_blank\" rel=\"noopener\">8208-4501</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=35773977900\" target=\"_blank\" rel=\"noopener\">35773977900</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-2713-9577\" target=\"_blank\" rel=\"noopener\">0000-0002-2713-9577</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/J-8552-2017\" target=\"_blank\" rel=\"noopener\">J-8552-2017</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/254/preview/%D0%9A%D0%B0%D1%80%D0%B0%D1%82%D0%B5%D0%B5%D0%B2%D0%90.%D0%95.jpg?1584089688\" alt=\"%d0%9a%d0%b0%d1%80%d0%b0%d1%82%d0%b5%d0%b5%d0%b2%d0%90.%d0%95\" />\n<h3>Karateev Andrey E.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, MD, PhD</h4>\n<p>- Head of the Laboratory of Pain Pathophysiology and Polymorphism of Skeletal-Muscular Diseases, V.A. Nasonova Research Institute of Rheumatology (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=2795-4080\" target=\"_blank\" rel=\"noopener\">2795-4080</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6603615916\" target=\"_blank\" rel=\"noopener\">6603615916</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-1391-0711\" target=\"_blank\" rel=\"noopener\">0000-0002-1391-0711</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/AAA-3367-2019\" target=\"_blank\" rel=\"noopener\">AAA-3367-2019</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/255/preview/%D0%9A%D1%80%D1%83%D0%BF%D0%B8%D0%BD%D0%B0%D0%9D.%D0%90.jpg?1586001378\" alt=\"%d0%9a%d1%80%d1%83%d0%bf%d0%b8%d0%bd%d0%b0%d0%9d.%d0%90\" />\n<h3>Krupina Nataliya A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Docror of Biology, PhD</h4>\n<p>- Chief Researcher, Nervous System Pathophysiology Laboratory, Research Institute of General Pathology and Pathophysiology (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=7177-8156\" target=\"_blank\" rel=\"noopener\">7177-8156</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7006787764\" target=\"_blank\" rel=\"noopener\">7006787764</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-2462-899X\" target=\"_blank\" rel=\"noopener\">0000-0002-2462-899X</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/M-3467-2014\" target=\"_blank\" rel=\"noopener\">M-3467-2014</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/256/preview/%D0%9C%D0%B0%D0%B9%D1%87%D1%83%D0%BA%D0%95.%D0%AE.jpg?1584091433\" alt=\"%d0%9c%d0%b0%d0%b9%d1%87%d1%83%d0%ba%d0%95.%d0%ae\" />\n<h3>Maychuk Elena Yu.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Internal Diseases No. 1, A.I. Evdokimov Moscow State Medical and Dental University (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=5532-7898\" target=\"_blank\" rel=\"noopener\">5532-7898</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7801401443\" target=\"_blank\" rel=\"noopener\">7801401443</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/257/preview/Mouraux_Andr%C3%A9.jpg?1584091678\" alt=\"Mouraux andr%c3%a9\" />\n<h3>Mouraux André</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD</h4>\n<p>- Pain Research Group, Institute of Neuroscience (Brussels, Belgium).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6602503125\" target=\"_blank\" rel=\"noopener\">6602503125</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-1056-5980\" target=\"_blank\" rel=\"noopener\">0000-0003-1056-5980</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/F-3724-2012\" target=\"_blank\" rel=\"noopener\">F-3724-2012</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/258/preview/%D0%9D%D0%B0%D1%81%D0%BE%D0%BD%D0%BE%D0%B2%D0%95.%D0%9B.jpg?1584092762\" alt=\"%d0%9d%d0%b0%d1%81%d0%be%d0%bd%d0%be%d0%b2%d0%95.%d0%9b\" />\n<h3>Nasonov Evgeniy L.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Member of the RAS, Prof., MD, PhD</h4>\n<p>- Scientific Director, V.A. Nasonova Rheumatology Research Institute (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=5162-6484\" target=\"_blank\" rel=\"noopener\">5162-6484</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7102614711\" target=\"_blank\" rel=\"noopener\">7102614711</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/259/preview/%D0%9D%D0%B8%D0%BA%D0%BE%D0%B4%D0%B0%D0%92.%D0%92.jpg?1584093114\" alt=\"%d0%9d%d0%b8%d0%ba%d0%be%d0%b4%d0%b0%d0%92.%d0%92\" />\n<h3>Nikoda Vladimir V.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, MD, PhD</h4>\n<p>- Head of the general resuscitation department, B.V. Petrovsky Russian Scientific Center of Surgery (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=6176-3911\" target=\"_blank\" rel=\"noopener\">6176-3911</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6701698242\" target=\"_blank\" rel=\"noopener\">6701698242</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-9605-254X\" target=\"_blank\" rel=\"noopener\">0000-0001-9605-254X</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/O-3631-2016\" target=\"_blank\" rel=\"noopener\">O-3631-2016</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/260/preview/%D0%9D%D0%BE%D0%B2%D0%B8%D0%BA%D0%BE%D0%B2%D0%93.%D0%90.jpg?1584094526\" alt=\"%d0%9d%d0%be%d0%b2%d0%b8%d0%ba%d0%be%d0%b2%d0%93.%d0%90\" />\n<h3>Novikov Georgiy A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- President of the All-Russian public movement \"Medicine for Quality of Life\", Head of the Department of Palliative Medicine, A.I. Evdokimov Moscow State Medical and Dental University (Moscow, Russia).</p>\n<p>RSCI AuthorID: <a href=\"http://elibrary.ru/author_profile.asp?id=587031\" target=\"_blank\" rel=\"noopener\">587031</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7005070465\" target=\"_blank\" rel=\"noopener\">7005070465</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/261/preview/%D0%9E%D0%B2%D0%B5%D1%87%D0%BA%D0%B8%D0%BD%D0%90.%D0%9C.jpg?1584094836\" alt=\"%d0%9e%d0%b2%d0%b5%d1%87%d0%ba%d0%b8%d0%bd%d0%90.%d0%9c\" />\n<h3>Ovechkin Aleksey M.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Professor of the Department of Anesthesiology and Critical Care, I.M. Sechenov First Moscow State Medical University (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=1277-9220\" target=\"_blank\" rel=\"noopener\">1277-9220</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7003507291\" target=\"_blank\" rel=\"noopener\">7003507291</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-7756-7089\" target=\"_blank\" rel=\"noopener\">0000-0001-7756-7089</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/S-6607-2016\" target=\"_blank\" rel=\"noopener\">S-6607-2016</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/262/preview/Plaghki_Leon.jpg?1584095210\" alt=\"Plaghki leon\" />\n<h3>Plaghki Leon</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD</h4>\n<p>- Honorary Professor, Catholic University of Levin (Levin, Belgium).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7003667780\" target=\"_blank\" rel=\"noopener\">7003667780</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-7996-5272\" target=\"_blank\" rel=\"noopener\">0000-0002-7996-5272</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/263/preview/%D0%A0%D0%B0%D0%B1%D0%B8%D0%BD%D0%BE%D0%B2%D0%B8%D1%87%D0%A1.%D0%90.jpg?1584095579\" alt=\"%d0%a0%d0%b0%d0%b1%d0%b8%d0%bd%d0%be%d0%b2%d0%b8%d1%87%d0%a1.%d0%90\" />\n<h3>Rabinovich Solomon A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Pain Management in Dentistry, Evdokimov Moscow State Medical and Dental University (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=3231-2930\" target=\"_blank\" rel=\"noopener\">3231-2930</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=56498748100\" target=\"_blank\" rel=\"noopener\">56498748100</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-2756-1468\" target=\"_blank\" rel=\"noopener\">0000-0003-2756-1468</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/N-4350-2014\" target=\"_blank\" rel=\"noopener\">N-4350-2014</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/264/preview/%D0%A1%D0%BE%D0%BA%D0%BE%D0%B2%D0%95.%D0%9B.jpg?1584096139\" alt=\"%d0%a1%d0%be%d0%ba%d0%be%d0%b2%d0%95.%d0%9b\" />\n<h3>Sokov Evgeniy L.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Algology and Rehabilitation, Institute of Oriental Medicine, Russian Peoples\' Friendship University (Moscow, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=1953-3066\" target=\"_blank\" rel=\"noopener\">1953-3066</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6602341586\" target=\"_blank\" rel=\"noopener\">6602341586</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/265/preview/%D0%A1%D1%82%D1%80%D0%BE%D0%BA%D0%BE%D0%B2%D0%98.%D0%90.jpg?1584096498\" alt=\"%d0%a1%d1%82%d1%80%d0%be%d0%ba%d0%be%d0%b2%d0%98.%d0%90\" />\n<h3>Strokov Igor A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Assoc. Prof., PhD</h4>\n<p>- Associate Professor, Department of Nervous Diseases and Neurosurgery, Faculty of Medicine, I.M. Sechenov First Moscow State Medical University (Moscow, Russia).</p>\n<p>SPIN RSCi: <a href=\"http://elibrary.ru/author_profile.asp?spin=5262-8780\" target=\"_blank\" rel=\"noopener\">5262-8780</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6701743258\" target=\"_blank\" rel=\"noopener\">6701743258</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-6950-7166\" target=\"_blank\" rel=\"noopener\">0000-0001-6950-7166</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/266/preview/%D0%A2%D0%B0%D0%B1%D0%B5%D0%B5%D0%B2%D0%B0%D0%93.%D0%A0.jpg?1584098124\" alt=\"%d0%a2%d0%b0%d0%b1%d0%b5%d0%b5%d0%b2%d0%b0%d0%93.%d0%a0\" />\n<h3>Tabeyeva Gyuzyal R.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- President of the Russian Society for the Study of Headache, Professor of the Department of Nervous Diseases and Neurosurgery, I.M. Sechenov First Moscow State Medical University (Moscow, Russia).</p>\n<p> </p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/267/preview/%D0%A5%D0%B0%D0%B1%D0%B8%D1%80%D0%BE%D0%B2%D0%A4.%D0%90.jpg?1584098642\" alt=\"%d0%a5%d0%b0%d0%b1%d0%b8%d1%80%d0%be%d0%b2%d0%a4.%d0%90\" />\n<h3>Khabirov Farit A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Department of Vertebroneurology and Manual Therapy, Kazan State Medical Academy (Kazan, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=6015-3095\" target=\"_blank\" rel=\"noopener\">6015-3095</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6701631544\" target=\"_blank\" rel=\"noopener\">6701631544</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-2572-6970\" target=\"_blank\" rel=\"noopener\">0000-0002-2572-6970</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/268/preview/%D0%A8%D0%B8%D1%80%D0%BE%D0%BA%D0%BE%D0%B2%D0%92.%D0%90.jpg?1584100153\" alt=\"%d0%a8%d0%b8%d1%80%d0%be%d0%ba%d0%be%d0%b2%d0%92.%d0%90\" />\n<h3>Shirokov Vasiliy A.</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD, PhD</h4>\n<p>- Head of the Scientific Department of the Neurological Clinic, Ekaterinburg Medical and Scientific Center for Prevention and Health Protection of Industrial Workers (Yekaterinburg, Russia).</p>\n<p>SPIN RSCI: <a href=\"http://elibrary.ru/author_profile.asp?spin=8387-4080\" target=\"_blank\" rel=\"noopener\">8387-4080</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=57210118004\" target=\"_blank\" rel=\"noopener\">57210118004</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-1461-1761\" target=\"_blank\" rel=\"noopener\">0000-0003-1461-1761</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/269/preview/Ecclecston_Christopher.jpg?1586001441\" alt=\"Ecclecston christopher\" />\n<h3>Ecclecston Christopher</h3>\n</div>\n<h4>Member of the Editorial Advisory Board, Prof., MD</h4>\n<p>- Director, Centre for Pain Research, University of Bath (Bath, UK).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7004000686\" target=\"_blank\" rel=\"noopener\">7004000686</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-0698-1543\" target=\"_blank\" rel=\"noopener\">0000-0003-0698-1543</a></p>\n</div>', NULL),
(1, 'en_US', 'name', 'Russian Journal of Pain', NULL),
(1, 'ru_RU', 'about', '<p><strong>Учредитель:</strong></p>\n<p><a href=\"https://painrussia.ru/\" target=\"_blank\" rel=\"noopener\"><img style=\"margin-right: 10px;\" src=\"https://ojs-msph.ru/public/site/images/vllukin/logo-pr.png\" alt=\"Межрегиональная общественная организация «Российское общество по изучению боли» (Москва, Россия)\" width=\"70\" height=\"64\" /></a>Межрегиональная общественная организация «Российское общество по изучению боли» (Москва, Россия)</p>\n<p><strong>Язык издания:</strong></p>\n<ul>\n<li><strong>метаданные – на русском и английском,</strong></li>\n<li><strong>статьи – на русском,</strong></li>\n<li><strong>избранные статьи в электронном виде – на английском.</strong></li>\n</ul>\n<p><em>Модель распространения журнала: по подписке; статьи на сайте переходят в открытый доступ через год после публикации.</em></p>\n<p>Свидетельство о регистрации СМИ в Роскомнадзоре: <a href=\"https://rkn.gov.ru/mass-communications/reestr/media/?id=337645\" target=\"_blank\" rel=\"noopener\">ПИ № ФС 77-41802</a>.</p>\n<p>Основан в 2010 году. С 2003 по 2009 г. выходил под названием «Боль».</p>\n<p>C 2020 года издателем журнала стало издательство «Медиа Сфера».</p>\n<p>В каждом номере публикуются статьи авторов-соискателей ученой степени кандидата медицинских наук. Тематика журнала посвящена проблеме боли и охватывает многие научные направления, связанные с физиологией и патофизиологией боли, методами оценки и диагностики боли, особенностями клиники ноцицептивных, невропатических и дисфункциональных болевых синдромов и методами терапии.</p>\n<p>В статьях отражаются самые современные представления об этиопатогенезе болевых синдромов, клинической картине, современных методах лекарственной и немедикаментозной терапии, профилактике и реабилитации больных с различными формами хронических болей. Регулярно публикуются научные обзоры литературы и лекции по проблеме боли. Все статьи сопровождает библиография с полным цитированием источника.</p>\n<p>Журнал входит в перечень ведущих рецензируемых журналов и изданий ВАК при Министерстве образования и науки Российской Федерации, в которых должны быть опубликованы научные результаты диссертаций на соискание учёных степеней кандидата и доктора наук. Входит в базу данных РИНЦ.</p>\n<p><strong>Основные разделы журнала</strong></p>\n<ul>\n<li>Лекция</li>\n<li>Оригинальные статьи</li>\n<li>Описание клинического случая</li>\n<li>Обзор</li>\n<li>Обозрение зарубежной литературы</li>\n<li>Организация альгологической помощи</li>\n<li>Рецензии</li>\n</ul>\n<p>Плата за публикации статей не взимается. Каждая поступившая в редакцию статья регистрируется и рассматривается после рецензирования на заседании редакционной коллегии, на котором решается вопрос о ее публикации.</p>\n<p><strong>Заведующая редакцией</strong> – Чаречанская Виктория Викторовна</p>\n<p><strong>Формат А4<br />Периодичность – 4 раза в год</strong></p>\n<p><strong>Информация о журнале:</strong></p>\n<p><a href=\"https://elibrary.ru/title_about.asp?id=32168\" target=\"_blank\" rel=\"noopener\"><img src=\"https://ojs-msph.ru/public/site/images/vllukin/-elib-0.jpg\" alt=\"eLibrary.ru\" width=\"180\" height=\"57\" /></a><strong><br />На сайте Научной электронной библиотеки (РИНЦ):</strong> <strong><a href=\"https://elibrary.ru/title_about.asp?id=32168\" target=\"_blank\" rel=\"noopener\">https://elibrary.ru/title_about.asp?id=32168</a></strong> (все данные по импакт-фактору и другим показателям находятся в правом боковом меню - \"Анализ публикационной активности журнала\").</p>', NULL),
(1, 'ru_RU', 'acronym', 'РЖБ', NULL),
(1, 'ru_RU', 'authorInformation', 'Вы хотите отправить материал для публикации в этом журнале? Рекомендуем вам посмотреть раздел <a href=\"https://ojs-msph.ru/index.phprussian_journal_of_pain/about\">«О журнале»</a>, где вы сможете ознакомиться с правилами разделов журнала, а также с <a href=\"https://ojs-msph.ru/index.phprussian_journal_of_pain/about/submissions#authorGuidelines\">Руководством для автора</a>. Авторам нужно <a href=\"https://ojs-msph.ru/index.phprussian_journal_of_pain/user/register\">зарегистрироваться</a> в журнале перед отправкой материалов, или, если вы уже зарегистрированы, можно просто <a href=\"https://ojs-msph.ru/index.php/index/login\">войти</a> со своей учетной записью и начать процесс отправки, состоящий из пяти шагов.', NULL),
(1, 'ru_RU', 'clockssLicense', 'Этот журнал использует систему CLOCKSS для создания распределенной архивной системы между участвующими в этой системе библиотеками и разрешает этим библиотекам создавать постоянные архивы журнала в целях сохранения и восстановления. <a href=\"http://clockss.org/\">Подробнее...</a>', NULL),
(1, 'ru_RU', 'description', '<p>Основан в 2010 году. С 2003 по 2009 г. выходил под названием «Боль».</p>\n<p>C 2020 года издателем журнала стало издательство «Медиа Сфера».</p>\n<p>В каждом номере публикуются статьи авторов-соискателей ученой степени кандидата медицинских наук. Тематика журнала посвящена проблеме боли и охватывает многие научные направления, связанные с физиологией и патофизиологией боли, методами оценки и диагностики боли, особенностями клиники ноцицептивных, невропатических и дисфункциональных болевых синдромов и методами терапии.</p>\n<p>В статьях отражаются самые современные представления об этиопатогенезе болевых синдромов, клинической картине, современных методах лекарственной и немедикаментозной терапии, профилактике и реабилитации больных с различными формами хронических болей. Регулярно публикуются научные обзоры литературы и лекции по проблеме боли. Все статьи сопровождает библиография с полным цитированием источника.</p>\n<p>Журнал входит в перечень ведущих рецензируемых журналов и изданий ВАК при Министерстве образования и науки Российской Федерации, в которых должны быть опубликованы научные результаты диссертаций на соискание учёных степеней кандидата и доктора наук. Входит в базу данных РИНЦ.</p>\n<p><strong>Основные разделы журнала</strong></p>\n<ul>\n<li>Лекция</li>\n<li>Оригинальные статьи</li>\n<li>Описание клинического случая</li>\n<li>Обзор</li>\n<li>Обозрение зарубежной литературы</li>\n<li>Организация альгологической помощи</li>\n<li>Рецензии</li>\n</ul>\n<p>Плата за публикации статей не взимается. Каждая поступившая в редакцию статья регистрируется и рассматривается после рецензирования на заседании редакционной коллегии, на котором решается вопрос о ее публикации.</p>', NULL);
INSERT INTO `journal_settings` (`journal_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, 'ru_RU', 'editorialTeam', '<h3>Редакционная коллегия</h3>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/239/preview/%D0%9A%D1%83%D0%BA%D1%83%D1%88%D0%BA%D0%B8%D0%BD%D0%9C%D0%9B.jpg?1584012228\" alt=\"%d0%9a%d1%83%d0%ba%d1%83%d1%88%d0%ba%d0%b8%d0%bd%d0%9c%d0%9b\" />\n<h3>Кукушкин Михаил Львович</h3>\n<h4>Главный редактор, проф., д.м.н.</h4>\n<p>- заведующий лабораторией фундаментальных и прикладных проблем боли, ФГБНУ Научно-исследовательский институт общей патологии и патофизиологии (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=2810-1998\" target=\"_blank\" rel=\"noopener\">2810-1998</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7003806134\" target=\"_blank\" rel=\"noopener\">7003806134</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-9406-5846\" target=\"_blank\" rel=\"noopener\">0000-0002-9406-5846</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/242/preview/%D0%AF%D1%85%D0%BD%D0%BE%D0%9D.%D0%9D.jpg?1584020899\" alt=\"%d0%af%d1%85%d0%bd%d0%be%d0%9d.%d0%9d\" />\n<h3>Яхно Николай Николаевич</h3>\n</div>\n<h4>Председатель редакционного совета, акад. РАН, проф., д.м.н.</h4>\n<p>- заведующий научно-исследовательским отделом неврологии, ФГАОУ ВО Первый МГМУ имени И.М. Сеченова, Президент Российского общества по изучению боли (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=6438-3370\" target=\"_blank\" rel=\"noopener\">6438-3370</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7004210424\" target=\"_blank\" rel=\"noopener\">7004210424</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-8255-5645\" target=\"_blank\" rel=\"noopener\">0000-0002-8255-5645<br style=\"margin-right: 10px;\" /></a>ResearcherID: <a href=\"http://www.researcherid.com/rid/L-6615-2018\" target=\"_blank\" rel=\"noopener\">L-6615-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/243/preview/%D0%94%D0%B0%D0%B2%D1%8B%D0%B4%D0%BE%D0%B2%D0%9E.%D0%A1.jpg?1584021553\" alt=\"%d0%94%d0%b0%d0%b2%d1%8b%d0%b4%d0%be%d0%b2%d0%9e.%d0%a1\" />\n<h3>Давыдов Олег Сергеевич</h3>\n</div>\n<h4>Ответственный секретарь, к.м.н.</h4>\n<p>- ведущий научный сотрудник лаборатории фундаментальных и прикладных проблем боли, ФГБНУ Научно-исследовательский институт общей патологии и патофизиологии (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=6861-2707\" target=\"_blank\" rel=\"noopener\">6861-2707</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=55759482400\" target=\"_blank\" rel=\"noopener\">55759482400</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-3252-4311\" target=\"_blank\" rel=\"noopener\">0000-0003-3252-4311</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/P-5361-2017\" target=\"_blank\" rel=\"noopener\">P-5361-2017</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/244/preview/%D0%9C%D0%B5%D0%B4%D0%B2%D0%B5%D0%B4%D0%B5%D0%B2%D0%B0%D0%9B.%D0%90.jpg?1584022539\" alt=\"%d0%9c%d0%b5%d0%b4%d0%b2%d0%b5%d0%b4%d0%b5%d0%b2%d0%b0%d0%9b.%d0%90\" />\n<h3>Медведева Людмила Анатольевна</h3>\n</div>\n<h4>Ответственный секретарь, д.м.н.</h4>\n<p>- главный научный сотрудник Клиники изучения и лечения боли, ФГБНУ Российский научный центр хирургии имени акад. Б.В. Петровского (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=9850-6910\" target=\"_blank\" rel=\"noopener\">9850-6910</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=56593537900\" target=\"_blank\" rel=\"noopener\">56593537900</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-4191-7224\" target=\"_blank\" rel=\"noopener\">0000-0002-4191-7224</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/I-5578-2017\" target=\"_blank\" rel=\"noopener\">I-5578-2017</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/245/preview/%D0%A7%D1%83%D1%80%D1%8E%D0%BA%D0%B0%D0%BD%D0%BE%D0%B2%D0%9C.%D0%92.jpg?1584022991\" alt=\"%d0%a7%d1%83%d1%80%d1%8e%d0%ba%d0%b0%d0%bd%d0%be%d0%b2%d0%9c.%d0%92\" />\n<h3>Чурюканов Максим Валерьевич</h3>\n</div>\n<h4>Ответственный секретарь, доц., к.м.н.</h4>\n<p>- доцент кафедры нервных болезней и нейрохирургии, ФГАОУ ВО Первый МГМУ имени И.М. Сеченова; старший научный сотрудник Клиники изучения и лечения боли, ФГБНУ Российский научный центр хирургии им. Б.В. Петровского; член Правления Европейской федерации боли EFIC (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=7968-2812\" target=\"_blank\" rel=\"noopener\">7968-2812</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=15047727300\" target=\"_blank\" rel=\"noopener\">15047727300</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-6542-1963\" target=\"_blank\" rel=\"noopener\">0000-0001-6542-1963</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/G-9255-2018\" target=\"_blank\" rel=\"noopener\">G-9255-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/240/preview/%D0%90%D0%B1%D1%83%D0%B7%D0%B0%D1%80%D0%BE%D0%B2%D0%B0%D0%93.%D0%A0.jpg?1584013038\" alt=\"%d0%90%d0%b1%d1%83%d0%b7%d0%b0%d1%80%d0%be%d0%b2%d0%b0%d0%93.%d0%a0\" />\n<h3>Абузарова Гузель Рафаиловна</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- профессор кафедры онкологии и паллиативной медицины, Российская медицинская академия непрерывного профессионального образования; руководитель центра паллиативной помощи онкологическим больным, Московский научно-исследовательский онкологический институт (МНИОИ) имени П.А. Герцена (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=9876-4680\" target=\"_blank\" rel=\"noopener\">9876-4680</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6506455155\" target=\"_blank\" rel=\"noopener\">6506455155</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-6146-2706\" target=\"_blank\" rel=\"noopener\">0000-0002-6146-2706</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/AAA-1500-2020\" target=\"_blank\" rel=\"noopener\">AAA-1500-2020</a><br style=\"margin-right: 10px;\" /><br style=\"margin-right: 10px;\" /></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/241/preview/%D0%90%D0%BC%D0%B5%D0%BB%D0%B8%D0%BD%D0%90.%D0%92.jpg?1584016456\" alt=\"%d0%90%d0%bc%d0%b5%d0%bb%d0%b8%d0%bd%d0%90.%d0%92\" />\n<h3>Амелин Александр Витальевич</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- профессор кафедры неврологии, Санкт-Петербургский государственный медицинский университет имени И.П. Павлова; заведующий лабораторией нейрофизиологии и фармакологии боли, Институт фармакологии имени А.В. Вальдмана (Санкт-Петербург, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=2402-7452\" target=\"_blank\" rel=\"noopener\">2402-7452</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7007120162\" target=\"_blank\" rel=\"noopener\">7007120162</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/246/preview/%D0%91%D0%B0%D0%BB%D1%8F%D0%B7%D0%B8%D0%BD%D0%92.%D0%90.jpg?1584023859\" alt=\"%d0%91%d0%b0%d0%bb%d1%8f%d0%b7%d0%b8%d0%bd%d0%92.%d0%90\" />\n<h3>Балязин Виктор Александрович</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующий кафедрой неврологии и нейрохирургии, Ростовский государственный медицинский университет, Вице-президент Российского общества по изучению боли (Ростов-на-Дону, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=7054-9452\" target=\"_blank\" rel=\"noopener\">7054-9452</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6506095562\" target=\"_blank\" rel=\"noopener\">6506095562</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-8381-8876\" target=\"_blank\" rel=\"noopener\">0000-0001-8381-8876</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/AAG-6725-2020\" target=\"_blank\" rel=\"noopener\">AAG-6725-2020</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/247/preview/%D0%91%D0%B5%D0%BB%D1%8F%D0%B5%D0%B2%D0%90.%D0%A4.jpg?1584024469\" alt=\"%d0%91%d0%b5%d0%bb%d1%8f%d0%b5%d0%b2%d0%90.%d0%a4\" />\n<h3>Беляев Анатолий Федорович</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующий кафедрой восстановительной медицины, Владивостокский государственный медицинский университет (Владивосток, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=7144-4831\" target=\"_blank\" rel=\"noopener\">7144-4831</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/248/preview/Bouhassira_Didier.jpg?1584024886\" alt=\"Bouhassira didier\" />\n<h3>Бухассира Дидье</h3>\n</div>\n<h4>Член редакционного совета, проф., доктор медицины</h4>\n<p>- Центр изучения и лечения боли, Университет Версаль Сен-Квентин (Версаль, Франция).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7006708423\" target=\"_blank\" rel=\"noopener\">7006708423</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-6446-8719\" target=\"_blank\" rel=\"noopener\">0000-0001-6446-8719</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/Y-8403-2018\" target=\"_blank\" rel=\"noopener\">Y-8403-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/249/preview/%D0%92%D0%B5%D0%BB%D1%8C%D1%82%D0%B8%D1%89%D0%B5%D0%B2%D0%94.%D0%AE.jpg?1584025337\" alt=\"%d0%92%d0%b5%d0%bb%d1%8c%d1%82%d0%b8%d1%89%d0%b5%d0%b2%d0%94.%d0%ae\" />\n<h3>Вельтищев Дмитрий Юрьевич</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- руководитель отдела стрессовых расстройств, Московский НИИ психиатрии – филиал ФГБНУ «Научный центр психического здоровья» (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=2454-7931\" target=\"_blank\" rel=\"noopener\">2454-7931</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=36700770300\" target=\"_blank\" rel=\"noopener\">36700770300</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-5210-2605\" target=\"_blank\" rel=\"noopener\">0000-0001-5210-2605</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/C-6188-2013\" target=\"_blank\" rel=\"noopener\">C-6188-2013</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/250/preview/%D0%94%D1%80%D0%B5%D0%B2%D0%B0%D0%BB%D1%8C%D0%9E.%D0%9D.jpg?1584025699\" alt=\"%d0%94%d1%80%d0%b5%d0%b2%d0%b0%d0%bb%d1%8c%d0%9e.%d0%9d\" />\n<h3>Древаль Олег Николаевич</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующий кафедрой нейрохирургии, Российская медицинская академия непрерывного профессионального образования (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=8190-3431\" target=\"_blank\" rel=\"noopener\">8190-3431</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6508261842\" target=\"_blank\" rel=\"noopener\">6508261842</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-8944-9837\" target=\"_blank\" rel=\"noopener\">0000-0002-8944-9837</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/251/preview/%D0%95%D0%B2%D0%B7%D0%B8%D0%BA%D0%BE%D0%B2%D0%93.%D0%AE.jpg?1584087655\" alt=\"%d0%95%d0%b2%d0%b7%d0%b8%d0%ba%d0%be%d0%b2%d0%93.%d0%ae\" />\n<h3>Евзиков Григорий Юльевич</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- профессор кафедры нервных болезней и нейрохирургии, ФГАОУ ВО Первый МГМУ им. И.М.Сеченова (Москва, Россия).</p>\n<p>РИНЦ AuthorID: <a href=\"http://elibrary.ru/author_profile.asp?id=228859\" target=\"_blank\" rel=\"noopener\">228859</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=57205219900\" target=\"_blank\" rel=\"noopener\">57205219900</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-6715-6021\" target=\"_blank\" rel=\"noopener\">0000-0002-6715-6021</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/V-8510-2018\" target=\"_blank\" rel=\"noopener\">V-8510-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/252/preview/%D0%95%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%BA%D0%BE%D0%90.%D0%90.jpg?1584088119\" alt=\"%d0%95%d1%80%d0%b5%d0%bc%d0%b5%d0%bd%d0%ba%d0%be%d0%90.%d0%90\" />\n<h3>Еременко Александр Анатольевич</h3>\n</div>\n<h4>Член редакционного совета, член-корр. РАН, проф., д.м.н.</h4>\n<p>- Заслуженный деятель науки РФ, заведующий отделением кардиореанимации и интенсивной терапии, ФГБНУ Российский научный центр хирургии имени акад. Б.В. Петровского (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=5661-3290\" target=\"_blank\" rel=\"noopener\">5661-3290</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7102260042\" target=\"_blank\" rel=\"noopener\">7102260042</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-5809-8563\" target=\"_blank\" rel=\"noopener\">0000-0001-5809-8563</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/B-3152-2018\" target=\"_blank\" rel=\"noopener\">B-3152-2018</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/253/preview/%D0%97%D0%B0%D0%B3%D0%BE%D1%80%D1%83%D0%BB%D1%8C%D0%BA%D0%BE%D0%9E.%D0%98.jpg?1584089199\" alt=\"%d0%97%d0%b0%d0%b3%d0%be%d1%80%d1%83%d0%bb%d1%8c%d0%ba%d0%be%d0%9e.%d0%98\" />\n<h3>Загорулько Олег Иванович</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- руководитель Клиники изучения и лечения боли, ФГБНУ Российский научный центр хирургии имени акад. Б.В. Петровского (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=8208-4501\" target=\"_blank\" rel=\"noopener\">8208-4501</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=35773977900\" target=\"_blank\" rel=\"noopener\">35773977900</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-2713-9577\" target=\"_blank\" rel=\"noopener\">0000-0002-2713-9577</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/J-8552-2017\" target=\"_blank\" rel=\"noopener\">J-8552-2017</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/254/preview/%D0%9A%D0%B0%D1%80%D0%B0%D1%82%D0%B5%D0%B5%D0%B2%D0%90.%D0%95.jpg?1584089688\" alt=\"%d0%9a%d0%b0%d1%80%d0%b0%d1%82%d0%b5%d0%b5%d0%b2%d0%90.%d0%95\" />\n<h3>Каратеев Андрей Евгеньевич</h3>\n</div>\n<h4>Член редакционного совета, д.м.н.</h4>\n<p>- заведующий лабораторией патофизиологии боли и полиморфизма скелетно-мышечных заболеваний, ФГБНУ Научно-исследовательский институт ревматологии имени В.А. Насоновой (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=2795-4080\" target=\"_blank\" rel=\"noopener\">2795-4080</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6603615916\" target=\"_blank\" rel=\"noopener\">6603615916</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-1391-0711\" target=\"_blank\" rel=\"noopener\">0000-0002-1391-0711</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/AAA-3367-2019\" target=\"_blank\" rel=\"noopener\">AAA-3367-2019</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/255/preview/%D0%9A%D1%80%D1%83%D0%BF%D0%B8%D0%BD%D0%B0%D0%9D.%D0%90.jpg?1586001378\" alt=\"%d0%9a%d1%80%d1%83%d0%bf%d0%b8%d0%bd%d0%b0%d0%9d.%d0%90\" />\n<h3>Крупина Наталия Александровна</h3>\n</div>\n<h4>Член редакционного совета, д.б.н.</h4>\n<p>- главный научный сотрудник лаборатории патофизиологии нервной системы, ФГБНУ Научно-исследовательский институт общей патологии и патофизиологии (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=7177-8156\" target=\"_blank\" rel=\"noopener\">7177-8156</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7006787764\" target=\"_blank\" rel=\"noopener\">7006787764</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-2462-899X\" target=\"_blank\" rel=\"noopener\">0000-0002-2462-899X</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/M-3467-2014\" target=\"_blank\" rel=\"noopener\">M-3467-2014</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/256/preview/%D0%9C%D0%B0%D0%B9%D1%87%D1%83%D0%BA%D0%95.%D0%AE.jpg?1584091433\" alt=\"%d0%9c%d0%b0%d0%b9%d1%87%d1%83%d0%ba%d0%95.%d0%ae\" />\n<h3>Майчук Елена Юрьевна</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующая кафедрой внутренних болезней № 1, Московский государственный медико-стоматологический университет имени А.И. Евдокимова (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=5532-7898\" target=\"_blank\" rel=\"noopener\">5532-7898</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7801401443\" target=\"_blank\" rel=\"noopener\">7801401443</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/257/preview/Mouraux_Andr%C3%A9.jpg?1584091678\" alt=\"Mouraux andr%c3%a9\" />\n<h3>Моро Андре</h3>\n</div>\n<h4>Член редакционного совета, проф., доктор медицины</h4>\n<p>- научная группа исследования боли, Институт нейронаук (Брюссель, Бельгия).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6602503125\" target=\"_blank\" rel=\"noopener\">6602503125</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-1056-5980\" target=\"_blank\" rel=\"noopener\">0000-0003-1056-5980</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/F-3724-2012\" target=\"_blank\" rel=\"noopener\">F-3724-2012</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/258/preview/%D0%9D%D0%B0%D1%81%D0%BE%D0%BD%D0%BE%D0%B2%D0%95.%D0%9B.jpg?1584092762\" alt=\"%d0%9d%d0%b0%d1%81%d0%be%d0%bd%d0%be%d0%b2%d0%95.%d0%9b\" />\n<h3>Насонов Евгений Львович</h3>\n</div>\n<h4>Член редакционного совета, акад. РАН, проф., д.м.н.</h4>\n<p>- научный руководитель, ФГБНУ Научно-исследовательский институт ревматологии имени В.А. Насоновой (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=5162-6484\" target=\"_blank\" rel=\"noopener\">5162-6484</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7102614711\" target=\"_blank\" rel=\"noopener\">7102614711</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/259/preview/%D0%9D%D0%B8%D0%BA%D0%BE%D0%B4%D0%B0%D0%92.%D0%92.jpg?1584093114\" alt=\"%d0%9d%d0%b8%d0%ba%d0%be%d0%b4%d0%b0%d0%92.%d0%92\" />\n<h3>Никода Владимир Владимирович</h3>\n</div>\n<h4>Член редакционного совета, д.м.н.</h4>\n<p>- заведующий отделением общей реанимации, ФГБНУ Российский научный центр хирургии имени акад. Б.В. Петровского (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=6176-3911\" target=\"_blank\" rel=\"noopener\">6176-3911</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6701698242\" target=\"_blank\" rel=\"noopener\">6701698242</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-9605-254X\" target=\"_blank\" rel=\"noopener\">0000-0001-9605-254X</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/O-3631-2016\" target=\"_blank\" rel=\"noopener\">O-3631-2016</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/260/preview/%D0%9D%D0%BE%D0%B2%D0%B8%D0%BA%D0%BE%D0%B2%D0%93.%D0%90.jpg?1584094526\" alt=\"%d0%9d%d0%be%d0%b2%d0%b8%d0%ba%d0%be%d0%b2%d0%93.%d0%90\" />\n<h3>Новиков Георгий Андреевич</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- президент Общероссийского общественного движения \"Медицина за качество жизни\", заведующий кафедрой паллиативной медицины, Московский государственный медико-стоматологический университет имени А.И. Евдокимова (Москва, Россия).</p>\n<p>РИНЦ AuthorID: <a href=\"http://elibrary.ru/author_profile.asp?id=587031\" target=\"_blank\" rel=\"noopener\">587031</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7005070465\" target=\"_blank\" rel=\"noopener\">7005070465</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/261/preview/%D0%9E%D0%B2%D0%B5%D1%87%D0%BA%D0%B8%D0%BD%D0%90.%D0%9C.jpg?1584094836\" alt=\"%d0%9e%d0%b2%d0%b5%d1%87%d0%ba%d0%b8%d0%bd%d0%90.%d0%9c\" />\n<h3>Овечкин Алексей Михайлович</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- профессор кафедры анестезиологии и реаниматологии, ФГАОУ ВО Первый МГМУ имени И.М. Сеченова (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=1277-9220\" target=\"_blank\" rel=\"noopener\">1277-9220</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7003507291\" target=\"_blank\" rel=\"noopener\">7003507291</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-7756-7089\" target=\"_blank\" rel=\"noopener\">0000-0001-7756-7089</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/S-6607-2016\" target=\"_blank\" rel=\"noopener\">S-6607-2016</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/262/preview/Plaghki_Leon.jpg?1584095210\" alt=\"Plaghki leon\" />\n<h3>Плаки Леон</h3>\n</div>\n<h4>Член редакционного совета, проф., доктор медицины</h4>\n<p>- почетный профессор, Католический Университет Лёвина (Лёвин, Бельгия).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7003667780\" target=\"_blank\" rel=\"noopener\">7003667780</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-7996-5272\" target=\"_blank\" rel=\"noopener\">0000-0002-7996-5272</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/263/preview/%D0%A0%D0%B0%D0%B1%D0%B8%D0%BD%D0%BE%D0%B2%D0%B8%D1%87%D0%A1.%D0%90.jpg?1584095579\" alt=\"%d0%a0%d0%b0%d0%b1%d0%b8%d0%bd%d0%be%d0%b2%d0%b8%d1%87%d0%a1.%d0%90\" />\n<h3>Рабинович Соломон Абрамович</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующий кафедрой обезболивания в стоматологии, Московский государственный медико-стоматологический университет имени А.И. Евдокимова (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=3231-2930\" target=\"_blank\" rel=\"noopener\">3231-2930</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=56498748100\" target=\"_blank\" rel=\"noopener\">56498748100</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-2756-1468\" target=\"_blank\" rel=\"noopener\">0000-0003-2756-1468</a><br style=\"margin-right: 10px;\" />ResearcherID: <a href=\"http://www.researcherid.com/rid/N-4350-2014\" target=\"_blank\" rel=\"noopener\">N-4350-2014</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/264/preview/%D0%A1%D0%BE%D0%BA%D0%BE%D0%B2%D0%95.%D0%9B.jpg?1584096139\" alt=\"%d0%a1%d0%be%d0%ba%d0%be%d0%b2%d0%95.%d0%9b\" />\n<h3>Соков Евгений Леонидович</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующий кафедрой алгологии и реабилитации, Институт восточной медицины, Российский университет дружбы народов (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=1953-3066\" target=\"_blank\" rel=\"noopener\">1953-3066</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6602341586\" target=\"_blank\" rel=\"noopener\">6602341586</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/265/preview/%D0%A1%D1%82%D1%80%D0%BE%D0%BA%D0%BE%D0%B2%D0%98.%D0%90.jpg?1584096498\" alt=\"%d0%a1%d1%82%d1%80%d0%be%d0%ba%d0%be%d0%b2%d0%98.%d0%90\" />\n<h3>Строков Игорь Алексеевич</h3>\n</div>\n<h4>Член редакционного совета, доц., к.м.н.</h4>\n<p>- доцент кафедры нервных болезней и нейрохирургии лечебного факультета, ФГАОУ Первый МГМУ имени И.М. Сеченова (Москва, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=5262-8780\" target=\"_blank\" rel=\"noopener\">5262-8780</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6701743258\" target=\"_blank\" rel=\"noopener\">6701743258</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0001-6950-7166\" target=\"_blank\" rel=\"noopener\">0000-0001-6950-7166</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/266/preview/%D0%A2%D0%B0%D0%B1%D0%B5%D0%B5%D0%B2%D0%B0%D0%93.%D0%A0.jpg?1584098124\" alt=\"%d0%a2%d0%b0%d0%b1%d0%b5%d0%b5%d0%b2%d0%b0%d0%93.%d0%a0\" />\n<h3>Табеева Гюзяль Рафкатовна</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- Президент Российского общества по изучению головной боли, профессор кафедры нервных болезней и нейрохирургии, ФГАОУ ВО Первый МГМУ имени И.М. Сеченова (Москва, Россия).</p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/267/preview/%D0%A5%D0%B0%D0%B1%D0%B8%D1%80%D0%BE%D0%B2%D0%A4.%D0%90.jpg?1584098642\" alt=\"%d0%a5%d0%b0%d0%b1%d0%b8%d1%80%d0%be%d0%b2%d0%a4.%d0%90\" />\n<h3>Хабиров Фарит Ахатович</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующий кафедрой вертеброневрологии и мануальной терапии, Казанский государственный медицинская академия (Казань, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=6015-3095\" target=\"_blank\" rel=\"noopener\">6015-3095</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=6701631544\" target=\"_blank\" rel=\"noopener\">6701631544</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0002-2572-6970\" target=\"_blank\" rel=\"noopener\">0000-0002-2572-6970</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/268/preview/%D0%A8%D0%B8%D1%80%D0%BE%D0%BA%D0%BE%D0%B2%D0%92.%D0%90.jpg?1584100153\" alt=\"%d0%a8%d0%b8%d1%80%d0%be%d0%ba%d0%be%d0%b2%d0%92.%d0%90\" />\n<h3>Широков Василий Афонасьевич</h3>\n</div>\n<h4>Член редакционного совета, проф., д.м.н.</h4>\n<p>- заведующий научным отделом «Неврологическая клиника», ФБУН «Екатеринбургский медицинский-научный центр профилактики и охраны здоровья рабочих промышленных предприятий» (Екатеринбург, Россия).</p>\n<p>SPIN РИНЦ: <a href=\"http://elibrary.ru/author_profile.asp?spin=8387-4080\" target=\"_blank\" rel=\"noopener\">8387-4080</a><br style=\"margin-right: 10px;\" />Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=57210118004\" target=\"_blank\" rel=\"noopener\">57210118004</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-1461-1761\" target=\"_blank\" rel=\"noopener\">0000-0003-1461-1761</a></p>\n</div>\n<div>\n<div><img class=\"pull-left\" style=\"margin-right: 10px;\" src=\"https://mediasphera.ru/system/authors/avatars/000/125/269/preview/Ecclecston_Christopher.jpg?1586001441\" alt=\"Ecclecston christopher\" />\n<h3>Эсслекстон Кристофер</h3>\n</div>\n<h4>Член редакционного совета, проф., доктор медицины</h4>\n<p>- директор Центра изучения боли, Университет Бата (Бат, Великобритания).</p>\n<p>Scopus AuthorID: <a href=\"https://www.scopus.com/authid/detail.uri?authorId=7004000686\" target=\"_blank\" rel=\"noopener\">7004000686</a><br style=\"margin-right: 10px;\" />ORCID: <a href=\"https://orcid.org/0000-0003-0698-1543\" target=\"_blank\" rel=\"noopener\">0000-0003-0698-1543</a></p>\n</div>', NULL),
(1, 'ru_RU', 'librarianInformation', 'Мы надеемся, что сотрудники библиотек внесут этот журнал в список электронных журналов своей библиотеки. Следует отметить, что открытая издательская система этого журнала также подходит для того, чтобы библиотеки могли разместить собственные электронные журналы, в редактировании которых участвуют преподаватели и научные работники (подробнее можно посмотреть на <a href=\"http://pkp.sfu.ca/ojs\">Open Journal Systems</a>.', NULL),
(1, 'ru_RU', 'lockssLicense', 'Этот журнал использует систему LOCKSS для создания распределенной архивной системы между участвующими в этой системе библиотеками и разрешает этим библиотекам создавать постоянные архивы журнала в целях сохранения и восстановления. <a href=\"http://www.lockss.org/\">Подробнее...</a>', NULL),
(1, 'ru_RU', 'name', 'Российский журнал боли', NULL),
(1, 'ru_RU', 'openAccessPolicy', 'Этот журнал предоставляет непосредственный открытый доступ к своему контенту, исходя из следующего принципа: свободный открытый доступ к результатам исследований способствует увеличению глобального обмена знаниями.', NULL),
(1, 'ru_RU', 'privacyStatement', '<p>Имена и адреса электронной почты, введенные на сайте этого журнала, будут использованы исключительно для целей, обозначенных этим журналом, и не будут использованы для каких-либо других целей или предоставлены другим лицам и организациям.</p>', NULL),
(1, 'ru_RU', 'readerInformation', 'Мы приглашаем наших читателей подписаться на уведомления о выходе номеров этого журнала. Используйте ссылку <a href=\"https://ojs-msph.ru/index.phprussian_journal_of_pain/user/register\">РЕГИСТРАЦИЯ</a> в верхней части главной страницы журнала. Эта регистрация позволит читателю получать на электронную почту содержание каждого нового номера журнала. Этот список также позволяет журналу говорить об определенном уровне поддержки или количестве читателей. Посмотрите также страницу <a href=\"https://ojs-msph.ru/index.phprussian_journal_of_pain/about/submissions#privacyStatement\">Заявление о конфиденциальности</a>, которая позволяет читателям убедиться в том, что их имя и адрес электронной почты не будут использованы для других целей.', NULL),
(1, 'ru_RU', 'submissionChecklist', '[{\"order\":1,\"content\":\"Этот материал ранее не был опубликован, а также не был представлен для рассмотрения и публикации в другом журнале (или дано объяснение этого в Комментариях для редактора).\"},{\"order\":6,\"content\":\"Файл с материалом представлен в формате документа Microsoft Word — принимается только файл с раширением docx.\"},{\"order\":3,\"content\":\"Приведены полные интернет-адреса (URL) для ссылок там, где это возможно.\"},{\"order\":4,\"content\":\"Текст набран с одинарным межстрочным интервалом; используется кегль шрифта в 12 пунктов; для выделения используется курсив, а не подчеркивание (за исключением URL-адресов); все иллюстрации, графики и таблицы расположены в соответствующих местах в тексте, а не в конце документа.\"},{\"order\":5,\"content\":\"Текст соответствует стилистическим и библиографческим требованиям, описанным в <a href=\\\"https:\\/\\/ojs-msph.ru\\/index.phprussian_journal_of_pain\\/about\\/submissions#authorGuidelines\\\" target=\\\"_new\\\">Руководстве для авторов<\\/a>, которое можно найти на странице «О журнале».\"}]', 'object'),
(2, '', 'contactEmail', 'natalya-molleker@yandex.ru', NULL),
(2, '', 'contactName', 'Наталья Моллекер', NULL),
(2, '', 'copyrightYearBasis', 'issue', NULL),
(2, '', 'defaultReviewMode', '2', NULL),
(2, '', 'emailSignature', '<br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/prb\">Пробный</a>', NULL),
(2, '', 'enableOai', '1', NULL),
(2, '', 'itemsPerPage', '25', NULL),
(2, '', 'keywords', 'request', NULL),
(2, '', 'mailingAddress', '456560', NULL),
(2, '', 'membershipFee', '0', NULL),
(2, '', 'numPageLinks', '10', NULL),
(2, '', 'numWeeksPerResponse', '4', NULL),
(2, '', 'numWeeksPerReview', '4', NULL),
(2, '', 'publicationFee', '0', NULL),
(2, '', 'purchaseArticleFee', '0', NULL),
(2, '', 'supportedFormLocales', '[\"ru_RU\",\"en_US\"]', NULL),
(2, '', 'supportedLocales', '[\"en_US\",\"ru_RU\"]', NULL),
(2, '', 'supportedSubmissionLocales', '[\"ru_RU\",\"en_US\"]', NULL),
(2, '', 'supportEmail', 'natalya-molleker@yandex.ru', NULL),
(2, '', 'supportName', 'Наталья Моллекер', NULL),
(2, '', 'themePluginPath', 'healthSciences', NULL),
(2, 'en_US', 'acronym', 'prb', NULL),
(2, 'en_US', 'authorInformation', 'Interested in submitting to this journal? We recommend that you review the <a href=\"https://ojs-msph.ru/index.phpprb/about\">About the Journal</a> page for the journal\'s section policies, as well as the <a href=\"https://ojs-msph.ru/index.phpprb/about/submissions#authorGuidelines\">Author Guidelines</a>. Authors need to <a href=\"https://ojs-msph.ru/index.phpprb/user/register\">register</a> with the journal prior to submitting or, if already registered, can simply <a href=\"https://ojs-msph.ru/index.php/index/login\">log in</a> and begin the five-step process.', NULL),
(2, 'en_US', 'clockssLicense', 'This journal utilizes the CLOCKSS system to create a distributed archiving system among participating libraries and permits those libraries to create permanent archives of the journal for purposes of preservation and restoration. <a href=\"http://clockss.org/\">More...</a>', NULL),
(2, 'en_US', 'librarianInformation', 'We encourage research librarians to list this journal among their library\'s electronic journal holdings. As well, it may be worth noting that this journal\'s open source publishing system is suitable for libraries to host for their faculty members to use with journals they are involved in editing (see <a href=\"http://pkp.sfu.ca/ojs\">Open Journal Systems</a>).', NULL),
(2, 'en_US', 'lockssLicense', 'This journal utilizes the LOCKSS system to create a distributed archiving system among participating libraries and permits those libraries to create permanent archives of the journal for purposes of preservation and restoration. <a href=\"http://www.lockss.org/\">More...</a>', NULL),
(2, 'en_US', 'name', 'TEST', NULL),
(2, 'en_US', 'openAccessPolicy', 'This journal provides immediate open access to its content on the principle that making research freely available to the public supports a greater global exchange of knowledge.', NULL),
(2, 'en_US', 'privacyStatement', '<p>The names and email addresses entered in this journal site will be used exclusively for the stated purposes of this journal and will not be made available for any other purpose or to any other party.</p>', NULL),
(2, 'en_US', 'readerInformation', 'We encourage readers to sign up for the publishing notification service for this journal. Use the <a href=\"https://ojs-msph.ru/index.phpprb/user/register\">Register</a> link at the top of the home page for the journal. This registration will result in the reader receiving the Table of Contents by email for each new issue of the journal. This list also allows the journal to claim a certain level of support or readership. See the journal\'s <a href=\"https://ojs-msph.ru/index.phpprb/about/submissions#privacyStatement\">Privacy Statement</a>, which assures readers that their name and email address will not be used for other purposes.', NULL),
(2, 'en_US', 'submissionChecklist', '[{\"order\":1,\"content\":\"The submission has not been previously published, nor is it before another journal for consideration (or an explanation has been provided in Comments to the Editor).\"},{\"order\":2,\"content\":\"The submission file is in OpenOffice, Microsoft Word, or RTF document file format.\"},{\"order\":3,\"content\":\"Where available, URLs for the references have been provided.\"},{\"order\":4,\"content\":\"The text is single-spaced; uses a 12-point font; employs italics, rather than underlining (except with URL addresses); and all illustrations, figures, and tables are placed within the text at the appropriate points, rather than at the end.\"},{\"order\":5,\"content\":\"The text adheres to the stylistic and bibliographic requirements outlined in the Author Guidelines.\"}]', NULL),
(2, 'ru_RU', 'about', '<p>Журнал, созданный для тестовых целей.</p>', NULL),
(2, 'ru_RU', 'acronym', 'ПРБ', NULL),
(2, 'ru_RU', 'authorInformation', 'Вы хотите отправить материал для публикации в этом журнале? Рекомендуем вам посмотреть раздел <a href=\"https://ojs-msph.ru/index.phpprb/about\">«О журнале»</a>, где вы сможете ознакомиться с правилами разделов журнала, а также с <a href=\"https://ojs-msph.ru/index.phpprb/about/submissions#authorGuidelines\">Руководством для автора</a>. Авторам нужно <a href=\"https://ojs-msph.ru/index.phpprb/user/register\">зарегистрироваться</a> в журнале перед отправкой материалов, или, если вы уже зарегистрированы, можно просто <a href=\"https://ojs-msph.ru/index.php/index/login\">войти</a> со своей учетной записью и начать процесс отправки, состоящий из пяти шагов.', NULL),
(2, 'ru_RU', 'clockssLicense', 'Этот журнал использует систему CLOCKSS для создания распределенной архивной системы между участвующими в этой системе библиотеками и разрешает этим библиотекам создавать постоянные архивы журнала в целях сохранения и восстановления. <a href=\"http://clockss.org/\">Подробнее...</a>', NULL),
(2, 'ru_RU', 'librarianInformation', 'Мы надеемся, что сотрудники библиотек внесут этот журнал в список электронных журналов своей библиотеки. Следует отметить, что открытая издательская система этого журнала также подходит для того, чтобы библиотеки могли разместить собственные электронные журналы, в редактировании которых участвуют преподаватели и научные работники (подробнее можно посмотреть на <a href=\"http://pkp.sfu.ca/ojs\">Open Journal Systems</a>.', NULL),
(2, 'ru_RU', 'lockssLicense', 'Этот журнал использует систему LOCKSS для создания распределенной архивной системы между участвующими в этой системе библиотеками и разрешает этим библиотекам создавать постоянные архивы журнала в целях сохранения и восстановления. <a href=\"http://www.lockss.org/\">Подробнее...</a>', NULL),
(2, 'ru_RU', 'name', 'Пробный', NULL),
(2, 'ru_RU', 'openAccessPolicy', 'Этот журнал предоставляет непосредственный открытый доступ к своему контенту, исходя из следующего принципа: свободный открытый доступ к результатам исследований способствует увеличению глобального обмена знаниями.', NULL),
(2, 'ru_RU', 'privacyStatement', '<p>Имена и адреса электронной почты, введенные на сайте этого журнала, будут использованы исключительно для целей, обозначенных этим журналом, и не будут использованы для каких-либо других целей или предоставлены другим лицам и организациям.</p>', NULL),
(2, 'ru_RU', 'readerInformation', 'Мы приглашаем наших читателей подписаться на уведомления о выходе номеров этого журнала. Используйте ссылку <a href=\"https://ojs-msph.ru/index.phpprb/user/register\">РЕГИСТРАЦИЯ</a> в верхней части главной страницы журнала. Эта регистрация позволит читателю получать на электронную почту содержание каждого нового номера журнала. Этот список также позволяет журналу говорить об определенном уровне поддержки или количестве читателей. Посмотрите также страницу <a href=\"https://ojs-msph.ru/index.phpprb/about/submissions#privacyStatement\">Заявление о конфиденциальности</a>, которая позволяет читателям убедиться в том, что их имя и адрес электронной почты не будут использованы для других целей.', NULL),
(2, 'ru_RU', 'submissionChecklist', '[{\"order\":1,\"content\":\"Этот материал ранее не был опубликован, а также не был представлен для рассмотрения и публикации в другом журнале (или дано объяснение этого в Комментариях для редактора).\"},{\"order\":2,\"content\":\"Файл с материалом представлен в формате документа OpenOffice, Microsoft Word или RTF.\"},{\"order\":3,\"content\":\"Приведены полные интернет-адреса (URL) для ссылок там, где это возможно.\"},{\"order\":4,\"content\":\"Текст набран с одинарным межстрочным интервалом; используется кегль шрифта в 12 пунктов; для выделения используется курсив, а не подчеркивание (за исключением URL-адресов); все иллюстрации, графики и таблицы расположены в соответствующих местах в тексте, а не в конце документа.\"},{\"order\":5,\"content\":\"Текст соответствует стилистическим и библиографческим требованиям, описанным в <a href=\\\"https:\\/\\/ojs-msph.ru\\/index.phpprb\\/about\\/submissions#authorGuidelines\\\" target=\\\"_new\\\">Руководстве для авторов<\\/a>, которое можно найти на странице «О журнале».\"}]', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `library_files`
--

CREATE TABLE `library_files` (
  `file_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_file_name` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `public_access` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `library_file_settings`
--

CREATE TABLE `library_file_settings` (
  `file_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `metadata_descriptions`
--

CREATE TABLE `metadata_descriptions` (
  `metadata_description_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL DEFAULT '0',
  `assoc_id` bigint(20) NOT NULL DEFAULT '0',
  `schema_namespace` varchar(255) NOT NULL,
  `schema_name` varchar(255) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `seq` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `metadata_description_settings`
--

CREATE TABLE `metadata_description_settings` (
  `metadata_description_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `metrics`
--

CREATE TABLE `metrics` (
  `load_id` varchar(255) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `pkp_section_id` bigint(20) DEFAULT NULL,
  `assoc_object_type` bigint(20) DEFAULT NULL,
  `assoc_object_id` bigint(20) DEFAULT NULL,
  `submission_id` bigint(20) DEFAULT NULL,
  `representation_id` bigint(20) DEFAULT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `day` varchar(8) DEFAULT NULL,
  `month` varchar(6) DEFAULT NULL,
  `file_type` tinyint(4) DEFAULT NULL,
  `country_id` varchar(2) DEFAULT NULL,
  `region` varchar(2) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `metric_type` varchar(255) NOT NULL,
  `metric` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `metrics`
--

INSERT INTO `metrics` (`load_id`, `context_id`, `pkp_section_id`, `assoc_object_type`, `assoc_object_id`, `submission_id`, `representation_id`, `assoc_type`, `assoc_id`, `day`, `month`, `file_type`, `country_id`, `region`, `city`, `metric_type`, `metric`) VALUES
('usage_events_20200420.log', 1, NULL, NULL, NULL, NULL, NULL, 256, 1, '20200420', '202004', NULL, NULL, NULL, NULL, 'ojs::counter', 2),
('usage_events_20200421.log', 1, NULL, NULL, NULL, NULL, NULL, 256, 1, '20200421', '202004', NULL, NULL, NULL, NULL, 'ojs::counter', 18),
('usage_events_20200422.log', 1, NULL, NULL, NULL, NULL, NULL, 256, 1, '20200422', '202004', NULL, NULL, NULL, NULL, 'ojs::counter', 9),
('usage_events_20200422.log', 1, NULL, NULL, NULL, NULL, NULL, 259, 1, '20200422', '202004', NULL, NULL, NULL, NULL, 'ojs::counter', 3),
('usage_events_20200429.log', 2, NULL, NULL, NULL, NULL, NULL, 256, 2, '20200429', '202004', NULL, NULL, NULL, NULL, 'ojs::counter', 1),
('usage_events_20200831.log', 2, NULL, NULL, NULL, NULL, NULL, 256, 2, '20200831', '202008', NULL, NULL, NULL, NULL, 'ojs::counter', 1),
('usage_events_20210127.log', 2, NULL, NULL, NULL, NULL, NULL, 256, 2, '20210127', '202101', NULL, NULL, NULL, NULL, 'ojs::counter', 2),
('usage_events_20210224.log', 2, NULL, NULL, NULL, NULL, NULL, 256, 2, '20210224', '202102', NULL, NULL, NULL, NULL, 'ojs::counter', 1),
('usage_events_20210506.log', 2, NULL, NULL, NULL, NULL, NULL, 256, 2, '20210506', '202105', NULL, NULL, NULL, NULL, 'ojs::counter', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2016_10_22_195149_add_api_token', 1),
(2, '2016_10_23_194915_create_antiplagiat_reports_table', 1),
(3, '2016_10_23_200442_create_antiplagiat_reports_blocks', 1),
(4, '2016_10_23_202157_create_antiplagiat_reports_services_table', 1),
(5, '2016_10_23_202559_create_antiplagiat_reports_services__sources_table', 1),
(6, '2016_10_23_203319_create_antiplagiat_reports_status_table', 1),
(7, '2016_11_05_203450_create_failed_jobs_table', 1),
(8, '2016_11_09_203503_add_link_column_to_antiplagiat_report', 2),
(9, '2016_11_26_185137_add_submission_file_log', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_menus`
--

CREATE TABLE `navigation_menus` (
  `navigation_menu_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `area_name` varchar(255) DEFAULT '',
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `navigation_menus`
--

INSERT INTO `navigation_menus` (`navigation_menu_id`, `context_id`, `area_name`, `title`) VALUES
(1, 0, 'user', 'User Navigation Menu'),
(2, 1, 'user', 'User Navigation Menu'),
(3, 1, 'primary', 'Primary Navigation Menu'),
(4, 2, 'user', 'User Navigation Menu'),
(5, 2, 'primary', 'Primary Navigation Menu');

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_menu_items`
--

CREATE TABLE `navigation_menu_items` (
  `navigation_menu_item_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `path` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `navigation_menu_items`
--

INSERT INTO `navigation_menu_items` (`navigation_menu_item_id`, `context_id`, `path`, `type`) VALUES
(1, 0, NULL, 'NMI_TYPE_USER_REGISTER'),
(2, 0, NULL, 'NMI_TYPE_USER_LOGIN'),
(3, 0, NULL, 'NMI_TYPE_USER_DASHBOARD'),
(4, 0, NULL, 'NMI_TYPE_USER_DASHBOARD'),
(5, 0, NULL, 'NMI_TYPE_USER_PROFILE'),
(6, 0, NULL, 'NMI_TYPE_ADMINISTRATION'),
(7, 0, NULL, 'NMI_TYPE_USER_LOGOUT'),
(8, 1, NULL, 'NMI_TYPE_USER_REGISTER'),
(9, 1, NULL, 'NMI_TYPE_USER_LOGIN'),
(10, 1, NULL, 'NMI_TYPE_USER_DASHBOARD'),
(11, 1, NULL, 'NMI_TYPE_USER_DASHBOARD'),
(12, 1, NULL, 'NMI_TYPE_USER_PROFILE'),
(13, 1, NULL, 'NMI_TYPE_ADMINISTRATION'),
(14, 1, NULL, 'NMI_TYPE_USER_LOGOUT'),
(15, 1, NULL, 'NMI_TYPE_CURRENT'),
(16, 1, NULL, 'NMI_TYPE_ARCHIVES'),
(17, 1, NULL, 'NMI_TYPE_ANNOUNCEMENTS'),
(18, 1, NULL, 'NMI_TYPE_ABOUT'),
(19, 1, NULL, 'NMI_TYPE_ABOUT'),
(20, 1, NULL, 'NMI_TYPE_SUBMISSIONS'),
(21, 1, NULL, 'NMI_TYPE_EDITORIAL_TEAM'),
(22, 1, NULL, 'NMI_TYPE_PRIVACY'),
(23, 1, NULL, 'NMI_TYPE_CONTACT'),
(24, 1, NULL, 'NMI_TYPE_SEARCH'),
(25, 2, NULL, 'NMI_TYPE_USER_REGISTER'),
(26, 2, NULL, 'NMI_TYPE_USER_LOGIN'),
(27, 2, NULL, 'NMI_TYPE_USER_DASHBOARD'),
(28, 2, NULL, 'NMI_TYPE_USER_DASHBOARD'),
(29, 2, NULL, 'NMI_TYPE_USER_PROFILE'),
(30, 2, NULL, 'NMI_TYPE_ADMINISTRATION'),
(31, 2, NULL, 'NMI_TYPE_USER_LOGOUT'),
(32, 2, NULL, 'NMI_TYPE_CURRENT'),
(33, 2, NULL, 'NMI_TYPE_ARCHIVES'),
(34, 2, NULL, 'NMI_TYPE_ANNOUNCEMENTS'),
(35, 2, NULL, 'NMI_TYPE_ABOUT'),
(36, 2, NULL, 'NMI_TYPE_ABOUT'),
(37, 2, NULL, 'NMI_TYPE_SUBMISSIONS'),
(38, 2, NULL, 'NMI_TYPE_EDITORIAL_TEAM'),
(39, 2, NULL, 'NMI_TYPE_PRIVACY'),
(40, 2, NULL, 'NMI_TYPE_CONTACT'),
(41, 2, NULL, 'NMI_TYPE_SEARCH');

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_menu_item_assignments`
--

CREATE TABLE `navigation_menu_item_assignments` (
  `navigation_menu_item_assignment_id` bigint(20) NOT NULL,
  `navigation_menu_id` bigint(20) NOT NULL,
  `navigation_menu_item_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `seq` bigint(20) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `navigation_menu_item_assignments`
--

INSERT INTO `navigation_menu_item_assignments` (`navigation_menu_item_assignment_id`, `navigation_menu_id`, `navigation_menu_item_id`, `parent_id`, `seq`) VALUES
(1, 1, 1, 0, 0),
(2, 1, 2, 0, 1),
(3, 1, 3, 0, 2),
(4, 1, 4, 3, 0),
(5, 1, 5, 3, 1),
(6, 1, 6, 3, 2),
(7, 1, 7, 3, 3),
(8, 2, 8, 0, 0),
(9, 2, 9, 0, 1),
(10, 2, 10, 0, 2),
(11, 2, 11, 10, 0),
(12, 2, 12, 10, 1),
(13, 2, 13, 10, 2),
(14, 2, 14, 10, 3),
(15, 3, 15, 0, 0),
(16, 3, 16, 0, 1),
(17, 3, 17, 0, 2),
(18, 3, 18, 0, 3),
(19, 3, 19, 18, 0),
(20, 3, 20, 18, 1),
(21, 3, 21, 18, 2),
(22, 3, 22, 18, 3),
(23, 3, 23, 18, 4),
(24, 4, 25, 0, 0),
(25, 4, 26, 0, 1),
(26, 4, 27, 0, 2),
(27, 4, 28, 27, 0),
(28, 4, 29, 27, 1),
(29, 4, 30, 27, 2),
(30, 4, 31, 27, 3),
(31, 5, 32, 0, 0),
(32, 5, 33, 0, 1),
(33, 5, 34, 0, 2),
(34, 5, 35, 0, 3),
(35, 5, 36, 35, 0),
(36, 5, 37, 35, 1),
(37, 5, 38, 35, 2),
(38, 5, 39, 35, 3),
(39, 5, 40, 35, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_menu_item_assignment_settings`
--

CREATE TABLE `navigation_menu_item_assignment_settings` (
  `navigation_menu_item_assignment_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_menu_item_settings`
--

CREATE TABLE `navigation_menu_item_settings` (
  `navigation_menu_item_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `navigation_menu_item_settings`
--

INSERT INTO `navigation_menu_item_settings` (`navigation_menu_item_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, '', 'titleLocaleKey', 'navigation.register', 'string'),
(2, '', 'titleLocaleKey', 'navigation.login', 'string'),
(3, '', 'titleLocaleKey', '{$loggedInUsername}', 'string'),
(4, '', 'titleLocaleKey', 'navigation.dashboard', 'string'),
(5, '', 'titleLocaleKey', 'common.viewProfile', 'string'),
(6, '', 'titleLocaleKey', 'navigation.admin', 'string'),
(7, '', 'titleLocaleKey', 'user.logOut', 'string'),
(8, '', 'titleLocaleKey', 'navigation.register', 'string'),
(9, '', 'titleLocaleKey', 'navigation.login', 'string'),
(10, '', 'titleLocaleKey', '{$loggedInUsername}', 'string'),
(11, '', 'titleLocaleKey', 'navigation.dashboard', 'string'),
(12, '', 'titleLocaleKey', 'common.viewProfile', 'string'),
(13, '', 'titleLocaleKey', 'navigation.admin', 'string'),
(14, '', 'titleLocaleKey', 'user.logOut', 'string'),
(15, '', 'titleLocaleKey', 'navigation.current', 'string'),
(16, '', 'titleLocaleKey', 'navigation.archives', 'string'),
(17, '', 'titleLocaleKey', 'manager.announcements', 'string'),
(18, '', 'titleLocaleKey', 'navigation.about', 'string'),
(19, '', 'titleLocaleKey', 'about.aboutContext', 'string'),
(20, '', 'titleLocaleKey', 'about.submissions', 'string'),
(21, '', 'titleLocaleKey', 'about.editorialTeam', 'string'),
(22, '', 'titleLocaleKey', 'manager.setup.privacyStatement', 'string'),
(23, '', 'titleLocaleKey', 'about.contact', 'string'),
(24, '', 'titleLocaleKey', 'common.search', 'string'),
(25, '', 'titleLocaleKey', 'navigation.register', 'string'),
(26, '', 'titleLocaleKey', 'navigation.login', 'string'),
(27, '', 'titleLocaleKey', '{$loggedInUsername}', 'string'),
(28, '', 'titleLocaleKey', 'navigation.dashboard', 'string'),
(29, '', 'titleLocaleKey', 'common.viewProfile', 'string'),
(30, '', 'titleLocaleKey', 'navigation.admin', 'string'),
(31, '', 'titleLocaleKey', 'user.logOut', 'string'),
(32, '', 'titleLocaleKey', 'navigation.current', 'string'),
(33, '', 'titleLocaleKey', 'navigation.archives', 'string'),
(34, '', 'titleLocaleKey', 'manager.announcements', 'string'),
(35, '', 'titleLocaleKey', 'navigation.about', 'string'),
(36, '', 'titleLocaleKey', 'about.aboutContext', 'string'),
(37, '', 'titleLocaleKey', 'about.submissions', 'string'),
(38, '', 'titleLocaleKey', 'about.editorialTeam', 'string'),
(39, '', 'titleLocaleKey', 'manager.setup.privacyStatement', 'string'),
(40, '', 'titleLocaleKey', 'about.contact', 'string'),
(41, '', 'titleLocaleKey', 'common.search', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE `notes` (
  `note_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `contents` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `notes`
--

INSERT INTO `notes` (`note_id`, `assoc_type`, `assoc_id`, `user_id`, `date_created`, `date_modified`, `title`, `contents`) VALUES
(1, 1048586, 1, 1, '2020-04-21 09:56:55', '2020-04-21 09:56:55', NULL, NULL),
(2, 1048586, 2, 1, '2020-04-21 10:06:07', '2020-04-21 10:06:07', NULL, NULL),
(3, 1048586, 3, 1, '2020-04-21 10:12:05', '2020-04-21 10:12:05', NULL, NULL),
(4, 1048586, 4, 1, '2020-04-21 10:13:21', '2020-04-21 10:13:21', NULL, NULL),
(6, 1048586, 5, 2, '2020-04-21 10:21:13', '2020-04-21 10:21:13', '[РЖБ] Назначение редактором', '<p>Здравствуйте, Владимир Влукин!<br><br>В соответствии с Вашей ролью редактора раздела Вам поручен контроль прохождения через редакционный процесс материала «Участие половых гормонов в формировании назальных полипов. История вопроса» в журнале «Российский журнал боли».<br><br>URL материала: <a href=\'https://ojs-msph.ru/index.php/russian_journal_of_pain/workflow/access/1\' class=\'submissionUrl-style-class\'>https://ojs-msph.ru/index.php/russian_journal_of_pain/workflow/access/1</a><br>Имя пользователя: vllukin<br><br>Заранее благодарю.</p><br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>'),
(7, 1048586, 6, 2, '2020-04-21 11:16:39', '2020-04-21 11:16:39', '[РЖБ] Запрос на литературное редактирование', '<p>Здравствуйте, Владимир Влукин!<br><br>Я хотел бы попросить Вас выполнить литературное редактирование материала «Участие половых гормонов в формировании назальных полипов. История вопроса» для журнала «Российский журнал боли», выполнив следующие шаги.<br>1. Щелкните на URL материала ниже.<br>2. Откройте все файлы, доступные в панели «Черновики», и выполните литературное редактирование, добавляя при необходимости Обсуждения литературного редактирования.<br>3. Сохраните отредактированные файлы и загрузите их в панель «Отредактированные».<br>4. Уведомите редактора о том, что все файлы были подготовлены и можно их запускать в производство.<br><br>URL журнала «Российский журнал боли»: <a class=\"contextUrl-style-class\" href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">https://ojs-msph.ru/index.php/russian_journal_of_pain</a><br>URL материала: <a href=\'https://ojs-msph.ru/index.php/russian_journal_of_pain/reviewer/submission/1\' class=\'submissionUrl-style-class\'>https://ojs-msph.ru/index.php/russian_journal_of_pain/reviewer/submission/1</a><br>Имя пользователя: vllukin</p><br/><br/>\n________________________________________________________________________ <br/>\n<a href=\"https://ojs-msph.ru/index.php/russian_journal_of_pain\">Российский журнал боли</a>'),
(8, 1048586, 7, 4, '2021-05-06 14:39:35', '2021-05-06 14:39:35', NULL, NULL),
(9, 1048586, 8, 4, '2021-05-06 14:42:54', '2021-05-06 14:42:54', NULL, NULL),
(10, 1048586, 9, 4, '2021-05-10 22:26:45', '2021-05-10 22:26:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `level` bigint(20) NOT NULL,
  `type` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_read` datetime DEFAULT NULL,
  `assoc_type` bigint(20) DEFAULT NULL,
  `assoc_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `notifications`
--

INSERT INTO `notifications` (`notification_id`, `context_id`, `user_id`, `level`, `type`, `date_created`, `date_read`, `assoc_type`, `assoc_id`) VALUES
(25, 1, 0, 2, 16777243, '2020-04-21 09:55:33', NULL, 1048585, 1),
(26, 1, 0, 2, 16777245, '2020-04-21 09:55:33', NULL, 1048585, 1),
(36, 1, 0, 2, 16777236, '2020-04-21 10:22:07', '2020-04-21 10:22:08', 523, 1),
(40, 1, 2, 2, 16777219, '2020-04-21 10:25:02', NULL, 517, 1),
(45, 1, 2, 3, 16777239, '2020-04-21 11:16:39', '2020-04-21 11:23:51', 1048585, 1),
(49, 1, 1, 2, 16777235, '2020-04-21 11:18:23', NULL, 1048585, 1),
(50, 1, 2, 2, 16777254, '2020-04-21 11:18:23', '2020-04-21 11:18:25', 1048585, 1),
(61, 2, 0, 2, 16777243, '2021-01-27 20:54:02', NULL, 1048585, 2),
(62, 2, 0, 2, 16777245, '2021-01-27 20:54:02', NULL, 1048585, 2),
(64, 2, 0, 2, 16777236, '2021-01-27 20:55:14', '2021-01-27 20:55:17', 523, 2),
(67, 2, 4, 2, 16777219, '2021-01-27 20:58:25', NULL, 517, 2),
(68, 2, 4, 2, 16777251, '2021-01-27 20:59:56', '2021-01-27 20:59:59', 1048585, 2),
(78, 2, 0, 2, 16777243, '2021-05-06 14:32:10', NULL, 1048585, 3),
(79, 2, 0, 2, 16777245, '2021-05-06 14:32:10', NULL, 1048585, 3),
(90, 2, 0, 2, 16777243, '2021-05-06 14:42:22', NULL, 1048585, 4),
(91, 2, 0, 2, 16777245, '2021-05-06 14:42:22', NULL, 1048585, 4),
(94, 2, 0, 2, 16777236, '2021-05-06 14:48:33', '2021-05-06 14:48:37', 523, 3),
(95, 2, 4, 2, 16777231, '2021-05-06 14:48:33', NULL, 1048585, 4),
(97, 2, 0, 2, 16777236, '2021-05-06 14:52:08', '2021-05-06 14:52:12', 523, 4),
(102, 2, 3, 2, 16777219, '2021-05-06 14:55:33', NULL, 517, 3),
(103, 2, 0, 2, 16777236, '2021-05-06 14:57:21', '2021-05-06 14:57:26', 523, 5),
(107, 2, 3, 2, 16777219, '2021-05-06 15:04:53', NULL, 517, 4),
(108, 2, 4, 2, 16777230, '2021-05-06 15:07:19', NULL, 1048585, 3),
(109, 2, 3, 2, 16777251, '2021-05-06 15:07:19', '2021-05-06 15:07:22', 1048585, 3),
(113, 2, 4, 2, 16777219, '2021-05-06 15:12:02', NULL, 517, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `notification_mail_list`
--

CREATE TABLE `notification_mail_list` (
  `notification_mail_list_id` bigint(20) NOT NULL,
  `email` varchar(90) NOT NULL,
  `confirmed` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(40) NOT NULL,
  `context` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `notification_settings`
--

CREATE TABLE `notification_settings` (
  `notification_id` bigint(20) NOT NULL,
  `locale` varchar(14) DEFAULT NULL,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `notification_subscription_settings`
--

CREATE TABLE `notification_subscription_settings` (
  `setting_id` bigint(20) NOT NULL,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` text,
  `user_id` bigint(20) NOT NULL,
  `context` bigint(20) NOT NULL,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `oai_resumption_tokens`
--

CREATE TABLE `oai_resumption_tokens` (
  `token` varchar(32) NOT NULL,
  `expire` bigint(20) NOT NULL,
  `record_offset` int(11) NOT NULL,
  `params` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `plugin_settings`
--

CREATE TABLE `plugin_settings` (
  `plugin_name` varchar(80) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `setting_name` varchar(80) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `plugin_settings`
--

INSERT INTO `plugin_settings` (`plugin_name`, `context_id`, `setting_name`, `setting_value`, `setting_type`) VALUES
('acronplugin', 0, 'crontab', '[{\"className\":\"plugins.generic.usageStats.UsageStatsLoader\",\"frequency\":{\"hour\":24},\"args\":[\"autoStage\"]},{\"className\":\"plugins.generic.usageStats.UsageStatsLoader\",\"frequency\":{\"hour\":24},\"args\":[\"autoStage\"]},{\"className\":\"plugins.importexport.datacite.DataciteInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.doaj.DOAJInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.crossref.CrossrefInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.generic.usageStats.UsageStatsLoader\",\"frequency\":{\"hour\":24},\"args\":[\"autoStage\"]},{\"className\":\"plugins.importexport.datacite.DataciteInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.doaj.DOAJInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.crossref.CrossrefInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.generic.usageStats.UsageStatsLoader\",\"frequency\":{\"hour\":24},\"args\":[\"autoStage\"]},{\"className\":\"plugins.importexport.datacite.DataciteInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.doaj.DOAJInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.crossref.CrossrefInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.generic.usageStats.UsageStatsLoader\",\"frequency\":{\"hour\":24},\"args\":[\"autoStage\"]},{\"className\":\"plugins.importexport.datacite.DataciteInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.doaj.DOAJInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.crossref.CrossrefInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.generic.usageStats.UsageStatsLoader\",\"frequency\":{\"hour\":24},\"args\":[\"autoStage\"]},{\"className\":\"plugins.importexport.datacite.DataciteInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.doaj.DOAJInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"plugins.importexport.crossref.CrossrefInfoSender\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"lib.pkp.classes.task.ReviewReminder\",\"frequency\":{\"hour\":24},\"args\":[]},{\"className\":\"lib.pkp.classes.task.StatisticsReport\",\"frequency\":{\"day\":\"1\"},\"args\":[]},{\"className\":\"classes.tasks.SubscriptionExpiryReminder\",\"frequency\":{\"day\":\"1\"},\"args\":[]}]', 'object'),
('acronplugin', 0, 'enabled', '1', 'bool'),
('announcementfeedplugin', 1, 'enabled', '1', 'bool'),
('browseblockplugin', 1, 'enabled', '1', 'bool'),
('browseblockplugin', 2, 'enabled', '1', 'bool'),
('customblockmanagerplugin', 1, 'enabled', '1', 'bool'),
('customblockmanagerplugin', 2, 'enabled', '1', 'bool'),
('defaultthemeplugin', 0, 'enabled', '1', 'bool'),
('defaultthemeplugin', 1, 'baseColour', '#1E6292', 'string'),
('defaultthemeplugin', 1, 'enabled', '1', 'bool'),
('defaultthemeplugin', 1, 'showDescriptionInJournalIndex', 'false', 'string'),
('defaultthemeplugin', 1, 'typography', 'notoSans', 'string'),
('defaultthemeplugin', 1, 'useHomepageImageAsHeader', 'false', 'string'),
('defaultthemeplugin', 2, 'enabled', '1', 'bool'),
('developedbyblockplugin', 0, 'enabled', '0', 'bool'),
('developedbyblockplugin', 0, 'seq', '0', 'int'),
('developedbyblockplugin', 1, 'enabled', '0', 'bool'),
('developedbyblockplugin', 1, 'seq', '0', 'int'),
('developedbyblockplugin', 2, 'enabled', '1', 'bool'),
('developedbyblockplugin', 2, 'seq', '0', 'int'),
('doipubidplugin', 1, 'enabled', '1', 'bool'),
('driverplugin', 1, 'enabled', '0', 'bool'),
('dublincoremetaplugin', 1, 'enabled', '1', 'bool'),
('dublincoremetaplugin', 2, 'enabled', '1', 'bool'),
('googleanalyticsplugin', 1, 'enabled', '1', 'bool'),
('googlescholarplugin', 1, 'enabled', '1', 'bool'),
('googlescholarplugin', 2, 'enabled', '1', 'bool'),
('healthsciencesthemeplugin', 1, 'baseColour', '#10BECA', 'string'),
('healthsciencesthemeplugin', 1, 'enabled', '1', 'bool'),
('healthsciencesthemeplugin', 2, 'baseColour', '#10BECA', 'string'),
('healthsciencesthemeplugin', 2, 'enabled', '1', 'bool'),
('htmlarticlegalleyplugin', 1, 'enabled', '1', 'bool'),
('htmlarticlegalleyplugin', 2, 'enabled', '1', 'bool'),
('informationblockplugin', 1, 'enabled', '1', 'bool'),
('informationblockplugin', 1, 'seq', '7', 'int'),
('informationblockplugin', 2, 'enabled', '1', 'bool'),
('informationblockplugin', 2, 'seq', '7', 'int'),
('languagetoggleblockplugin', 0, 'enabled', '1', 'bool'),
('languagetoggleblockplugin', 0, 'seq', '4', 'int'),
('languagetoggleblockplugin', 1, 'enabled', '1', 'bool'),
('languagetoggleblockplugin', 1, 'seq', '4', 'int'),
('languagetoggleblockplugin', 2, 'enabled', '1', 'bool'),
('languagetoggleblockplugin', 2, 'seq', '4', 'int'),
('lensgalleyplugin', 1, 'enabled', '1', 'bool'),
('lensgalleyplugin', 2, 'enabled', '1', 'bool'),
('makesubmissionblockplugin', 1, 'enabled', '1', 'bool'),
('makesubmissionblockplugin', 2, 'enabled', '1', 'bool'),
('orcidprofileplugin', 1, 'enabled', '1', 'bool'),
('orcidprofileplugin', 2, 'enabled', '1', 'bool'),
('pdfjsviewerplugin', 1, 'enabled', '1', 'bool'),
('pdfjsviewerplugin', 2, 'enabled', '1', 'bool'),
('recommendbyauthorplugin', 1, 'enabled', '1', 'bool'),
('recommendbysimilarityplugin', 1, 'enabled', '1', 'bool'),
('resolverplugin', 1, 'enabled', '1', 'bool'),
('resolverplugin', 2, 'enabled', '1', 'bool'),
('staticpagesplugin', 1, 'enabled', '1', 'bool'),
('staticpagesplugin', 2, 'enabled', '1', 'bool'),
('subscriptionblockplugin', 1, 'enabled', '1', 'bool'),
('subscriptionblockplugin', 1, 'seq', '2', 'int'),
('subscriptionblockplugin', 2, 'enabled', '1', 'bool'),
('subscriptionblockplugin', 2, 'seq', '2', 'int'),
('tinymceplugin', 0, 'enabled', '1', 'bool'),
('tinymceplugin', 1, 'enabled', '1', 'bool'),
('tinymceplugin', 2, 'enabled', '1', 'bool'),
('usageeventplugin', 0, 'enabled', '1', 'bool'),
('usageeventplugin', 0, 'uniqueSiteId', '5e9dcbdcf1e68', 'string'),
('usagestatsplugin', 0, 'accessLogFileParseRegex', '/^(?P<ip>\\S+) \\S+ \\S+ \\[(?P<date>.*?)\\] \"\\S+ (?P<url>\\S+).*?\" (?P<returnCode>\\S+) \\S+ \".*?\" \"(?P<userAgent>.*?)\"/', 'string'),
('usagestatsplugin', 0, 'chartType', 'bar', 'string'),
('usagestatsplugin', 0, 'createLogFiles', '1', 'bool'),
('usagestatsplugin', 0, 'datasetMaxCount', '4', 'string'),
('usagestatsplugin', 0, 'enabled', '1', 'bool'),
('usagestatsplugin', 0, 'optionalColumns', '[\"city\",\"region\"]', 'object'),
('webfeedplugin', 1, 'displayItems', '1', 'bool'),
('webfeedplugin', 1, 'displayPage', 'homepage', 'string'),
('webfeedplugin', 1, 'enabled', '1', 'bool'),
('webfeedplugin', 2, 'displayItems', '1', 'bool'),
('webfeedplugin', 2, 'displayPage', 'homepage', 'string'),
('webfeedplugin', 2, 'enabled', '1', 'bool');

-- --------------------------------------------------------

--
-- Структура таблицы `publications`
--

CREATE TABLE `publications` (
  `publication_id` bigint(20) NOT NULL,
  `access_status` bigint(20) DEFAULT '0',
  `date_published` date DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `primary_contact_id` bigint(20) DEFAULT NULL,
  `section_id` bigint(20) DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `submission_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `url_path` varchar(64) DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `publications`
--

INSERT INTO `publications` (`publication_id`, `access_status`, `date_published`, `last_modified`, `primary_contact_id`, `section_id`, `seq`, `submission_id`, `status`, `url_path`, `version`) VALUES
(1, 0, NULL, '2020-04-22 11:51:40', 1, 1, 0, 1, 5, NULL, 1),
(2, 0, NULL, '2021-01-27 20:53:58', 2, 2, 0, 2, 1, NULL, 1),
(3, 0, NULL, '2021-05-06 14:32:06', 3, 2, 0, 3, 1, NULL, 1),
(4, 0, NULL, '2021-05-06 14:42:19', 4, 2, 0, 4, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `publication_categories`
--

CREATE TABLE `publication_categories` (
  `publication_id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `publication_galleys`
--

CREATE TABLE `publication_galleys` (
  `galley_id` bigint(20) NOT NULL,
  `locale` varchar(14) DEFAULT NULL,
  `publication_id` bigint(20) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `submission_file_id` bigint(20) UNSIGNED DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `remote_url` varchar(2047) DEFAULT NULL,
  `is_approved` tinyint(4) NOT NULL DEFAULT '0',
  `url_path` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `publication_galley_settings`
--

CREATE TABLE `publication_galley_settings` (
  `galley_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `publication_settings`
--

CREATE TABLE `publication_settings` (
  `publication_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `publication_settings`
--

INSERT INTO `publication_settings` (`publication_id`, `locale`, `setting_name`, `setting_value`) VALUES
(1, '', 'categoryIds', '[]'),
(1, '', 'citationsRaw', '1.	Муминова А.И., Плужникова М.С., Рязанцева С.В. «Полипозные риносинуиты» Ташкент. «Медицина» УзССР, 1990, 152 с.  [Muminova A.I., Pluzhnikova M.S., Ryazanceva S.V. «Polipoznye rinosinuity» Tashkent. «Medicina» UzSSR, 1990, 152 s. (In Russ.).]\r\n2.	European Position Paper on Rhinosinusitis and Nasal Polyps 2012, стр. 56 \r\n3.	Рязанцев С.В. Современные взгляды на терапию полипозных риносинуситов. //Пульмунология и аллергология  2007 IV P. 22-25. [Ryazancev S.V. Sovremennye vzglyady na terapiyu polipoznyh rinosinusitov. //Pul\'munologiya i allergologiya  2007 IV P. 22-25. (In Russ.).]\r\n4.	Ланцов А.А. и др.  Эпидемиология полипозных риносинуситов. СПБ., 1999 . [Lancov A.A. i dr.  Epidemiologiya polipoznyh rinosinusitov. SPB., 1999 . (In Russ.).]\r\n5.	Пискунов Г.З. Полипозный риносинусит /Г. З. Пискунов – М. : ГЭОТАР-Медиа, 2016 . – 96 с. [Piskunov G.Z. Polipoznyj rinosinusit /G. Z. Piskunov – M. : GEHOTAR-Media, 2016 . – 96 s. (In Russ.).]\r\n6.	Whitney W. Stevens, Anju T. Peters, Lydia Suh, James E. Norton, Robert C. Kern and David B. Conley, et al. A retrospective, cross-sectional study reveals that women with CRSwNP have more severe disease than men. Immunity, Inflammation and Disease 2015; 3(1): 14–22.  https://doi.org/10.1002/iid3.46\r\n7.	Helmy AM, EI Ghazzawi IF, Mandour MA, Shehata MA. The effect of estrogen on the nasal respiratory mucosa. An experimental histopatological and histochemical study. J. Laryngology Otology 1975 Dec: 89(12):1229-41 https://doi.org/10.1017/s0022215100081597\r\n8.	Parfyonova E.V. The linkage of 3Н estradiol with citozoles receptors rats’ olfactory tunica. Cytology, 28(5),1986, p. 570-572 \r\n9.	Zhao X, Dong Z, Yang Z. An experimental observation on the influence of the different levels of estradiol on the nasal mucosa. Zhonghua Er Bi Yan Hou Ke Za Zhi, 1994 Apr: 29(2):98-100\r\n10.	Zhao X, Dong Z, Zhu J. A preliminary study on the effect of estrogen on nasal mucosal hyperreactivity. Zhonghua Er Bi Yan Hou Ke Za Zhi, 1997 Feb: 32(1):35-37. \r\n11.	D. Zabolotnyi, S. Yaremchuk .The new aspects of polyp fotmation.  Recent Advances in Rhinosinusitis and Nasal Polyposis, 2015  Kugler Publications, Amsterdam, The Netherlands; pp. 29-31   \r\n12.	Philpott CM, El-Alami M, Murty GE. The effect of the steroid sex hormones on the nasal airway during the normal menstrual cycle. Clin Otolaryngol Allied Sci 2004;29:138–42. https://doi.org/10.1111/j.1365-2273.2004.00801.x\r\n13.	Soylu Özler G, Akbay E, Akkoca AN, Karapınar OS, Şimşek GÖ. Does menopause effect nasal mucociliary clearance time? Eur Arch Otorhinolaryngol 2015;272:363–6 https://doi.org/10.1007/s00405-014-3118-z\r\n14.	Deveci HS, Deveci I, Habesoglu M, et al. Histological evaluation of rat larynx in experimental polycystic ovary syndrome model. Eur Arch Otorhinolaryngol 2012; 269:1945–50. https://doi.org/10.1007/s00405-012-1978-7\r\n15.	Suna Kabil Kucura, Ali Sevena, Beril Yuksela, et al. Alterations in nasal mucociliary activity in polycystic ovary syndrome. European Journal of Obstetrics & Gynecology and Reproductive Biology 207 (2016) 169–172. https://doi.org/10.1016/j.ejogrb.2016.10.023\r\n16.	Заболотный Д.И., Яремчук С.Э. Теоретическое обоснование влияния эстрогенов на рост и развитие полипов носа.  Ринологія, №4, 2006\r\n17.	Kato, A., A. Peters, L. Suh, R. Carter, K. E. Harris, and R. Chandra, et al. 2008. Evidence of a role for B cell-activating factor of the TNF family in the pathogenesis of chronic rhinosinusitis with nasal polyps. J. Allergy Clin. Immunol. 121(6): 1385–1392, 1392.e 1381–1382.  https://doi.org/10.1016/j.jaci.2008.03.002\r\n18.	Verthelyi,D.I., and S.A.Ahmed,1998. Estrogen in creases the number of plasma cells and enhances their autoantibody production in nonautoimmune C57BL/6 mice. Cell Immunol. 189(2): 125–134.  https://doi.org/10.1006/cimm.1998.1372\r\n19.	Donald Dennis, David Robertson, Luke Curtis and Judson Black. Fungal exposure endocrinopathy in sinusitis with growth hormone deficiency: Dennis-Robertson syndrome. Toxicology and Industrial Health. 2009 Oct-Nov;25(9-10):669-80.  https://doi.org/10.1177/0748233709348266'),
(1, '', 'copyrightYear', '2020'),
(1, '', 'issueId', '1'),
(1, 'en_US', 'abstract', '<p>Hormones are biologically active substances that have a regulating effect on metabolism and physiological functions. At the end of the twentieth century, scientists actively studied the effect of hormones on different organs and systems, including the nasal mucosa. Clinicians began to notice that a change in the level of sex hormones leads to such conditions as rhinitis in pregnant women, nasal congestion during the period of ovulation. In the course of the research, receptors for estradiol were found, and effects on the part of the respiratory system caused by its excess and deficiency were described. Later, scientists tried to find a connection between the development of chronic rhinosinusitis with nasal polyps (CRSwNP) and changes in the level of sex hormones, in particular estradiol, arguing that the disease has gender and age characteristics. Nasal polyps, as a rule, develops in people of mature age and practically does not occur in children, men are more likely to suffer from it, but women have the most severe forms. In this regard, the researchers suggested possible pathogenetic mechanisms of the effect of hormonal status on the formation of nasal polyps, which is reflected in this article.</p>'),
(1, 'en_US', 'copyrightHolder', 'Russian Journal of Pain'),
(1, 'en_US', 'prefix', ''),
(1, 'en_US', 'subtitle', ''),
(1, 'en_US', 'title', 'Participation of sex hormones in the formation of nazal polypas. Background'),
(1, 'en_US', 'type', 'text'),
(1, 'ru_RU', 'abstract', '<p>Гормоны -&nbsp;<a href=\"https://ru.wikipedia.org/wiki/%D0%91%D0%B8%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F\">биологически</a>&nbsp;активные вещества, оказывающие регулирующее влияние на обмен веществ и&nbsp;<a href=\"https://ru.wikipedia.org/wiki/%D0%A4%D0%B8%D0%B7%D0%B8%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F\">физиологические</a>&nbsp;функции. В конце ХХ века ученые активно изучали влияние гормонов на различные органы и системы, в том числе на слизистую оболочку полости носа. Клиницисты стали замечать, что изменение уровня половых гормонов ведет к таким состояниям, как ринит беременных, заложенность носа в период овуляции. В ходе исследований были найдены рецепторы к эстрадиолу, описаны эффекты со стороны дыхательной системы, вызываемые его избытком и недостатком. Позднее учёные попытались найти связь развития полипозного риносинусита с изменением уровня половых гормонов, в частности эстрадиола, аргументируя это тем, что болезнь имеет гендерные и возрастные особенности. Полипоз, как правило, развивается у людей зрелого возраста и практически не встречается у детей, чаще им страдают мужчины, но наиболее тяжелым формам подвержены женщины. В связи с этим, исследователи предложили возможные патогенетические механизмы влияния гормонального фона на формирование назальных полипов, что отражено в данной статье.</p>'),
(1, 'ru_RU', 'copyrightHolder', 'Российский журнал боли'),
(1, 'ru_RU', 'prefix', ''),
(1, 'ru_RU', 'subtitle', ''),
(1, 'ru_RU', 'title', 'Участие половых гормонов в формировании назальных полипов. История вопроса'),
(1, 'ru_RU', 'type', 'Текст'),
(2, '', 'categoryIds', '[]'),
(2, 'en_US', 'abstract', '<p>123</p>'),
(2, 'en_US', 'prefix', ''),
(2, 'en_US', 'subtitle', ''),
(2, 'en_US', 'title', 'Simple submission'),
(2, 'ru_RU', 'abstract', '<p>123</p>'),
(2, 'ru_RU', 'prefix', ''),
(2, 'ru_RU', 'subtitle', ''),
(2, 'ru_RU', 'title', 'Просто статья'),
(3, '', 'categoryIds', '[]'),
(3, 'en_US', 'abstract', ''),
(3, 'en_US', 'prefix', ''),
(3, 'en_US', 'subtitle', ''),
(3, 'en_US', 'title', 'test 1'),
(3, 'ru_RU', 'abstract', '<p>111</p>'),
(3, 'ru_RU', 'prefix', ''),
(3, 'ru_RU', 'subtitle', ''),
(3, 'ru_RU', 'title', 'Тестовая статья 1'),
(4, '', 'categoryIds', '[]'),
(4, 'en_US', 'abstract', ''),
(4, 'en_US', 'prefix', ''),
(4, 'en_US', 'subtitle', ''),
(4, 'en_US', 'title', 'Test-test'),
(4, 'ru_RU', 'abstract', '<p>tttt</p>'),
(4, 'ru_RU', 'prefix', ''),
(4, 'ru_RU', 'subtitle', ''),
(4, 'ru_RU', 'title', 'Проверка');

-- --------------------------------------------------------

--
-- Структура таблицы `queries`
--

CREATE TABLE `queries` (
  `query_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `stage_id` tinyint(4) NOT NULL DEFAULT '1',
  `seq` double NOT NULL DEFAULT '0',
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `closed` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `queries`
--

INSERT INTO `queries` (`query_id`, `assoc_type`, `assoc_id`, `stage_id`, `seq`, `date_posted`, `date_modified`, `closed`) VALUES
(5, 1048585, 1, 1, 1, NULL, NULL, 0),
(6, 1048585, 1, 4, 2, NULL, NULL, 0),
(8, 1048585, 3, 1, 1, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `query_participants`
--

CREATE TABLE `query_participants` (
  `query_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `query_participants`
--

INSERT INTO `query_participants` (`query_id`, `user_id`) VALUES
(5, 2),
(6, 2),
(8, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `queued_payments`
--

CREATE TABLE `queued_payments` (
  `queued_payment_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `payment_data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `review_assignments`
--

CREATE TABLE `review_assignments` (
  `review_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `reviewer_id` bigint(20) NOT NULL,
  `competing_interests` text,
  `recommendation` tinyint(4) DEFAULT NULL,
  `date_assigned` datetime DEFAULT NULL,
  `date_notified` datetime DEFAULT NULL,
  `date_confirmed` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `date_acknowledged` datetime DEFAULT NULL,
  `date_due` datetime DEFAULT NULL,
  `date_response_due` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reminder_was_automatic` tinyint(4) NOT NULL DEFAULT '0',
  `declined` tinyint(4) NOT NULL DEFAULT '0',
  `cancelled` tinyint(4) NOT NULL DEFAULT '0',
  `reviewer_file_id` bigint(20) DEFAULT NULL,
  `date_rated` datetime DEFAULT NULL,
  `date_reminded` datetime DEFAULT NULL,
  `quality` tinyint(4) DEFAULT NULL,
  `review_round_id` bigint(20) NOT NULL,
  `stage_id` tinyint(4) NOT NULL DEFAULT '1',
  `review_method` tinyint(4) NOT NULL DEFAULT '1',
  `round` tinyint(4) NOT NULL DEFAULT '1',
  `step` tinyint(4) NOT NULL DEFAULT '1',
  `review_form_id` bigint(20) DEFAULT NULL,
  `unconsidered` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `review_assignments`
--

INSERT INTO `review_assignments` (`review_id`, `submission_id`, `reviewer_id`, `competing_interests`, `recommendation`, `date_assigned`, `date_notified`, `date_confirmed`, `date_completed`, `date_acknowledged`, `date_due`, `date_response_due`, `last_modified`, `reminder_was_automatic`, `declined`, `cancelled`, `reviewer_file_id`, `date_rated`, `date_reminded`, `quality`, `review_round_id`, `stage_id`, `review_method`, `round`, `step`, `review_form_id`, `unconsidered`) VALUES
(1, 1, 2, NULL, 1, '2020-04-21 10:22:40', '2020-04-21 10:22:40', '2020-04-21 10:24:20', '2020-04-21 10:25:03', '2020-04-21 10:26:42', '2020-05-19 00:00:00', '2020-05-19 00:00:00', '2020-04-21 10:26:42', 0, 0, 0, NULL, '2020-04-21 10:26:31', NULL, 5, 1, 3, 2, 1, 4, NULL, 0),
(2, 2, 4, NULL, 1, '2021-01-27 20:55:58', '2021-01-27 20:55:59', '2021-01-27 20:57:14', '2021-01-27 20:58:26', NULL, '2021-02-24 00:00:00', '2021-02-24 00:00:00', '2021-01-27 20:58:26', 0, 0, 0, NULL, NULL, NULL, NULL, 2, 3, 3, 1, 4, NULL, 0),
(3, 3, 4, NULL, 1, '2021-05-06 14:52:56', '2021-05-06 14:52:56', '2021-05-06 14:54:40', '2021-05-06 14:55:33', NULL, '2021-06-03 00:00:00', '2021-06-03 00:00:00', '2021-05-06 14:55:33', 0, 0, 0, NULL, NULL, NULL, NULL, 4, 3, 3, 1, 4, NULL, 0),
(4, 3, 4, NULL, 1, '2021-05-06 14:58:09', '2021-05-06 14:58:09', '2021-05-06 15:02:14', '2021-05-06 15:04:53', NULL, '2021-06-03 00:00:00', '2021-06-03 00:00:00', '2021-05-06 15:04:53', 0, 0, 0, NULL, NULL, NULL, NULL, 5, 3, 3, 2, 4, NULL, 0),
(5, 4, 4, NULL, 1, '2021-05-06 15:10:32', '2021-05-06 15:10:32', '2021-05-06 15:11:28', '2021-05-06 15:12:02', NULL, '2021-06-03 00:00:00', '2021-06-03 00:00:00', '2021-05-06 15:12:02', 0, 0, 0, NULL, NULL, NULL, NULL, 3, 3, 3, 1, 4, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `review_files`
--

CREATE TABLE `review_files` (
  `review_id` bigint(20) NOT NULL,
  `submission_file_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `review_files`
--

INSERT INTO `review_files` (`review_id`, `submission_file_id`) VALUES
(1, 5),
(2, 10),
(3, 14),
(4, 17),
(5, 13);

-- --------------------------------------------------------

--
-- Структура таблицы `review_forms`
--

CREATE TABLE `review_forms` (
  `review_form_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `seq` double DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `review_form_elements`
--

CREATE TABLE `review_form_elements` (
  `review_form_element_id` bigint(20) NOT NULL,
  `review_form_id` bigint(20) NOT NULL,
  `seq` double DEFAULT NULL,
  `element_type` bigint(20) DEFAULT NULL,
  `required` tinyint(4) DEFAULT NULL,
  `included` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `review_form_element_settings`
--

CREATE TABLE `review_form_element_settings` (
  `review_form_element_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `review_form_responses`
--

CREATE TABLE `review_form_responses` (
  `review_form_element_id` bigint(20) NOT NULL,
  `review_id` bigint(20) NOT NULL,
  `response_type` varchar(6) DEFAULT NULL,
  `response_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `review_form_settings`
--

CREATE TABLE `review_form_settings` (
  `review_form_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `review_rounds`
--

CREATE TABLE `review_rounds` (
  `review_round_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `stage_id` bigint(20) DEFAULT NULL,
  `round` tinyint(4) NOT NULL,
  `review_revision` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `review_rounds`
--

INSERT INTO `review_rounds` (`review_round_id`, `submission_id`, `stage_id`, `round`, `review_revision`, `status`) VALUES
(1, 1, 3, 1, NULL, 4),
(2, 2, 3, 1, NULL, 4),
(3, 4, 3, 1, NULL, 8),
(4, 3, 3, 1, NULL, 2),
(5, 3, 3, 2, NULL, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `review_round_files`
--

CREATE TABLE `review_round_files` (
  `submission_id` bigint(20) NOT NULL,
  `review_round_id` bigint(20) NOT NULL,
  `stage_id` tinyint(4) NOT NULL,
  `submission_file_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `review_round_files`
--

INSERT INTO `review_round_files` (`submission_id`, `review_round_id`, `stage_id`, `submission_file_id`) VALUES
(1, 1, 3, 5),
(2, 2, 3, 10),
(3, 4, 3, 14),
(3, 4, 3, 15),
(3, 4, 3, 16),
(3, 5, 3, 17),
(3, 5, 3, 18),
(4, 3, 3, 13),
(4, 3, 3, 19);

-- --------------------------------------------------------

--
-- Структура таблицы `scheduled_tasks`
--

CREATE TABLE `scheduled_tasks` (
  `class_name` varchar(255) NOT NULL,
  `last_run` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `scheduled_tasks`
--

INSERT INTO `scheduled_tasks` (`class_name`, `last_run`) VALUES
('classes.tasks.SubscriptionExpiryReminder', '2021-05-01 01:07:41'),
('lib.pkp.classes.task.ReviewReminder', '2021-05-21 10:31:14'),
('lib.pkp.classes.task.StatisticsReport', '2021-05-01 01:07:41'),
('plugins.generic.usageStats.UsageStatsLoader', '2021-05-21 10:31:14'),
('plugins.importexport.crossref.CrossrefInfoSender', '2021-05-21 10:31:14'),
('plugins.importexport.datacite.DataciteInfoSender', '2021-05-21 10:31:14'),
('plugins.importexport.doaj.DOAJInfoSender', '2021-05-21 10:31:14'),
('plugins.importexport.medra.MedraInfoSender', '2021-05-08 03:19:16');

-- --------------------------------------------------------

--
-- Структура таблицы `sections`
--

CREATE TABLE `sections` (
  `section_id` bigint(20) NOT NULL,
  `journal_id` bigint(20) NOT NULL,
  `review_form_id` bigint(20) DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `editor_restricted` tinyint(4) NOT NULL DEFAULT '0',
  `meta_indexed` tinyint(4) NOT NULL DEFAULT '0',
  `meta_reviewed` tinyint(4) NOT NULL DEFAULT '1',
  `abstracts_not_required` tinyint(4) NOT NULL DEFAULT '0',
  `hide_title` tinyint(4) NOT NULL DEFAULT '0',
  `hide_author` tinyint(4) NOT NULL DEFAULT '0',
  `abstract_word_count` bigint(20) DEFAULT NULL,
  `is_inactive` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sections`
--

INSERT INTO `sections` (`section_id`, `journal_id`, `review_form_id`, `seq`, `editor_restricted`, `meta_indexed`, `meta_reviewed`, `abstracts_not_required`, `hide_title`, `hide_author`, `abstract_word_count`, `is_inactive`) VALUES
(1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0),
(2, 2, 0, 0, 0, 1, 1, 0, 0, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `section_settings`
--

CREATE TABLE `section_settings` (
  `section_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `section_settings`
--

INSERT INTO `section_settings` (`section_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, 'ru_RU', 'abbrev', 'СТ', 'string'),
(1, 'ru_RU', 'policy', 'Политика раздела по умолчанию', 'string'),
(1, 'ru_RU', 'title', 'Статьи', 'string'),
(2, 'en_US', 'abbrev', '', 'string'),
(2, 'en_US', 'identifyType', '', 'string'),
(2, 'en_US', 'policy', '', 'string'),
(2, 'en_US', 'title', '', 'string'),
(2, 'ru_RU', 'abbrev', 'СТ', 'string'),
(2, 'ru_RU', 'identifyType', '', 'string'),
(2, 'ru_RU', 'policy', '<p>Политика раздела по умолчанию</p>', 'string'),
(2, 'ru_RU', 'title', 'Статьи', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE `sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `ip_address` varchar(39) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created` bigint(20) NOT NULL DEFAULT '0',
  `last_used` bigint(20) NOT NULL DEFAULT '0',
  `remember` tinyint(4) NOT NULL DEFAULT '0',
  `data` text,
  `domain` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `user_id`, `ip_address`, `user_agent`, `created`, `last_used`, `remember`, `data`, `domain`) VALUES
('04e5da0f65e2c71abea1c64a3f296f76', 1, '195.91.227.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36', 1621598810, 1621598860, 1, 'csrf|a:2:{s:9:\"timestamp\";i:1621598861;s:5:\"token\";s:32:\"780402e7f182c90f45cf0c6d73acf789\";}userId|i:1;username|s:10:\"superadmin\";', 'ojs-msph.ru'),
('05ade4e305837c23a850da26af78ee2d', NULL, '35.166.239.71', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621594152, 1621594152, 0, '', 'ojs-msph.ru'),
('0992be1d1fca160918bfd32ed2045117', NULL, '34.216.202.28', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621594299, 1621594299, 0, '', 'ojs-msph.ru'),
('0b32c40f62430d20ca5c25d7fefd8ea2', NULL, '77.51.135.54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36', 1621502597, 1621502598, 0, '', 'ojs-msph.ru'),
('14ff0ceb0a7b187634ed2ef7ee04101e', NULL, '54.191.157.216', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621594043, 1621594043, 0, '', 'ojs-msph.ru'),
('1c989a80785b31838753bd004e4d225e', NULL, '13.233.246.168', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1621600616, 1621600616, 0, '', 'ojs-msph.ru'),
('3305fbec3e4c2859c23e2e5909340c14', NULL, '77.51.135.54', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36', 1621503138, 1621503138, 0, '', 'ojs-msph.ru'),
('5be34cfb75dd875ec53a99faf3398f55', NULL, '34.215.99.21', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621424482, 1621424482, 0, '', 'ojs-msph.ru'),
('6f061c72aac333eee0458fe488d34ccb', NULL, '51.158.108.61', '', 1621411764, 1621411764, 0, '', 'ojs-msph.ru'),
('6f5fb0db34d6be6025c55bf28f28687c', NULL, '212.47.251.118', '', 1621466624, 1621466624, 0, '', 'ojs-msph.ru'),
('73f31b31d4129fdf96ea3319a84329b4', NULL, '54.70.35.34', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621505037, 1621505037, 0, '', 'ojs-msph.ru'),
('80e61942641b67095f1f40de6d4101d1', NULL, '138.246.253.24', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.146 Safari/537.36', 1621545039, 1621545039, 0, '', 'ojs-msph.ru'),
('8d95a3aed58fb145ba638a32b0a67e80', NULL, '31.177.68.100', 'index (+http://www.nic.ru)', 1621594786, 1621594786, 0, '', 'ojs-msph.ru'),
('93c4c4b17f07ddc40dd8855e749428da', NULL, '34.220.146.78', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621594128, 1621594128, 0, '', 'ojs-msph.ru'),
('975f8bae19bb7c96260c9b15c4873460', NULL, '34.221.250.105', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621594153, 1621594153, 0, '', 'ojs-msph.ru'),
('98acf1bc7437c72005835d646c2d31a1', NULL, '84.201.163.250', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36', 1621436231, 1621436231, 0, '', 'ojs-msph.ru'),
('adf3a061753d395052a74861b53ab02c', NULL, '34.219.45.232', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621594228, 1621594228, 0, '', 'ojs-msph.ru'),
('b1012d910499d6731fe73a4586754faf', NULL, '89.163.242.241', 'Dy robot 1.0', 1621447638, 1621447638, 0, '', 'ojs-msph.ru'),
('b1878bf7b71edc3866b826f0fdf1eb10', NULL, '52.26.189.82', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621419709, 1621419709, 0, '', 'ojs-msph.ru'),
('bb0c10b9332bc8892b49bfe4f06abdc6', NULL, '54.202.93.53', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621505039, 1621505039, 0, '', 'ojs-msph.ru'),
('bcb6385c4c1964f25fd5d473aa9cabd0', NULL, '93.170.123.14', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322) Babya Discoverer 8.0:', 1621442038, 1621442038, 0, '', 'ojs-msph.ru'),
('be44908cdd1d6b17c4aa1340d96fe885', NULL, '3.86.247.252', 'Go-http-client/1.1', 1621458815, 1621458815, 0, '', 'ojs-msph.ru'),
('cbec258d984d2071f4d02d15ba1b0443', NULL, '157.230.40.120', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36', 1621582273, 1621582274, 0, '', 'ojs-msph.ru'),
('d368f27ad1535f06808957959e0a99ce', NULL, '176.59.212.207', 'Mozilla/5.0 (Windows NT 6.1; rv:85.0) Gecko/20100101 Firefox/85.0', 1621501027, 1621501027, 0, 'csrf|a:2:{s:9:\"timestamp\";i:1621501028;s:5:\"token\";s:32:\"f4db9743ded351aff286b48d37a8888d\";}', 'ojs-msph.ru'),
('e4f8948930bee01701a0679482247c99', NULL, '185.12.124.78', 'Mozilla/5.0 (compatible; BackupLand/1.0; https://go.backupland.com/; Domain check for viruses;)', 1621496406, 1621496406, 0, '', 'ojs-msph.ru'),
('eb9c9eb0d8dc9836ef630660752fccaf', NULL, '3.98.140.9', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 1621402687, 1621402687, 0, '', 'ojs-msph.ru'),
('efab37bacf98c549df735521f6fb4856', NULL, '52.38.29.58', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1621419666, 1621419666, 0, '', 'ojs-msph.ru');

-- --------------------------------------------------------

--
-- Структура таблицы `site`
--

CREATE TABLE `site` (
  `redirect` bigint(20) NOT NULL DEFAULT '0',
  `primary_locale` varchar(14) NOT NULL,
  `min_password_length` tinyint(4) NOT NULL DEFAULT '6',
  `installed_locales` varchar(1024) NOT NULL DEFAULT 'en_US',
  `supported_locales` varchar(1024) DEFAULT NULL,
  `original_style_file_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `site`
--

INSERT INTO `site` (`redirect`, `primary_locale`, `min_password_length`, `installed_locales`, `supported_locales`, `original_style_file_name`) VALUES
(0, 'ru_RU', 6, '[\"en_US\",\"ru_RU\"]', '[\"en_US\",\"ru_RU\"]', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_settings`
--

CREATE TABLE `site_settings` (
  `setting_name` varchar(255) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `site_settings`
--

INSERT INTO `site_settings` (`setting_name`, `locale`, `setting_value`) VALUES
('contactEmail', 'ru_RU', 'lukin@mediasphera.ru'),
('contactName', 'en_US', 'Open Journal Systems'),
('contactName', 'ru_RU', 'Open Journal Systems'),
('themePluginPath', '', 'default');

-- --------------------------------------------------------

--
-- Структура таблицы `stage_assignments`
--

CREATE TABLE `stage_assignments` (
  `stage_assignment_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `user_group_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `date_assigned` datetime NOT NULL,
  `recommend_only` tinyint(4) NOT NULL DEFAULT '0',
  `can_change_metadata` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `stage_assignments`
--

INSERT INTO `stage_assignments` (`stage_assignment_id`, `submission_id`, `user_group_id`, `user_id`, `date_assigned`, `recommend_only`, `can_change_metadata`) VALUES
(1, 1, 14, 1, '2020-04-21 09:40:17', 0, 0),
(2, 1, 3, 2, '2020-04-21 10:21:13', 0, 1),
(3, 1, 7, 2, '2020-04-21 11:16:39', 0, 0),
(4, 2, 19, 4, '2021-01-27 20:52:49', 0, 1),
(5, 2, 20, 4, '2021-01-27 20:54:41', 0, 1),
(6, 3, 31, 4, '2021-05-06 14:31:11', 0, 0),
(7, 4, 31, 4, '2021-05-06 14:41:16', 0, 0),
(8, 4, 20, 4, '2021-05-06 14:48:20', 0, 1),
(9, 3, 20, 3, '2021-05-06 14:51:37', 0, 1),
(10, 3, 24, 4, '2021-05-06 15:07:49', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `static_pages`
--

CREATE TABLE `static_pages` (
  `static_page_id` bigint(20) NOT NULL,
  `path` varchar(255) NOT NULL,
  `context_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `static_page_settings`
--

CREATE TABLE `static_page_settings` (
  `static_page_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` longtext,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `subeditor_submission_group`
--

CREATE TABLE `subeditor_submission_group` (
  `context_id` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `submissions`
--

CREATE TABLE `submissions` (
  `submission_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `current_publication_id` bigint(20) DEFAULT NULL,
  `date_last_activity` datetime DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `stage_id` bigint(20) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `submission_progress` tinyint(4) NOT NULL DEFAULT '1',
  `locale` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `submissions`
--

INSERT INTO `submissions` (`submission_id`, `context_id`, `current_publication_id`, `date_last_activity`, `date_submitted`, `last_modified`, `stage_id`, `status`, `submission_progress`, `locale`) VALUES
(1, 1, 1, '2020-04-22 11:51:40', '2020-04-21 09:55:33', '2020-04-21 10:22:40', 5, 5, 0, 'ru_RU'),
(2, 2, 2, '2021-05-06 14:38:57', '2021-01-27 20:54:02', '2021-01-27 20:55:59', 4, 1, 0, 'ru_RU'),
(3, 2, 3, '2021-05-06 15:07:49', '2021-05-06 14:32:09', '2021-05-06 14:58:09', 4, 1, 0, 'ru_RU'),
(4, 2, 4, '2021-05-06 15:12:02', '2021-05-06 14:42:22', '2021-05-06 15:10:32', 3, 1, 0, 'ru_RU');

-- --------------------------------------------------------

--
-- Структура таблицы `submission_artwork_files`
--

CREATE TABLE `submission_artwork_files` (
  `file_id` bigint(20) NOT NULL,
  `revision` bigint(20) NOT NULL,
  `caption` text,
  `credit` varchar(255) DEFAULT NULL,
  `copyright_owner` varchar(255) DEFAULT NULL,
  `copyright_owner_contact` text,
  `permission_terms` text,
  `permission_file_id` bigint(20) DEFAULT NULL,
  `chapter_id` bigint(20) DEFAULT NULL,
  `contact_author` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `submission_comments`
--

CREATE TABLE `submission_comments` (
  `comment_id` bigint(20) NOT NULL,
  `comment_type` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `assoc_id` bigint(20) NOT NULL,
  `author_id` bigint(20) NOT NULL,
  `comment_title` text,
  `comments` text,
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `viewable` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `submission_comments`
--

INSERT INTO `submission_comments` (`comment_id`, `comment_type`, `role_id`, `submission_id`, `assoc_id`, `author_id`, `comment_title`, `comments`, `date_posted`, `date_modified`, `viewable`) VALUES
(1, 1, 4096, 1, 1, 2, '', '<p>Все отлично</p>', '2020-04-21 10:25:02', NULL, 1),
(2, 1, 4096, 2, 2, 4, '', '<p>Здесь текст рецензии для автора и редактора</p>', '2021-01-27 20:58:25', NULL, 1),
(3, 1, 4096, 2, 2, 4, '', '<p>Рецензия только для редактора.</p>', '2021-01-27 20:58:25', NULL, 0),
(4, 1, 4096, 3, 3, 4, '', '<p>для автора и редактора</p>', '2021-05-06 14:55:33', NULL, 1),
(5, 1, 4096, 3, 3, 4, '', '<p>только для редактора</p>', '2021-05-06 14:55:33', NULL, 0),
(6, 1, 4096, 3, 4, 4, '', '<p>Рецензию для этого материала для автора и редактора</p>', '2021-05-06 15:04:53', NULL, 1),
(7, 1, 4096, 3, 4, 4, '', '<p>Рецензия для этого материала для редактора</p>', '2021-05-06 15:04:53', NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `submission_files`
--

CREATE TABLE `submission_files` (
  `submission_file_id` bigint(20) UNSIGNED NOT NULL,
  `source_submission_file_id` bigint(20) DEFAULT NULL,
  `submission_id` bigint(20) NOT NULL,
  `genre_id` bigint(20) DEFAULT NULL,
  `file_stage` bigint(20) NOT NULL,
  `direct_sales_price` varchar(255) DEFAULT NULL,
  `sales_type` varchar(255) DEFAULT NULL,
  `viewable` tinyint(4) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `uploader_user_id` bigint(20) DEFAULT NULL,
  `assoc_type` bigint(20) DEFAULT NULL,
  `assoc_id` bigint(20) DEFAULT NULL,
  `file_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `submission_files`
--

INSERT INTO `submission_files` (`submission_file_id`, `source_submission_file_id`, `submission_id`, `genre_id`, `file_stage`, `direct_sales_price`, `sales_type`, `viewable`, `created_at`, `updated_at`, `uploader_user_id`, `assoc_type`, `assoc_id`, `file_id`) VALUES
(3, NULL, 1, 1, 2, NULL, NULL, 1, '2020-04-21 09:45:06', '2020-04-21 09:45:06', 1, NULL, NULL, 1),
(4, NULL, 1, 8, 2, NULL, NULL, 1, '2020-04-21 09:45:30', '2020-04-21 09:45:30', 1, NULL, NULL, 2),
(5, 3, 1, 1, 4, NULL, NULL, 1, '2020-04-21 09:45:06', '2020-04-21 10:22:07', 1, 523, 1, 3),
(6, 5, 1, 1, 6, NULL, NULL, 1, '2020-04-21 09:45:06', '2020-04-21 11:17:26', 1, NULL, NULL, 4),
(7, 6, 1, 1, 9, NULL, NULL, 1, '2020-04-21 09:45:06', '2020-04-21 11:18:06', 1, NULL, NULL, 5),
(8, 7, 1, 1, 11, NULL, NULL, 0, '2020-04-21 09:45:06', '2020-04-21 11:18:23', 1, NULL, NULL, 6),
(9, NULL, 2, 13, 2, NULL, NULL, 1, '2021-01-27 20:53:05', '2021-01-27 20:53:05', 4, NULL, NULL, 7),
(10, 9, 2, 13, 4, NULL, NULL, 1, '2021-01-27 20:53:05', '2021-01-27 20:55:14', 4, 523, 2, 8),
(11, NULL, 3, 13, 2, NULL, NULL, 1, '2021-05-06 14:31:22', '2021-05-06 14:31:22', 4, NULL, NULL, 9),
(12, NULL, 4, 13, 2, NULL, NULL, 1, '2021-05-06 14:41:29', '2021-05-06 14:41:29', 4, NULL, NULL, 10),
(13, 12, 4, 13, 4, NULL, NULL, 1, '2021-05-06 14:41:29', '2021-05-06 14:48:33', 4, 523, 3, 11),
(14, 11, 3, 13, 4, NULL, NULL, 1, '2021-05-06 14:31:22', '2021-05-06 14:52:08', 4, 523, 4, 12),
(15, NULL, 3, NULL, 5, NULL, NULL, 0, '2021-05-06 14:55:22', '2021-05-06 14:55:22', 4, 517, 3, 13),
(16, NULL, 3, 13, 15, NULL, NULL, 0, '2021-05-06 14:57:08', '2021-05-06 14:57:08', 3, 523, 4, 14),
(17, 16, 3, 13, 4, NULL, NULL, 1, '2021-05-06 14:57:08', '2021-05-06 14:57:21', 3, 523, 5, 15),
(18, NULL, 3, NULL, 5, NULL, NULL, 1, '2021-05-06 15:04:41', '2021-05-06 15:04:41', 4, 517, 4, 16),
(19, NULL, 4, NULL, 5, NULL, NULL, 0, '2021-05-06 15:11:42', '2021-05-06 15:11:42', 4, 517, 5, 17);

-- --------------------------------------------------------

--
-- Структура таблицы `submission_file_logs`
--

CREATE TABLE `submission_file_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `article_id` int(11) NOT NULL,
  `old_file_id` int(11) DEFAULT NULL,
  `new_file_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `submission_file_revisions`
--

CREATE TABLE `submission_file_revisions` (
  `revision_id` bigint(20) UNSIGNED NOT NULL,
  `submission_file_id` bigint(20) UNSIGNED NOT NULL,
  `file_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `submission_file_revisions`
--

INSERT INTO `submission_file_revisions` (`revision_id`, `submission_file_id`, `file_id`) VALUES
(1, 3, 1),
(2, 4, 2),
(3, 5, 3),
(4, 6, 4),
(5, 7, 5),
(6, 8, 6),
(7, 9, 7),
(8, 10, 8),
(9, 11, 9),
(10, 12, 10),
(11, 13, 11),
(12, 14, 12),
(13, 15, 13),
(14, 16, 14),
(15, 17, 15),
(16, 18, 16),
(17, 19, 17);

-- --------------------------------------------------------

--
-- Структура таблицы `submission_file_settings`
--

CREATE TABLE `submission_file_settings` (
  `submission_file_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL DEFAULT 'string'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `submission_file_settings`
--

INSERT INTO `submission_file_settings` (`submission_file_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(3, 'en_US', 'name', 'Test - text.docx', 'string'),
(3, 'ru_RU', 'name', 'Тест - текст.docx', 'string'),
(4, '', 'dateCreated', '2020-04-21', 'string'),
(4, '', 'language', 'RU', 'string'),
(4, 'en_US', 'creator', 'Participation of sex hormones in the formation of nazal polypas. Background', 'string'),
(4, 'en_US', 'description', 'Hormones are biologically active substances that have a regulating effect on metabolism and physiological functions. At the end of the twentieth century, scientists actively studied the effect of hormones on different organs and systems, including the nasal mucosa. Clinicians began to notice that a change in the level of sex hormones leads to such conditions as rhinitis in pregnant women, nasal congestion during the period of ovulation. In the course of the research, receptors for estradiol were found, and effects on the part of the respiratory system caused by its excess and deficiency were described. Later, scientists tried to find a connection between the development of chronic rhinosinusitis with nasal polyps (CRSwNP) and changes in the level of sex hormones, in particular estradiol, arguing that the disease has gender and age characteristics. Nasal polyps, as a rule, develops in people of mature age and practically does not occur in children, men are more likely to suffer from it, but women have the most severe forms. In this regard, the researchers suggested possible pathogenetic mechanisms of the effect of hormonal status on the formation of nasal polyps, which is reflected in this article.', 'string'),
(4, 'en_US', 'name', 'Test.docx', 'string'),
(4, 'en_US', 'publisher', 'Media Sphera Publihers', 'string'),
(4, 'en_US', 'source', '', 'string'),
(4, 'en_US', 'sponsor', 'Yu.P. Moiseeva, G.Z. Piskunov', 'string'),
(4, 'en_US', 'subject', '', 'string'),
(4, 'ru_RU', 'creator', 'Участие половых гормонов в формировании назальных полипов. История вопроса', 'string'),
(4, 'ru_RU', 'description', 'Гормоны - биологически активные вещества, оказывающие регулирующее влияние на обмен веществ и физиологические функции. В конце ХХ века ученые активно изучали влияние гормонов на различные органы и системы, в том числе на слизистую оболочку полости носа. Клиницисты стали замечать, что изменение уровня половых гормонов ведет к таким состояниям, как ринит беременных, заложенность носа в период овуляции. В ходе исследований были найдены рецепторы к эстрадиолу, описаны эффекты со стороны дыхательной системы, вызываемые его избытком и недостатком. Позднее учёные попытались найти связь развития полипозного риносинусита с изменением уровня половых гормонов, в частности эстрадиола, аргументируя это тем, что болезнь имеет гендерные и возрастные особенности. Полипоз, как правило, развивается у людей зрелого возраста и практически не встречается у детей, чаще им страдают мужчины, но наиболее тяжелым формам подвержены женщины. В связи с этим, исследователи предложили возможные патогенетические механизмы влияния гормонального фона на формирование назальных полипов, что отражено в данной статье.', 'string'),
(4, 'ru_RU', 'name', 'Тест.docx', 'string'),
(4, 'ru_RU', 'publisher', 'Издательство Медиа Сфера', 'string'),
(4, 'ru_RU', 'source', '', 'string'),
(4, 'ru_RU', 'sponsor', 'Ю.П. Моисеева, Г.З. Пискунов', 'string'),
(4, 'ru_RU', 'subject', '', 'string'),
(5, 'en_US', 'name', 'Test - text.docx', 'string'),
(5, 'ru_RU', 'name', 'Текст статьи, Тест - текст.docx', 'string'),
(6, 'en_US', 'name', 'Test - text.docx', 'string'),
(6, 'ru_RU', 'name', 'Текст статьи, Тест - текст.docx', 'string'),
(7, 'en_US', 'name', 'Test - text.docx', 'string'),
(7, 'ru_RU', 'name', 'Текст статьи, Тест - текст.docx', 'string'),
(8, 'en_US', 'name', 'Test - text.docx', 'string'),
(8, 'ru_RU', 'name', 'Текст статьи, Тест - текст.docx', 'string'),
(9, 'en_US', 'name', '', 'string'),
(9, 'ru_RU', 'name', 'admin, 4090-33487-3-CE.doc', 'string'),
(10, 'en_US', 'name', '', 'string'),
(10, 'ru_RU', 'name', 'Текст статьи, 4090-33487-3-CE.doc', 'string'),
(11, 'en_US', 'name', '', 'string'),
(11, 'ru_RU', 'name', 'admin, 4090-33487-3-CE.doc', 'string'),
(12, 'en_US', 'name', '', 'string'),
(12, 'ru_RU', 'name', 'admin, 4090-33487-3-CE.doc', 'string'),
(13, 'en_US', 'name', '', 'string'),
(13, 'ru_RU', 'name', 'Текст статьи, 4090-33487-3-CE.doc', 'string'),
(14, 'en_US', 'name', '', 'string'),
(14, 'ru_RU', 'name', 'Текст статьи, 4090-33487-3-CE.doc', 'string'),
(15, 'en_US', 'name', '', 'string'),
(15, 'ru_RU', 'name', ', 4090-33487-3-CE.doc', 'string'),
(16, 'en_US', 'name', '', 'string'),
(16, 'ru_RU', 'name', 'Текст статьи, 9627-57577-1-SM.docx', 'string'),
(17, 'en_US', 'name', '', 'string'),
(17, 'ru_RU', 'name', 'Текст статьи, 9627-57577-1-SM.docx', 'string'),
(18, 'en_US', 'name', '', 'string'),
(18, 'ru_RU', 'name', ', 4090-33487-3-CE.doc', 'string'),
(19, 'en_US', 'name', '', 'string'),
(19, 'ru_RU', 'name', ', 4090-33487-3-CE.doc', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `submission_search_keyword_list`
--

CREATE TABLE `submission_search_keyword_list` (
  `keyword_id` bigint(20) NOT NULL,
  `keyword_text` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `submission_search_objects`
--

CREATE TABLE `submission_search_objects` (
  `object_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `type` int(11) NOT NULL,
  `assoc_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `submission_search_object_keywords`
--

CREATE TABLE `submission_search_object_keywords` (
  `object_id` bigint(20) NOT NULL,
  `keyword_id` bigint(20) NOT NULL,
  `pos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `submission_settings`
--

CREATE TABLE `submission_settings` (
  `submission_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `submission_supplementary_files`
--

CREATE TABLE `submission_supplementary_files` (
  `file_id` bigint(20) NOT NULL,
  `revision` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `submission_supplementary_files`
--

INSERT INTO `submission_supplementary_files` (`file_id`, `revision`) VALUES
(4, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `submission_tombstones`
--

CREATE TABLE `submission_tombstones` (
  `tombstone_id` bigint(20) NOT NULL,
  `submission_id` bigint(20) NOT NULL,
  `date_deleted` datetime NOT NULL,
  `journal_id` bigint(20) NOT NULL,
  `section_id` bigint(20) NOT NULL,
  `set_spec` varchar(255) NOT NULL,
  `set_name` varchar(255) NOT NULL,
  `oai_identifier` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `subscriptions`
--

CREATE TABLE `subscriptions` (
  `subscription_id` bigint(20) NOT NULL,
  `journal_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `type_id` bigint(20) NOT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `membership` varchar(40) DEFAULT NULL,
  `reference_number` varchar(40) DEFAULT NULL,
  `notes` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `subscription_types`
--

CREATE TABLE `subscription_types` (
  `type_id` bigint(20) NOT NULL,
  `journal_id` bigint(20) NOT NULL,
  `cost` double NOT NULL,
  `currency_code_alpha` varchar(3) NOT NULL,
  `non_expiring` tinyint(4) NOT NULL DEFAULT '0',
  `duration` smallint(6) DEFAULT NULL,
  `format` smallint(6) NOT NULL,
  `institutional` tinyint(4) NOT NULL DEFAULT '0',
  `membership` tinyint(4) NOT NULL DEFAULT '0',
  `disable_public_display` tinyint(4) NOT NULL,
  `seq` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `subscription_type_settings`
--

CREATE TABLE `subscription_type_settings` (
  `type_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `temporary_files`
--

CREATE TABLE `temporary_files` (
  `file_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `file_name` varchar(90) NOT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `date_uploaded` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `usage_stats_temporary_records`
--

CREATE TABLE `usage_stats_temporary_records` (
  `assoc_id` bigint(20) NOT NULL,
  `assoc_type` bigint(20) NOT NULL,
  `day` bigint(20) NOT NULL,
  `entry_time` bigint(20) NOT NULL,
  `metric` bigint(20) NOT NULL DEFAULT '1',
  `country_id` varchar(2) DEFAULT NULL,
  `region` varchar(2) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `load_id` varchar(255) NOT NULL,
  `file_type` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(2047) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `mailing_address` varchar(255) DEFAULT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `country` varchar(90) DEFAULT NULL,
  `locales` varchar(255) DEFAULT NULL,
  `gossip` text,
  `date_last_email` datetime DEFAULT NULL,
  `date_registered` datetime NOT NULL,
  `date_validated` datetime DEFAULT NULL,
  `date_last_login` datetime NOT NULL,
  `must_change_password` tinyint(4) DEFAULT NULL,
  `auth_id` bigint(20) DEFAULT NULL,
  `auth_str` varchar(255) DEFAULT NULL,
  `disabled` tinyint(4) NOT NULL DEFAULT '0',
  `disabled_reason` text,
  `inline_help` tinyint(4) DEFAULT NULL,
  `api_token` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `url`, `phone`, `mailing_address`, `billing_address`, `country`, `locales`, `gossip`, `date_last_email`, `date_registered`, `date_validated`, `date_last_login`, `must_change_password`, `auth_id`, `auth_str`, `disabled`, `disabled_reason`, `inline_help`, `api_token`) VALUES
(1, 'superadmin', '$2y$10$e114pIYWp1yQqUUdTJbUnOYHbWJ1Ecy6JiGzQUYxs7pXFZx6GuHQ6', 'lukin@mediasphera.ru', '', '', '', NULL, 'RU', 'en_US:ru_RU', NULL, NULL, '2020-04-20 18:43:49', NULL, '2021-05-21 15:06:54', 0, NULL, NULL, 0, NULL, 1, NULL),
(2, 'vllukin', '$2y$10$7U18W1A57RHrIMT0uMdxZuGJQ8MoVz1/eu6PG7uDB9d/HG1MpubYq', 'stim.vov@gmail.com', '', '', '', NULL, 'RU', 'en_US:ru_RU', NULL, NULL, '2020-04-21 10:18:18', NULL, '2020-04-22 11:06:49', 0, NULL, NULL, 0, NULL, 1, NULL),
(3, 'test', '$2y$10$/DAm6BH1aqW5d.EkIFwjO.bRuCuh8j/WoapOs2Q99l7.3VFDcyUaC', 'varmoch@mail.ru', '', '', '', NULL, '', '', NULL, NULL, '2020-04-29 16:12:33', NULL, '2020-04-29 16:12:33', 0, NULL, NULL, 0, NULL, 1, NULL),
(4, 'admin', '$2y$10$2CaSfIP3sOb2GDc6qS3No.oG7qrNQG7zgDXC/LsO9bvLflfhODqzW', 'natalya-molleker@yandex.ru', '', '', '', NULL, 'RU', '', NULL, NULL, '2020-05-04 12:49:34', NULL, '2021-05-18 10:39:02', 0, NULL, NULL, 0, NULL, 1, NULL),
(5, 'admin2', '$2y$10$vNem4pauXwbV.OZ9gyZdk.safMC1qvHe8uE0fXmdgKZDnJjnRmKVy', 'shoorick77@gmail.com', '', '', '', NULL, 'RU', '', NULL, NULL, '2020-06-17 17:53:50', NULL, '2020-06-17 17:53:50', 0, NULL, NULL, 0, NULL, 1, NULL),
(6, 'asvechkar', '$2y$10$MJjBKSKejfUg6/04rW8s7uYa.9I.xzJcodeSB3Z0ULp7AwuTp/dUu', 'asvechkar@gmail.com', '', '', '', NULL, '', '', NULL, NULL, '2021-02-05 14:48:36', NULL, '2021-02-21 13:31:33', 0, NULL, NULL, 0, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `user_groups`
--

CREATE TABLE `user_groups` (
  `user_group_id` bigint(20) NOT NULL,
  `context_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT '0',
  `show_title` tinyint(4) NOT NULL DEFAULT '1',
  `permit_self_registration` tinyint(4) NOT NULL DEFAULT '0',
  `permit_metadata_edit` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_groups`
--

INSERT INTO `user_groups` (`user_group_id`, `context_id`, `role_id`, `is_default`, `show_title`, `permit_self_registration`, `permit_metadata_edit`) VALUES
(1, 0, 1, 1, 0, 0, 0),
(2, 1, 16, 1, 0, 0, 1),
(3, 1, 16, 1, 0, 0, 1),
(4, 1, 16, 1, 0, 0, 1),
(5, 1, 17, 1, 0, 0, 1),
(6, 1, 17, 1, 0, 0, 0),
(7, 1, 4097, 1, 0, 0, 0),
(8, 1, 4097, 1, 0, 0, 0),
(9, 1, 4097, 1, 0, 0, 0),
(10, 1, 4097, 1, 0, 0, 0),
(11, 1, 4097, 1, 0, 0, 0),
(12, 1, 4097, 1, 0, 0, 0),
(13, 1, 4097, 1, 0, 0, 0),
(14, 1, 65536, 1, 0, 1, 0),
(15, 1, 65536, 1, 0, 0, 0),
(16, 1, 4096, 1, 0, 1, 0),
(17, 1, 1048576, 1, 0, 1, 0),
(18, 1, 2097152, 1, 0, 0, 0),
(19, 2, 16, 1, 0, 0, 1),
(20, 2, 16, 1, 0, 0, 1),
(21, 2, 16, 1, 0, 0, 1),
(22, 2, 17, 1, 0, 0, 1),
(23, 2, 17, 1, 0, 0, 0),
(24, 2, 4097, 1, 0, 0, 0),
(25, 2, 4097, 1, 0, 0, 0),
(26, 2, 4097, 1, 0, 0, 0),
(27, 2, 4097, 1, 0, 0, 0),
(28, 2, 4097, 1, 0, 0, 0),
(29, 2, 4097, 1, 0, 0, 0),
(30, 2, 4097, 1, 0, 0, 0),
(31, 2, 65536, 1, 0, 1, 0),
(32, 2, 65536, 1, 0, 0, 0),
(33, 2, 4096, 1, 0, 1, 0),
(34, 2, 1048576, 1, 0, 1, 0),
(35, 2, 2097152, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `user_group_settings`
--

CREATE TABLE `user_group_settings` (
  `user_group_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_group_settings`
--

INSERT INTO `user_group_settings` (`user_group_id`, `locale`, `setting_name`, `setting_value`, `setting_type`) VALUES
(1, 'en_US', 'name', 'Site Admin', 'string'),
(1, 'ru_RU', 'name', '##default.groups.name.siteAdmin##', 'string'),
(2, '', 'abbrevLocaleKey', 'default.groups.abbrev.manager', 'string'),
(2, '', 'nameLocaleKey', 'default.groups.name.manager', 'string'),
(2, 'en_US', 'abbrev', 'JM', 'string'),
(2, 'en_US', 'name', 'Journal manager', 'string'),
(2, 'ru_RU', 'abbrev', 'УпрЖ', 'string'),
(2, 'ru_RU', 'name', 'Управляющий журналом', 'string'),
(3, '', 'abbrevLocaleKey', 'default.groups.abbrev.editor', 'string'),
(3, '', 'nameLocaleKey', 'default.groups.name.editor', 'string'),
(3, 'en_US', 'abbrev', 'JE', 'string'),
(3, 'en_US', 'name', 'Journal editor', 'string'),
(3, 'ru_RU', 'abbrev', 'РедЖ', 'string'),
(3, 'ru_RU', 'name', 'Редактор журнала', 'string'),
(4, '', 'abbrevLocaleKey', 'default.groups.abbrev.productionEditor', 'string'),
(4, '', 'nameLocaleKey', 'default.groups.name.productionEditor', 'string'),
(4, 'en_US', 'abbrev', 'ProdE', 'string'),
(4, 'en_US', 'name', 'Production editor', 'string'),
(4, 'ru_RU', 'abbrev', 'ВыпРед', 'string'),
(4, 'ru_RU', 'name', 'Выпускающий редактор', 'string'),
(5, '', 'abbrevLocaleKey', 'default.groups.abbrev.sectionEditor', 'string'),
(5, '', 'nameLocaleKey', 'default.groups.name.sectionEditor', 'string'),
(5, 'en_US', 'abbrev', 'SecE', 'string'),
(5, 'en_US', 'name', 'Section editor', 'string'),
(5, 'ru_RU', 'abbrev', 'РедР', 'string'),
(5, 'ru_RU', 'name', 'Редактор раздела', 'string'),
(6, '', 'abbrevLocaleKey', 'default.groups.abbrev.guestEditor', 'string'),
(6, '', 'nameLocaleKey', 'default.groups.name.guestEditor', 'string'),
(6, 'en_US', 'abbrev', 'GE', 'string'),
(6, 'en_US', 'name', 'Guest editor', 'string'),
(6, 'ru_RU', 'abbrev', 'ПРед', 'string'),
(6, 'ru_RU', 'name', 'Приглашенный редактор', 'string'),
(7, '', 'abbrevLocaleKey', 'default.groups.abbrev.copyeditor', 'string'),
(7, '', 'nameLocaleKey', 'default.groups.name.copyeditor', 'string'),
(7, 'en_US', 'abbrev', 'CE', 'string'),
(7, 'en_US', 'name', 'Copyeditor', 'string'),
(7, 'ru_RU', 'abbrev', 'ЛитРед', 'string'),
(7, 'ru_RU', 'name', 'Литературный редактор', 'string'),
(8, '', 'abbrevLocaleKey', 'default.groups.abbrev.designer', 'string'),
(8, '', 'nameLocaleKey', 'default.groups.name.designer', 'string'),
(8, 'en_US', 'abbrev', 'Design', 'string'),
(8, 'en_US', 'name', 'Designer', 'string'),
(8, 'ru_RU', 'abbrev', 'Дизайн', 'string'),
(8, 'ru_RU', 'name', 'Дизайнер', 'string'),
(9, '', 'abbrevLocaleKey', 'default.groups.abbrev.funding', 'string'),
(9, '', 'nameLocaleKey', 'default.groups.name.funding', 'string'),
(9, 'en_US', 'abbrev', 'FC', 'string'),
(9, 'en_US', 'name', 'Funding coordinator', 'string'),
(9, 'ru_RU', 'abbrev', 'КФ', 'string'),
(9, 'ru_RU', 'name', 'Координатор по фондам', 'string'),
(10, '', 'abbrevLocaleKey', 'default.groups.abbrev.indexer', 'string'),
(10, '', 'nameLocaleKey', 'default.groups.name.indexer', 'string'),
(10, 'en_US', 'abbrev', 'IND', 'string'),
(10, 'en_US', 'name', 'Indexer', 'string'),
(10, 'ru_RU', 'abbrev', 'Инд', 'string'),
(10, 'ru_RU', 'name', 'Индексатор', 'string'),
(11, '', 'abbrevLocaleKey', 'default.groups.abbrev.layoutEditor', 'string'),
(11, '', 'nameLocaleKey', 'default.groups.name.layoutEditor', 'string'),
(11, 'en_US', 'abbrev', 'LE', 'string'),
(11, 'en_US', 'name', 'Layout Editor', 'string'),
(11, 'ru_RU', 'abbrev', 'Верст', 'string'),
(11, 'ru_RU', 'name', 'Верстальщик', 'string'),
(12, '', 'abbrevLocaleKey', 'default.groups.abbrev.marketing', 'string'),
(12, '', 'nameLocaleKey', 'default.groups.name.marketing', 'string'),
(12, 'en_US', 'abbrev', 'MS', 'string'),
(12, 'en_US', 'name', 'Marketing and sales coordinator', 'string'),
(12, 'ru_RU', 'abbrev', 'МиП', 'string'),
(12, 'ru_RU', 'name', 'Координатор по маркетингу и продажам', 'string'),
(13, '', 'abbrevLocaleKey', 'default.groups.abbrev.proofreader', 'string'),
(13, '', 'nameLocaleKey', 'default.groups.name.proofreader', 'string'),
(13, 'en_US', 'abbrev', 'PR', 'string'),
(13, 'en_US', 'name', 'Proofreader', 'string'),
(13, 'ru_RU', 'abbrev', 'Корр', 'string'),
(13, 'ru_RU', 'name', 'Корректор', 'string'),
(14, '', 'abbrevLocaleKey', 'default.groups.abbrev.author', 'string'),
(14, '', 'nameLocaleKey', 'default.groups.name.author', 'string'),
(14, 'en_US', 'abbrev', 'AU', 'string'),
(14, 'en_US', 'name', 'Author', 'string'),
(14, 'ru_RU', 'abbrev', 'Авт', 'string'),
(14, 'ru_RU', 'name', 'Автор', 'string'),
(15, '', 'abbrevLocaleKey', 'default.groups.abbrev.translator', 'string'),
(15, '', 'nameLocaleKey', 'default.groups.name.translator', 'string'),
(15, 'en_US', 'abbrev', 'Trans', 'string'),
(15, 'en_US', 'name', 'Translator', 'string'),
(15, 'ru_RU', 'abbrev', 'Перев', 'string'),
(15, 'ru_RU', 'name', 'Переводчик', 'string'),
(16, '', 'abbrevLocaleKey', 'default.groups.abbrev.externalReviewer', 'string'),
(16, '', 'nameLocaleKey', 'default.groups.name.externalReviewer', 'string'),
(16, 'en_US', 'abbrev', 'R', 'string'),
(16, 'en_US', 'name', 'Reviewer', 'string'),
(16, 'ru_RU', 'abbrev', 'Рец', 'string'),
(16, 'ru_RU', 'name', 'Рецензент', 'string'),
(17, '', 'abbrevLocaleKey', 'default.groups.abbrev.reader', 'string'),
(17, '', 'nameLocaleKey', 'default.groups.name.reader', 'string'),
(17, 'en_US', 'abbrev', 'Read', 'string'),
(17, 'en_US', 'name', 'Reader', 'string'),
(17, 'ru_RU', 'abbrev', 'Чит', 'string'),
(17, 'ru_RU', 'name', 'Читатель', 'string'),
(18, '', 'abbrevLocaleKey', 'default.groups.abbrev.subscriptionManager', 'string'),
(18, '', 'nameLocaleKey', 'default.groups.name.subscriptionManager', 'string'),
(18, 'en_US', 'abbrev', 'SubM', 'string'),
(18, 'en_US', 'name', 'Subscription Manager', 'string'),
(18, 'ru_RU', 'abbrev', 'МПодп', 'string'),
(18, 'ru_RU', 'name', 'Менеджер по подписке', 'string'),
(19, '', 'abbrevLocaleKey', 'default.groups.abbrev.manager', 'string'),
(19, '', 'nameLocaleKey', 'default.groups.name.manager', 'string'),
(19, 'en_US', 'abbrev', 'JM', 'string'),
(19, 'en_US', 'name', 'Journal manager', 'string'),
(19, 'ru_RU', 'abbrev', 'УпрЖ', 'string'),
(19, 'ru_RU', 'name', 'Управляющий журналом', 'string'),
(20, '', 'abbrevLocaleKey', 'default.groups.abbrev.editor', 'string'),
(20, '', 'nameLocaleKey', 'default.groups.name.editor', 'string'),
(20, 'en_US', 'abbrev', 'JE', 'string'),
(20, 'en_US', 'name', 'Journal editor', 'string'),
(20, 'ru_RU', 'abbrev', 'РедЖ', 'string'),
(20, 'ru_RU', 'name', 'Редактор журнала', 'string'),
(21, '', 'abbrevLocaleKey', 'default.groups.abbrev.productionEditor', 'string'),
(21, '', 'nameLocaleKey', 'default.groups.name.productionEditor', 'string'),
(21, 'en_US', 'abbrev', 'ProdE', 'string'),
(21, 'en_US', 'name', 'Production editor', 'string'),
(21, 'ru_RU', 'abbrev', 'ВыпРед', 'string'),
(21, 'ru_RU', 'name', 'Выпускающий редактор', 'string'),
(22, '', 'abbrevLocaleKey', 'default.groups.abbrev.sectionEditor', 'string'),
(22, '', 'nameLocaleKey', 'default.groups.name.sectionEditor', 'string'),
(22, 'en_US', 'abbrev', 'SecE', 'string'),
(22, 'en_US', 'name', 'Section editor', 'string'),
(22, 'ru_RU', 'abbrev', 'РедР', 'string'),
(22, 'ru_RU', 'name', 'Редактор раздела', 'string'),
(23, '', 'abbrevLocaleKey', 'default.groups.abbrev.guestEditor', 'string'),
(23, '', 'nameLocaleKey', 'default.groups.name.guestEditor', 'string'),
(23, 'en_US', 'abbrev', 'GE', 'string'),
(23, 'en_US', 'name', 'Guest editor', 'string'),
(23, 'ru_RU', 'abbrev', 'ПРед', 'string'),
(23, 'ru_RU', 'name', 'Приглашенный редактор', 'string'),
(24, '', 'abbrevLocaleKey', 'default.groups.abbrev.copyeditor', 'string'),
(24, '', 'nameLocaleKey', 'default.groups.name.copyeditor', 'string'),
(24, 'en_US', 'abbrev', 'CE', 'string'),
(24, 'en_US', 'name', 'Copyeditor', 'string'),
(24, 'ru_RU', 'abbrev', 'ЛитРед', 'string'),
(24, 'ru_RU', 'name', 'Литературный редактор', 'string'),
(25, '', 'abbrevLocaleKey', 'default.groups.abbrev.designer', 'string'),
(25, '', 'nameLocaleKey', 'default.groups.name.designer', 'string'),
(25, 'en_US', 'abbrev', 'Design', 'string'),
(25, 'en_US', 'name', 'Designer', 'string'),
(25, 'ru_RU', 'abbrev', 'Дизайн', 'string'),
(25, 'ru_RU', 'name', 'Дизайнер', 'string'),
(26, '', 'abbrevLocaleKey', 'default.groups.abbrev.funding', 'string'),
(26, '', 'nameLocaleKey', 'default.groups.name.funding', 'string'),
(26, 'en_US', 'abbrev', 'FC', 'string'),
(26, 'en_US', 'name', 'Funding coordinator', 'string'),
(26, 'ru_RU', 'abbrev', 'КФ', 'string'),
(26, 'ru_RU', 'name', 'Координатор по фондам', 'string'),
(27, '', 'abbrevLocaleKey', 'default.groups.abbrev.indexer', 'string'),
(27, '', 'nameLocaleKey', 'default.groups.name.indexer', 'string'),
(27, 'en_US', 'abbrev', 'IND', 'string'),
(27, 'en_US', 'name', 'Indexer', 'string'),
(27, 'ru_RU', 'abbrev', 'Инд', 'string'),
(27, 'ru_RU', 'name', 'Индексатор', 'string'),
(28, '', 'abbrevLocaleKey', 'default.groups.abbrev.layoutEditor', 'string'),
(28, '', 'nameLocaleKey', 'default.groups.name.layoutEditor', 'string'),
(28, 'en_US', 'abbrev', 'LE', 'string'),
(28, 'en_US', 'name', 'Layout Editor', 'string'),
(28, 'ru_RU', 'abbrev', 'Верст', 'string'),
(28, 'ru_RU', 'name', 'Верстальщик', 'string'),
(29, '', 'abbrevLocaleKey', 'default.groups.abbrev.marketing', 'string'),
(29, '', 'nameLocaleKey', 'default.groups.name.marketing', 'string'),
(29, 'en_US', 'abbrev', 'MS', 'string'),
(29, 'en_US', 'name', 'Marketing and sales coordinator', 'string'),
(29, 'ru_RU', 'abbrev', 'МиП', 'string'),
(29, 'ru_RU', 'name', 'Координатор по маркетингу и продажам', 'string'),
(30, '', 'abbrevLocaleKey', 'default.groups.abbrev.proofreader', 'string'),
(30, '', 'nameLocaleKey', 'default.groups.name.proofreader', 'string'),
(30, 'en_US', 'abbrev', 'PR', 'string'),
(30, 'en_US', 'name', 'Proofreader', 'string'),
(30, 'ru_RU', 'abbrev', 'Корр', 'string'),
(30, 'ru_RU', 'name', 'Корректор', 'string'),
(31, '', 'abbrevLocaleKey', 'default.groups.abbrev.author', 'string'),
(31, '', 'nameLocaleKey', 'default.groups.name.author', 'string'),
(31, 'en_US', 'abbrev', 'AU', 'string'),
(31, 'en_US', 'name', 'Author', 'string'),
(31, 'ru_RU', 'abbrev', 'Авт', 'string'),
(31, 'ru_RU', 'name', 'Автор', 'string'),
(32, '', 'abbrevLocaleKey', 'default.groups.abbrev.translator', 'string'),
(32, '', 'nameLocaleKey', 'default.groups.name.translator', 'string'),
(32, 'en_US', 'abbrev', 'Trans', 'string'),
(32, 'en_US', 'name', 'Translator', 'string'),
(32, 'ru_RU', 'abbrev', 'Перев', 'string'),
(32, 'ru_RU', 'name', 'Переводчик', 'string'),
(33, '', 'abbrevLocaleKey', 'default.groups.abbrev.externalReviewer', 'string'),
(33, '', 'nameLocaleKey', 'default.groups.name.externalReviewer', 'string'),
(33, 'en_US', 'abbrev', 'R', 'string'),
(33, 'en_US', 'name', 'Reviewer', 'string'),
(33, 'ru_RU', 'abbrev', 'Рец', 'string'),
(33, 'ru_RU', 'name', 'Рецензент', 'string'),
(34, '', 'abbrevLocaleKey', 'default.groups.abbrev.reader', 'string'),
(34, '', 'nameLocaleKey', 'default.groups.name.reader', 'string'),
(34, 'en_US', 'abbrev', 'Read', 'string'),
(34, 'en_US', 'name', 'Reader', 'string'),
(34, 'ru_RU', 'abbrev', 'Чит', 'string'),
(34, 'ru_RU', 'name', 'Читатель', 'string'),
(35, '', 'abbrevLocaleKey', 'default.groups.abbrev.subscriptionManager', 'string'),
(35, '', 'nameLocaleKey', 'default.groups.name.subscriptionManager', 'string'),
(35, 'en_US', 'abbrev', 'SubM', 'string'),
(35, 'en_US', 'name', 'Subscription Manager', 'string'),
(35, 'ru_RU', 'abbrev', 'МПодп', 'string'),
(35, 'ru_RU', 'name', 'Менеджер по подписке', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `user_group_stage`
--

CREATE TABLE `user_group_stage` (
  `context_id` bigint(20) NOT NULL,
  `user_group_id` bigint(20) NOT NULL,
  `stage_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_group_stage`
--

INSERT INTO `user_group_stage` (`context_id`, `user_group_id`, `stage_id`) VALUES
(1, 3, 1),
(1, 3, 3),
(1, 3, 4),
(1, 3, 5),
(1, 4, 4),
(1, 4, 5),
(1, 5, 1),
(1, 5, 3),
(1, 5, 4),
(1, 5, 5),
(1, 6, 1),
(1, 6, 3),
(1, 6, 4),
(1, 6, 5),
(1, 7, 4),
(1, 8, 5),
(1, 9, 1),
(1, 9, 3),
(1, 10, 5),
(1, 11, 5),
(1, 12, 4),
(1, 13, 5),
(1, 14, 1),
(1, 14, 3),
(1, 14, 4),
(1, 14, 5),
(1, 15, 1),
(1, 15, 3),
(1, 15, 4),
(1, 15, 5),
(1, 16, 3),
(2, 20, 1),
(2, 20, 3),
(2, 20, 4),
(2, 20, 5),
(2, 21, 4),
(2, 21, 5),
(2, 22, 1),
(2, 22, 3),
(2, 22, 4),
(2, 22, 5),
(2, 23, 1),
(2, 23, 3),
(2, 23, 4),
(2, 23, 5),
(2, 24, 4),
(2, 25, 5),
(2, 26, 1),
(2, 26, 3),
(2, 27, 5),
(2, 28, 5),
(2, 29, 4),
(2, 30, 5),
(2, 31, 1),
(2, 31, 3),
(2, 31, 4),
(2, 31, 5),
(2, 32, 1),
(2, 32, 3),
(2, 32, 4),
(2, 32, 5),
(2, 33, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `user_interests`
--

CREATE TABLE `user_interests` (
  `user_id` bigint(20) NOT NULL,
  `controlled_vocab_entry_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `user_settings`
--

CREATE TABLE `user_settings` (
  `user_id` bigint(20) NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `assoc_type` bigint(20) DEFAULT '0',
  `assoc_id` bigint(20) DEFAULT '0',
  `setting_value` text,
  `setting_type` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_settings`
--

INSERT INTO `user_settings` (`user_id`, `locale`, `setting_name`, `assoc_type`, `assoc_id`, `setting_value`, `setting_type`) VALUES
(1, 'ru_RU', 'givenName', NULL, NULL, 'Владимир', 'string'),
(1, 'ru_RU', 'familyName', NULL, NULL, 'Лукин', 'string'),
(1, 'ru_RU', 'biography', NULL, NULL, '', 'string'),
(1, 'en_US', 'biography', NULL, NULL, '', 'string'),
(1, 'ru_RU', 'signature', NULL, NULL, '', 'string'),
(1, 'en_US', 'signature', NULL, NULL, '', 'string'),
(1, 'ru_RU', 'affiliation', NULL, NULL, '', 'string'),
(1, 'en_US', 'affiliation', NULL, NULL, '', 'string'),
(1, 'en_US', 'givenName', NULL, NULL, 'Vladimir', 'string'),
(1, 'en_US', 'familyName', NULL, NULL, 'Lukin', 'string'),
(1, 'ru_RU', 'preferredPublicName', NULL, NULL, '', 'string'),
(1, 'en_US', 'preferredPublicName', NULL, NULL, '', 'string'),
(1, '', 'orcid', NULL, NULL, '', 'string'),
(2, 'ru_RU', 'biography', NULL, NULL, '', 'string'),
(2, 'en_US', 'biography', NULL, NULL, '', 'string'),
(2, 'ru_RU', 'signature', NULL, NULL, '', 'string'),
(2, 'en_US', 'signature', NULL, NULL, '', 'string'),
(2, 'ru_RU', 'affiliation', NULL, NULL, '', 'string'),
(2, 'en_US', 'affiliation', NULL, NULL, '', 'string'),
(2, 'ru_RU', 'givenName', NULL, NULL, 'Владимир', 'string'),
(2, 'en_US', 'givenName', NULL, NULL, 'Vladimir', 'string'),
(2, 'ru_RU', 'familyName', NULL, NULL, 'Влукин', 'string'),
(2, 'en_US', 'familyName', NULL, NULL, 'Vlukin', 'string'),
(2, 'ru_RU', 'preferredPublicName', NULL, NULL, '', 'string'),
(2, 'en_US', 'preferredPublicName', NULL, NULL, '', 'string'),
(2, '', 'orcid', NULL, NULL, '', 'string'),
(3, 'ru_RU', 'biography', NULL, NULL, '', 'string'),
(3, 'ru_RU', 'signature', NULL, NULL, '', 'string'),
(3, 'ru_RU', 'affiliation', NULL, NULL, '', 'string'),
(3, 'ru_RU', 'givenName', NULL, NULL, 'Иван', 'string'),
(3, 'ru_RU', 'familyName', NULL, NULL, 'Тестов', 'string'),
(3, 'ru_RU', 'preferredPublicName', NULL, NULL, '', 'string'),
(3, '', 'orcid', NULL, NULL, '', 'string'),
(4, 'ru_RU', 'biography', NULL, NULL, '', 'string'),
(4, 'ru_RU', 'signature', NULL, NULL, '', 'string'),
(4, 'ru_RU', 'affiliation', NULL, NULL, '', 'string'),
(4, 'ru_RU', 'givenName', NULL, NULL, 'Наталья', 'string'),
(4, 'ru_RU', 'familyName', NULL, NULL, 'Моллекер', 'string'),
(4, 'ru_RU', 'preferredPublicName', NULL, NULL, '', 'string'),
(4, '', 'orcid', NULL, NULL, '', 'string'),
(5, 'ru_RU', 'biography', NULL, NULL, '', 'string'),
(5, 'ru_RU', 'signature', NULL, NULL, '', 'string'),
(5, 'ru_RU', 'affiliation', NULL, NULL, '', 'string'),
(5, 'ru_RU', 'givenName', NULL, NULL, 'Александр', 'string'),
(5, 'ru_RU', 'familyName', NULL, NULL, 'Сапожников', 'string'),
(5, 'ru_RU', 'preferredPublicName', NULL, NULL, '', 'string'),
(5, '', 'orcid', NULL, NULL, '', 'string'),
(6, 'ru_RU', 'biography', NULL, NULL, '', 'string'),
(6, 'en_US', 'biography', NULL, NULL, '', 'string'),
(6, 'ru_RU', 'signature', NULL, NULL, '', 'string'),
(6, 'en_US', 'signature', NULL, NULL, '', 'string'),
(6, 'ru_RU', 'affiliation', NULL, NULL, '', 'string'),
(6, 'en_US', 'affiliation', NULL, NULL, '', 'string'),
(6, 'ru_RU', 'givenName', NULL, NULL, 'Алексей', 'string'),
(6, 'en_US', 'givenName', NULL, NULL, '', 'string'),
(6, 'ru_RU', 'familyName', NULL, NULL, 'Свечкарь', 'string'),
(6, 'en_US', 'familyName', NULL, NULL, '', 'string'),
(6, 'ru_RU', 'preferredPublicName', NULL, NULL, '', 'string'),
(6, 'en_US', 'preferredPublicName', NULL, NULL, '', 'string'),
(6, '', 'orcid', NULL, NULL, '', 'string'),
(4, 'en_US', 'biography', NULL, NULL, '', 'string'),
(4, 'en_US', 'signature', NULL, NULL, '', 'string'),
(4, 'en_US', 'affiliation', NULL, NULL, '', 'string'),
(4, 'en_US', 'givenName', NULL, NULL, '', 'string'),
(4, 'en_US', 'familyName', NULL, NULL, '', 'string'),
(4, 'en_US', 'preferredPublicName', NULL, NULL, '', 'string'),
(4, 'en_US', 'biography', 0, 0, '', 'string'),
(4, 'ru_RU', 'biography', 0, 0, '', 'string'),
(4, 'en_US', 'signature', 0, 0, '', 'string'),
(4, 'ru_RU', 'signature', 0, 0, '', 'string'),
(4, 'en_US', 'affiliation', 0, 0, '', 'string'),
(4, 'ru_RU', 'affiliation', 0, 0, '', 'string'),
(4, 'en_US', 'givenName', 0, 0, '', 'string'),
(4, 'ru_RU', 'givenName', 0, 0, 'Наталья', 'string'),
(4, 'en_US', 'familyName', 0, 0, '', 'string'),
(4, 'ru_RU', 'familyName', 0, 0, 'Моллекер', 'string'),
(4, 'en_US', 'preferredPublicName', 0, 0, '', 'string'),
(4, 'ru_RU', 'preferredPublicName', 0, 0, '', 'string'),
(4, '', 'orcid', 0, 0, '', 'string'),
(1, 'en_US', 'biography', 0, 0, '', 'string'),
(1, 'ru_RU', 'biography', 0, 0, '', 'string'),
(1, 'en_US', 'signature', 0, 0, '', 'string'),
(1, 'ru_RU', 'signature', 0, 0, '', 'string'),
(1, 'en_US', 'affiliation', 0, 0, '', 'string'),
(1, 'ru_RU', 'affiliation', 0, 0, '', 'string'),
(1, 'en_US', 'givenName', 0, 0, 'Vladimir', 'string'),
(1, 'ru_RU', 'givenName', 0, 0, 'Владимир', 'string'),
(1, 'en_US', 'familyName', 0, 0, 'Lukin', 'string'),
(1, 'ru_RU', 'familyName', 0, 0, 'Лукин', 'string'),
(1, 'en_US', 'preferredPublicName', 0, 0, '', 'string'),
(1, 'ru_RU', 'preferredPublicName', 0, 0, '', 'string'),
(1, '', 'orcid', 0, 0, '', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `user_user_groups`
--

CREATE TABLE `user_user_groups` (
  `user_group_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_user_groups`
--

INSERT INTO `user_user_groups` (`user_group_id`, `user_id`) VALUES
(1, 1),
(1, 4),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 1),
(8, 2),
(9, 1),
(9, 2),
(10, 1),
(10, 2),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(17, 2),
(18, 1),
(18, 2),
(19, 1),
(19, 3),
(19, 4),
(19, 5),
(19, 6),
(20, 3),
(20, 4),
(20, 5),
(20, 6),
(21, 4),
(21, 5),
(21, 6),
(22, 4),
(22, 5),
(22, 6),
(23, 3),
(23, 4),
(23, 5),
(23, 6),
(24, 3),
(24, 4),
(24, 5),
(24, 6),
(25, 4),
(25, 5),
(25, 6),
(26, 4),
(26, 5),
(26, 6),
(27, 4),
(27, 5),
(27, 6),
(28, 4),
(28, 5),
(28, 6),
(29, 4),
(29, 5),
(29, 6),
(30, 3),
(30, 4),
(30, 5),
(30, 6),
(31, 3),
(31, 4),
(31, 5),
(31, 6),
(32, 4),
(32, 5),
(32, 6),
(33, 3),
(33, 4),
(33, 5),
(33, 6),
(34, 4),
(34, 5),
(34, 6),
(35, 4),
(35, 5),
(35, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `versions`
--

CREATE TABLE `versions` (
  `major` int(11) NOT NULL DEFAULT '0',
  `minor` int(11) NOT NULL DEFAULT '0',
  `revision` int(11) NOT NULL DEFAULT '0',
  `build` int(11) NOT NULL DEFAULT '0',
  `date_installed` datetime NOT NULL,
  `current` tinyint(4) NOT NULL DEFAULT '0',
  `product_type` varchar(30) DEFAULT NULL,
  `product` varchar(30) DEFAULT NULL,
  `product_class_name` varchar(80) DEFAULT NULL,
  `lazy_load` tinyint(4) NOT NULL DEFAULT '0',
  `sitewide` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `versions`
--

INSERT INTO `versions` (`major`, `minor`, `revision`, `build`, `date_installed`, `current`, `product_type`, `product`, `product_class_name`, `lazy_load`, `sitewide`) VALUES
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.metadata', 'mods34', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.metadata', 'dc11', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.metadata', 'openurl10', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.blocks', 'information', 'InformationBlockPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.blocks', 'makeSubmission', 'MakeSubmissionBlockPlugin', 1, 0),
(1, 1, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.blocks', 'subscription', 'SubscriptionBlockPlugin', 1, 0),
(1, 0, 1, 0, '2020-04-20 18:43:49', 1, 'plugins.blocks', 'browse', 'BrowseBlockPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.blocks', 'developedBy', 'DevelopedByBlockPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.blocks', 'languageToggle', 'LanguageToggleBlockPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.gateways', 'resolver', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'driver', 'DRIVERPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'usageEvent', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 0, 'plugins.generic', 'lensGalley', 'LensGalleyPlugin', 1, 0),
(1, 0, 1, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'pdfJsViewer', 'PdfJsViewerPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'recommendBySimilarity', 'RecommendBySimilarityPlugin', 1, 1),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'recommendByAuthor', 'RecommendByAuthorPlugin', 1, 1),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'announcementFeed', 'AnnouncementFeedPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'webFeed', 'WebFeedPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'dublinCoreMeta', 'DublinCoreMetaPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'googleAnalytics', 'GoogleAnalyticsPlugin', 1, 0),
(1, 2, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'staticPages', 'StaticPagesPlugin', 1, 0),
(1, 1, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'googleScholar', 'GoogleScholarPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'usageStats', 'UsageStatsPlugin', 0, 1),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'htmlArticleGalley', 'HtmlArticleGalleyPlugin', 1, 0),
(1, 1, 2, 1, '2020-04-20 18:43:49', 0, 'plugins.generic', 'orcidProfile', 'OrcidProfilePlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'tinymce', 'TinyMCEPlugin', 1, 0),
(1, 2, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'acron', 'AcronPlugin', 1, 1),
(1, 2, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'customBlockManager', 'CustomBlockManagerPlugin', 1, 0),
(0, 1, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.generic', 'citationStyleLanguage', 'CitationStyleLanguagePlugin', 1, 0),
(2, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.importexport', 'datacite', '', 0, 0),
(1, 1, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.importexport', 'doaj', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.importexport', 'native', '', 0, 0),
(2, 1, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.importexport', 'crossref', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.importexport', 'users', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.importexport', 'pubmed', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.oaiMetadataFormats', 'marc', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.oaiMetadataFormats', 'marcxml', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.oaiMetadataFormats', 'dc', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.oaiMetadataFormats', 'rfc1807', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.paymethod', 'paypal', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.paymethod', 'manual', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.pubIds', 'urn', 'URNPubIdPlugin', 1, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.pubIds', 'doi', 'DOIPubIdPlugin', 1, 0),
(1, 1, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.reports', 'counterReport', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.reports', 'subscriptions', '', 0, 0),
(2, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.reports', 'reviewReport', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.reports', 'views', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.reports', 'articles', '', 0, 0),
(1, 0, 0, 0, '2020-04-20 18:43:49', 1, 'plugins.themes', 'default', 'DefaultThemePlugin', 1, 0),
(3, 2, 0, 2, '2020-04-20 18:43:19', 0, 'core', 'ojs2', '', 0, 1),
(1, 0, 6, 1, '2020-04-20 19:15:15', 0, 'plugins.themes', 'healthSciences', 'HealthSciencesThemePlugin', 1, 0),
(1, 1, 2, 3, '2020-08-31 12:19:04', 0, 'plugins.generic', 'orcidProfile', 'OrcidProfilePlugin', 1, 0),
(1, 0, 7, 0, '2020-08-31 12:19:39', 1, 'plugins.themes', 'healthSciences', 'HealthSciencesThemePlugin', 1, 0),
(1, 0, 0, 0, '2021-02-08 01:06:44', 1, 'plugins.auth', 'ldap', '', 0, 0),
(1, 0, 1, 0, '2021-05-06 23:14:38', 1, 'plugins.generic', 'lensGalley', 'LensGalleyPlugin', 1, 0),
(1, 1, 2, 14, '2021-05-06 23:14:38', 1, 'plugins.generic', 'orcidProfile', 'OrcidProfilePlugin', 1, 0),
(3, 3, 0, 6, '2021-05-06 23:14:21', 1, 'core', 'ojs2', '', 0, 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `access_keys`
--
ALTER TABLE `access_keys`
  ADD PRIMARY KEY (`access_key_id`),
  ADD KEY `access_keys_hash` (`key_hash`,`user_id`,`context`);

--
-- Индексы таблицы `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`),
  ADD KEY `announcements_assoc` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `announcement_settings`
--
ALTER TABLE `announcement_settings`
  ADD UNIQUE KEY `announcement_settings_pkey` (`announcement_id`,`locale`,`setting_name`),
  ADD KEY `announcement_settings_announcement_id` (`announcement_id`);

--
-- Индексы таблицы `announcement_types`
--
ALTER TABLE `announcement_types`
  ADD PRIMARY KEY (`type_id`),
  ADD KEY `announcement_types_assoc` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `announcement_type_settings`
--
ALTER TABLE `announcement_type_settings`
  ADD UNIQUE KEY `announcement_type_settings_pkey` (`type_id`,`locale`,`setting_name`),
  ADD KEY `announcement_type_settings_type_id` (`type_id`);

--
-- Индексы таблицы `antiplagiat_reports`
--
ALTER TABLE `antiplagiat_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `antiplagiat_reports_status_id_index` (`status_id`);

--
-- Индексы таблицы `antiplagiat_report_blocks`
--
ALTER TABLE `antiplagiat_report_blocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ariid` (`antiplagiat_report_id`);

--
-- Индексы таблицы `antiplagiat_report_services`
--
ALTER TABLE `antiplagiat_report_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `arid` (`antiplagiat_report_id`);

--
-- Индексы таблицы `antiplagiat_report_service_sources`
--
ALTER TABLE `antiplagiat_report_service_sources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `arsid` (`antiplagiat_report_service_id`);

--
-- Индексы таблицы `antiplagiat_report_statuses`
--
ALTER TABLE `antiplagiat_report_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`author_id`),
  ADD KEY `authors_publication_id` (`publication_id`);

--
-- Индексы таблицы `author_settings`
--
ALTER TABLE `author_settings`
  ADD UNIQUE KEY `author_settings_pkey` (`author_id`,`locale`,`setting_name`),
  ADD KEY `author_settings_author_id` (`author_id`);

--
-- Индексы таблицы `auth_sources`
--
ALTER TABLE `auth_sources`
  ADD PRIMARY KEY (`auth_id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_path` (`context_id`,`path`),
  ADD KEY `category_context_id` (`context_id`,`parent_id`);

--
-- Индексы таблицы `category_settings`
--
ALTER TABLE `category_settings`
  ADD UNIQUE KEY `category_settings_pkey` (`category_id`,`locale`,`setting_name`);

--
-- Индексы таблицы `citations`
--
ALTER TABLE `citations`
  ADD PRIMARY KEY (`citation_id`),
  ADD UNIQUE KEY `citations_publication_seq` (`publication_id`,`seq`),
  ADD KEY `citations_publication` (`publication_id`);

--
-- Индексы таблицы `citation_settings`
--
ALTER TABLE `citation_settings`
  ADD UNIQUE KEY `citation_settings_pkey` (`citation_id`,`locale`,`setting_name`),
  ADD KEY `citation_settings_citation_id` (`citation_id`);

--
-- Индексы таблицы `completed_payments`
--
ALTER TABLE `completed_payments`
  ADD PRIMARY KEY (`completed_payment_id`);

--
-- Индексы таблицы `controlled_vocabs`
--
ALTER TABLE `controlled_vocabs`
  ADD PRIMARY KEY (`controlled_vocab_id`),
  ADD UNIQUE KEY `controlled_vocab_symbolic` (`symbolic`,`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `controlled_vocab_entries`
--
ALTER TABLE `controlled_vocab_entries`
  ADD PRIMARY KEY (`controlled_vocab_entry_id`),
  ADD KEY `controlled_vocab_entries_cv_id` (`controlled_vocab_id`,`seq`);

--
-- Индексы таблицы `controlled_vocab_entry_settings`
--
ALTER TABLE `controlled_vocab_entry_settings`
  ADD UNIQUE KEY `c_v_e_s_pkey` (`controlled_vocab_entry_id`,`locale`,`setting_name`),
  ADD KEY `c_v_e_s_entry_id` (`controlled_vocab_entry_id`);

--
-- Индексы таблицы `custom_issue_orders`
--
ALTER TABLE `custom_issue_orders`
  ADD UNIQUE KEY `custom_issue_orders_pkey` (`issue_id`);

--
-- Индексы таблицы `custom_section_orders`
--
ALTER TABLE `custom_section_orders`
  ADD UNIQUE KEY `custom_section_orders_pkey` (`issue_id`,`section_id`);

--
-- Индексы таблицы `data_object_tombstones`
--
ALTER TABLE `data_object_tombstones`
  ADD PRIMARY KEY (`tombstone_id`),
  ADD KEY `data_object_tombstones_data_object_id` (`data_object_id`);

--
-- Индексы таблицы `data_object_tombstone_oai_set_objects`
--
ALTER TABLE `data_object_tombstone_oai_set_objects`
  ADD PRIMARY KEY (`object_id`),
  ADD KEY `data_object_tombstone_oai_set_objects_tombstone_id` (`tombstone_id`);

--
-- Индексы таблицы `data_object_tombstone_settings`
--
ALTER TABLE `data_object_tombstone_settings`
  ADD UNIQUE KEY `data_object_tombstone_settings_pkey` (`tombstone_id`,`locale`,`setting_name`),
  ADD KEY `data_object_tombstone_settings_tombstone_id` (`tombstone_id`);

--
-- Индексы таблицы `edit_decisions`
--
ALTER TABLE `edit_decisions`
  ADD PRIMARY KEY (`edit_decision_id`),
  ADD KEY `edit_decisions_submission_id` (`submission_id`),
  ADD KEY `edit_decisions_editor_id` (`editor_id`);

--
-- Индексы таблицы `email_log`
--
ALTER TABLE `email_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `email_log_assoc` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `email_log_users`
--
ALTER TABLE `email_log_users`
  ADD UNIQUE KEY `email_log_user_id` (`email_log_id`,`user_id`);

--
-- Индексы таблицы `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`email_id`),
  ADD UNIQUE KEY `email_templates_email_key` (`email_key`,`context_id`);

--
-- Индексы таблицы `email_templates_default`
--
ALTER TABLE `email_templates_default`
  ADD PRIMARY KEY (`email_id`),
  ADD KEY `email_templates_default_email_key` (`email_key`);

--
-- Индексы таблицы `email_templates_default_data`
--
ALTER TABLE `email_templates_default_data`
  ADD UNIQUE KEY `email_templates_default_data_pkey` (`email_key`,`locale`);

--
-- Индексы таблицы `email_templates_settings`
--
ALTER TABLE `email_templates_settings`
  ADD UNIQUE KEY `email_settings_pkey` (`email_id`,`locale`,`setting_name`),
  ADD KEY `email_settings_email_id` (`email_id`);

--
-- Индексы таблицы `event_log`
--
ALTER TABLE `event_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `event_log_assoc` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `event_log_settings`
--
ALTER TABLE `event_log_settings`
  ADD UNIQUE KEY `event_log_settings_pkey` (`log_id`,`setting_name`),
  ADD KEY `event_log_settings_log_id` (`log_id`),
  ADD KEY `event_log_settings_name_value` (`setting_name`(50),`setting_value`(150));

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`);

--
-- Индексы таблицы `filters`
--
ALTER TABLE `filters`
  ADD PRIMARY KEY (`filter_id`);

--
-- Индексы таблицы `filter_groups`
--
ALTER TABLE `filter_groups`
  ADD PRIMARY KEY (`filter_group_id`),
  ADD UNIQUE KEY `filter_groups_symbolic` (`symbolic`);

--
-- Индексы таблицы `filter_settings`
--
ALTER TABLE `filter_settings`
  ADD UNIQUE KEY `filter_settings_pkey` (`filter_id`,`locale`,`setting_name`),
  ADD KEY `filter_settings_id` (`filter_id`);

--
-- Индексы таблицы `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`genre_id`);

--
-- Индексы таблицы `genre_settings`
--
ALTER TABLE `genre_settings`
  ADD UNIQUE KEY `genre_settings_pkey` (`genre_id`,`locale`,`setting_name`),
  ADD KEY `genre_settings_genre_id` (`genre_id`);

--
-- Индексы таблицы `institutional_subscriptions`
--
ALTER TABLE `institutional_subscriptions`
  ADD PRIMARY KEY (`institutional_subscription_id`),
  ADD KEY `institutional_subscriptions_subscription_id` (`subscription_id`),
  ADD KEY `institutional_subscriptions_domain` (`domain`);

--
-- Индексы таблицы `institutional_subscription_ip`
--
ALTER TABLE `institutional_subscription_ip`
  ADD PRIMARY KEY (`institutional_subscription_ip_id`),
  ADD KEY `institutional_subscription_ip_subscription_id` (`subscription_id`),
  ADD KEY `institutional_subscription_ip_start` (`ip_start`),
  ADD KEY `institutional_subscription_ip_end` (`ip_end`);

--
-- Индексы таблицы `issues`
--
ALTER TABLE `issues`
  ADD PRIMARY KEY (`issue_id`),
  ADD KEY `issues_journal_id` (`journal_id`),
  ADD KEY `issues_url_path` (`url_path`);

--
-- Индексы таблицы `issue_files`
--
ALTER TABLE `issue_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `issue_files_issue_id` (`issue_id`);

--
-- Индексы таблицы `issue_galleys`
--
ALTER TABLE `issue_galleys`
  ADD PRIMARY KEY (`galley_id`),
  ADD KEY `issue_galleys_issue_id` (`issue_id`),
  ADD KEY `issue_galleys_url_path` (`url_path`);

--
-- Индексы таблицы `issue_galley_settings`
--
ALTER TABLE `issue_galley_settings`
  ADD UNIQUE KEY `issue_galley_settings_pkey` (`galley_id`,`locale`,`setting_name`),
  ADD KEY `issue_galley_settings_galley_id` (`galley_id`);

--
-- Индексы таблицы `issue_settings`
--
ALTER TABLE `issue_settings`
  ADD UNIQUE KEY `issue_settings_pkey` (`issue_id`,`locale`,`setting_name`),
  ADD KEY `issue_settings_issue_id` (`issue_id`),
  ADD KEY `issue_settings_name_value` (`setting_name`(50),`setting_value`(150));

--
-- Индексы таблицы `item_views`
--
ALTER TABLE `item_views`
  ADD UNIQUE KEY `item_views_pkey` (`assoc_type`,`assoc_id`,`user_id`);

--
-- Индексы таблицы `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`);

--
-- Индексы таблицы `journals`
--
ALTER TABLE `journals`
  ADD PRIMARY KEY (`journal_id`),
  ADD UNIQUE KEY `journals_path` (`path`);

--
-- Индексы таблицы `journal_settings`
--
ALTER TABLE `journal_settings`
  ADD UNIQUE KEY `journal_settings_pkey` (`journal_id`,`locale`,`setting_name`),
  ADD KEY `journal_settings_journal_id` (`journal_id`);

--
-- Индексы таблицы `library_files`
--
ALTER TABLE `library_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `library_files_submission_id` (`submission_id`);

--
-- Индексы таблицы `library_file_settings`
--
ALTER TABLE `library_file_settings`
  ADD UNIQUE KEY `library_file_settings_pkey` (`file_id`,`locale`,`setting_name`),
  ADD KEY `library_file_settings_id` (`file_id`);

--
-- Индексы таблицы `metadata_descriptions`
--
ALTER TABLE `metadata_descriptions`
  ADD PRIMARY KEY (`metadata_description_id`),
  ADD KEY `metadata_descriptions_assoc` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `metadata_description_settings`
--
ALTER TABLE `metadata_description_settings`
  ADD UNIQUE KEY `metadata_descripton_settings_pkey` (`metadata_description_id`,`locale`,`setting_name`),
  ADD KEY `metadata_description_settings_id` (`metadata_description_id`);

--
-- Индексы таблицы `metrics`
--
ALTER TABLE `metrics`
  ADD KEY `metrics_load_id` (`load_id`),
  ADD KEY `metrics_metric_type_context_id` (`metric_type`,`context_id`),
  ADD KEY `metrics_metric_type_submission_id_assoc_type` (`metric_type`,`submission_id`,`assoc_type`),
  ADD KEY `metrics_metric_type_submission_id_assoc` (`metric_type`,`context_id`,`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `navigation_menus`
--
ALTER TABLE `navigation_menus`
  ADD PRIMARY KEY (`navigation_menu_id`);

--
-- Индексы таблицы `navigation_menu_items`
--
ALTER TABLE `navigation_menu_items`
  ADD PRIMARY KEY (`navigation_menu_item_id`);

--
-- Индексы таблицы `navigation_menu_item_assignments`
--
ALTER TABLE `navigation_menu_item_assignments`
  ADD PRIMARY KEY (`navigation_menu_item_assignment_id`);

--
-- Индексы таблицы `navigation_menu_item_assignment_settings`
--
ALTER TABLE `navigation_menu_item_assignment_settings`
  ADD UNIQUE KEY `navigation_menu_item_assignment_settings_pkey` (`navigation_menu_item_assignment_id`,`locale`,`setting_name`),
  ADD KEY `assignment_settings_navigation_menu_item_assignment_id` (`navigation_menu_item_assignment_id`);

--
-- Индексы таблицы `navigation_menu_item_settings`
--
ALTER TABLE `navigation_menu_item_settings`
  ADD UNIQUE KEY `navigation_menu_item_settings_pkey` (`navigation_menu_item_id`,`locale`,`setting_name`),
  ADD KEY `navigation_menu_item_settings_navigation_menu_id` (`navigation_menu_item_id`);

--
-- Индексы таблицы `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`note_id`),
  ADD KEY `notes_assoc` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `notifications_context_id_user_id` (`context_id`,`user_id`,`level`),
  ADD KEY `notifications_context_id` (`context_id`,`level`),
  ADD KEY `notifications_assoc` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `notification_mail_list`
--
ALTER TABLE `notification_mail_list`
  ADD PRIMARY KEY (`notification_mail_list_id`),
  ADD UNIQUE KEY `notification_mail_list_email_context` (`email`,`context`);

--
-- Индексы таблицы `notification_settings`
--
ALTER TABLE `notification_settings`
  ADD UNIQUE KEY `notification_settings_pkey` (`notification_id`,`locale`,`setting_name`);

--
-- Индексы таблицы `notification_subscription_settings`
--
ALTER TABLE `notification_subscription_settings`
  ADD PRIMARY KEY (`setting_id`);

--
-- Индексы таблицы `oai_resumption_tokens`
--
ALTER TABLE `oai_resumption_tokens`
  ADD UNIQUE KEY `oai_resumption_tokens_pkey` (`token`);

--
-- Индексы таблицы `plugin_settings`
--
ALTER TABLE `plugin_settings`
  ADD UNIQUE KEY `plugin_settings_pkey` (`plugin_name`,`context_id`,`setting_name`),
  ADD KEY `plugin_settings_plugin_name` (`plugin_name`);

--
-- Индексы таблицы `publications`
--
ALTER TABLE `publications`
  ADD PRIMARY KEY (`publication_id`),
  ADD KEY `publications_submission_id` (`submission_id`),
  ADD KEY `publications_section_id` (`section_id`),
  ADD KEY `publications_url_path` (`url_path`);

--
-- Индексы таблицы `publication_categories`
--
ALTER TABLE `publication_categories`
  ADD UNIQUE KEY `publication_categories_id` (`publication_id`,`category_id`);

--
-- Индексы таблицы `publication_galleys`
--
ALTER TABLE `publication_galleys`
  ADD PRIMARY KEY (`galley_id`),
  ADD KEY `publication_galleys_publication_id` (`publication_id`),
  ADD KEY `publication_galleys_url_path` (`url_path`),
  ADD KEY `publication_galleys_submission_file_id_foreign` (`submission_file_id`);

--
-- Индексы таблицы `publication_galley_settings`
--
ALTER TABLE `publication_galley_settings`
  ADD UNIQUE KEY `publication_galley_settings_pkey` (`galley_id`,`locale`,`setting_name`),
  ADD KEY `publication_galley_settings_galley_id` (`galley_id`),
  ADD KEY `publication_galley_settings_name_value` (`setting_name`(50),`setting_value`(150));

--
-- Индексы таблицы `publication_settings`
--
ALTER TABLE `publication_settings`
  ADD UNIQUE KEY `publication_settings_pkey` (`publication_id`,`locale`,`setting_name`),
  ADD KEY `publication_settings_publication_id` (`publication_id`),
  ADD KEY `publication_settings_name_value` (`setting_name`(50),`setting_value`(150));

--
-- Индексы таблицы `queries`
--
ALTER TABLE `queries`
  ADD PRIMARY KEY (`query_id`),
  ADD KEY `queries_assoc_id` (`assoc_type`,`assoc_id`);

--
-- Индексы таблицы `query_participants`
--
ALTER TABLE `query_participants`
  ADD UNIQUE KEY `query_participants_pkey` (`query_id`,`user_id`);

--
-- Индексы таблицы `queued_payments`
--
ALTER TABLE `queued_payments`
  ADD PRIMARY KEY (`queued_payment_id`);

--
-- Индексы таблицы `review_assignments`
--
ALTER TABLE `review_assignments`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `review_assignments_submission_id` (`submission_id`),
  ADD KEY `review_assignments_reviewer_id` (`reviewer_id`),
  ADD KEY `review_assignments_form_id` (`review_form_id`),
  ADD KEY `review_assignments_reviewer_review` (`reviewer_id`,`review_id`);

--
-- Индексы таблицы `review_files`
--
ALTER TABLE `review_files`
  ADD UNIQUE KEY `review_files_pkey` (`review_id`,`submission_file_id`),
  ADD KEY `review_files_review_id` (`review_id`),
  ADD KEY `review_files_submission_file_id_foreign` (`submission_file_id`);

--
-- Индексы таблицы `review_forms`
--
ALTER TABLE `review_forms`
  ADD PRIMARY KEY (`review_form_id`);

--
-- Индексы таблицы `review_form_elements`
--
ALTER TABLE `review_form_elements`
  ADD PRIMARY KEY (`review_form_element_id`),
  ADD KEY `review_form_elements_review_form_id` (`review_form_id`);

--
-- Индексы таблицы `review_form_element_settings`
--
ALTER TABLE `review_form_element_settings`
  ADD UNIQUE KEY `review_form_element_settings_pkey` (`review_form_element_id`,`locale`,`setting_name`),
  ADD KEY `review_form_element_settings_review_form_element_id` (`review_form_element_id`);

--
-- Индексы таблицы `review_form_responses`
--
ALTER TABLE `review_form_responses`
  ADD KEY `review_form_responses_pkey` (`review_form_element_id`,`review_id`);

--
-- Индексы таблицы `review_form_settings`
--
ALTER TABLE `review_form_settings`
  ADD UNIQUE KEY `review_form_settings_pkey` (`review_form_id`,`locale`,`setting_name`),
  ADD KEY `review_form_settings_review_form_id` (`review_form_id`);

--
-- Индексы таблицы `review_rounds`
--
ALTER TABLE `review_rounds`
  ADD PRIMARY KEY (`review_round_id`),
  ADD UNIQUE KEY `review_rounds_submission_id_stage_id_round_pkey` (`submission_id`,`stage_id`,`round`),
  ADD KEY `review_rounds_submission_id` (`submission_id`);

--
-- Индексы таблицы `review_round_files`
--
ALTER TABLE `review_round_files`
  ADD UNIQUE KEY `review_round_files_pkey` (`submission_id`,`review_round_id`,`submission_file_id`),
  ADD UNIQUE KEY `review_round_files_submission_file_id_unique` (`submission_file_id`),
  ADD KEY `review_round_files_submission_id` (`submission_id`);

--
-- Индексы таблицы `scheduled_tasks`
--
ALTER TABLE `scheduled_tasks`
  ADD UNIQUE KEY `scheduled_tasks_pkey` (`class_name`);

--
-- Индексы таблицы `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `sections_journal_id` (`journal_id`);

--
-- Индексы таблицы `section_settings`
--
ALTER TABLE `section_settings`
  ADD UNIQUE KEY `section_settings_pkey` (`section_id`,`locale`,`setting_name`),
  ADD KEY `section_settings_section_id` (`section_id`);

--
-- Индексы таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_pkey` (`session_id`),
  ADD KEY `sessions_user_id` (`user_id`);

--
-- Индексы таблицы `site_settings`
--
ALTER TABLE `site_settings`
  ADD UNIQUE KEY `site_settings_pkey` (`setting_name`,`locale`);

--
-- Индексы таблицы `stage_assignments`
--
ALTER TABLE `stage_assignments`
  ADD PRIMARY KEY (`stage_assignment_id`),
  ADD UNIQUE KEY `stage_assignment` (`submission_id`,`user_group_id`,`user_id`),
  ADD KEY `stage_assignments_submission_id` (`submission_id`),
  ADD KEY `stage_assignments_user_group_id` (`user_group_id`),
  ADD KEY `stage_assignments_user_id` (`user_id`);

--
-- Индексы таблицы `static_pages`
--
ALTER TABLE `static_pages`
  ADD PRIMARY KEY (`static_page_id`);

--
-- Индексы таблицы `static_page_settings`
--
ALTER TABLE `static_page_settings`
  ADD UNIQUE KEY `static_page_settings_pkey` (`static_page_id`,`locale`,`setting_name`),
  ADD KEY `static_page_settings_static_page_id` (`static_page_id`);

--
-- Индексы таблицы `subeditor_submission_group`
--
ALTER TABLE `subeditor_submission_group`
  ADD UNIQUE KEY `section_editors_pkey` (`context_id`,`assoc_id`,`assoc_type`,`user_id`),
  ADD KEY `section_editors_context_id` (`context_id`),
  ADD KEY `subeditor_submission_group_assoc_id` (`assoc_id`,`assoc_type`),
  ADD KEY `subeditor_submission_group_user_id` (`user_id`);

--
-- Индексы таблицы `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`submission_id`),
  ADD KEY `submissions_context_id` (`context_id`),
  ADD KEY `submissions_publication_id` (`submission_id`);

--
-- Индексы таблицы `submission_artwork_files`
--
ALTER TABLE `submission_artwork_files`
  ADD PRIMARY KEY (`file_id`,`revision`);

--
-- Индексы таблицы `submission_comments`
--
ALTER TABLE `submission_comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `submission_comments_submission_id` (`submission_id`);

--
-- Индексы таблицы `submission_files`
--
ALTER TABLE `submission_files`
  ADD PRIMARY KEY (`submission_file_id`),
  ADD KEY `submission_files_submission_id` (`submission_id`),
  ADD KEY `submission_files_stage_assoc` (`file_stage`,`assoc_type`,`assoc_id`),
  ADD KEY `submission_files_file_id_foreign` (`file_id`);

--
-- Индексы таблицы `submission_file_logs`
--
ALTER TABLE `submission_file_logs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `submission_file_revisions`
--
ALTER TABLE `submission_file_revisions`
  ADD PRIMARY KEY (`revision_id`),
  ADD KEY `submission_file_revisions_submission_file_id_foreign` (`submission_file_id`),
  ADD KEY `submission_file_revisions_file_id_foreign` (`file_id`);

--
-- Индексы таблицы `submission_file_settings`
--
ALTER TABLE `submission_file_settings`
  ADD UNIQUE KEY `submission_file_settings_pkey` (`submission_file_id`,`locale`,`setting_name`),
  ADD KEY `submission_file_settings_id` (`submission_file_id`);

--
-- Индексы таблицы `submission_search_keyword_list`
--
ALTER TABLE `submission_search_keyword_list`
  ADD PRIMARY KEY (`keyword_id`),
  ADD UNIQUE KEY `submission_search_keyword_text` (`keyword_text`);

--
-- Индексы таблицы `submission_search_objects`
--
ALTER TABLE `submission_search_objects`
  ADD PRIMARY KEY (`object_id`),
  ADD KEY `submission_search_object_submission` (`submission_id`);

--
-- Индексы таблицы `submission_search_object_keywords`
--
ALTER TABLE `submission_search_object_keywords`
  ADD UNIQUE KEY `submission_search_object_keywords_pkey` (`object_id`,`pos`),
  ADD KEY `submission_search_object_keywords_keyword_id` (`keyword_id`);

--
-- Индексы таблицы `submission_settings`
--
ALTER TABLE `submission_settings`
  ADD UNIQUE KEY `submission_settings_pkey` (`submission_id`,`locale`,`setting_name`),
  ADD KEY `submission_settings_submission_id` (`submission_id`);

--
-- Индексы таблицы `submission_supplementary_files`
--
ALTER TABLE `submission_supplementary_files`
  ADD PRIMARY KEY (`file_id`,`revision`);

--
-- Индексы таблицы `submission_tombstones`
--
ALTER TABLE `submission_tombstones`
  ADD PRIMARY KEY (`tombstone_id`),
  ADD KEY `submission_tombstones_journal_id` (`journal_id`),
  ADD KEY `submission_tombstones_submission_id` (`submission_id`);

--
-- Индексы таблицы `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`subscription_id`);

--
-- Индексы таблицы `subscription_types`
--
ALTER TABLE `subscription_types`
  ADD PRIMARY KEY (`type_id`);

--
-- Индексы таблицы `subscription_type_settings`
--
ALTER TABLE `subscription_type_settings`
  ADD UNIQUE KEY `subscription_type_settings_pkey` (`type_id`,`locale`,`setting_name`),
  ADD KEY `subscription_type_settings_type_id` (`type_id`);

--
-- Индексы таблицы `temporary_files`
--
ALTER TABLE `temporary_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `temporary_files_user_id` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `users_username` (`username`),
  ADD UNIQUE KEY `users_email` (`email`),
  ADD UNIQUE KEY `users_api_token_unique` (`api_token`);

--
-- Индексы таблицы `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`user_group_id`),
  ADD KEY `user_groups_user_group_id` (`user_group_id`),
  ADD KEY `user_groups_context_id` (`context_id`),
  ADD KEY `user_groups_role_id` (`role_id`);

--
-- Индексы таблицы `user_group_settings`
--
ALTER TABLE `user_group_settings`
  ADD UNIQUE KEY `user_group_settings_pkey` (`user_group_id`,`locale`,`setting_name`);

--
-- Индексы таблицы `user_group_stage`
--
ALTER TABLE `user_group_stage`
  ADD UNIQUE KEY `user_group_stage_pkey` (`context_id`,`user_group_id`,`stage_id`),
  ADD KEY `user_group_stage_context_id` (`context_id`),
  ADD KEY `user_group_stage_user_group_id` (`user_group_id`),
  ADD KEY `user_group_stage_stage_id` (`stage_id`);

--
-- Индексы таблицы `user_interests`
--
ALTER TABLE `user_interests`
  ADD UNIQUE KEY `u_e_pkey` (`user_id`,`controlled_vocab_entry_id`);

--
-- Индексы таблицы `user_settings`
--
ALTER TABLE `user_settings`
  ADD UNIQUE KEY `user_settings_pkey` (`user_id`,`locale`,`setting_name`,`assoc_type`,`assoc_id`),
  ADD KEY `user_settings_user_id` (`user_id`);

--
-- Индексы таблицы `user_user_groups`
--
ALTER TABLE `user_user_groups`
  ADD UNIQUE KEY `user_user_groups_pkey` (`user_group_id`,`user_id`),
  ADD KEY `user_user_groups_user_group_id` (`user_group_id`),
  ADD KEY `user_user_groups_user_id` (`user_id`);

--
-- Индексы таблицы `versions`
--
ALTER TABLE `versions`
  ADD UNIQUE KEY `versions_pkey` (`product_type`,`product`,`major`,`minor`,`revision`,`build`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `access_keys`
--
ALTER TABLE `access_keys`
  MODIFY `access_key_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `announcement_types`
--
ALTER TABLE `announcement_types`
  MODIFY `type_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `antiplagiat_reports`
--
ALTER TABLE `antiplagiat_reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `antiplagiat_report_blocks`
--
ALTER TABLE `antiplagiat_report_blocks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `antiplagiat_report_services`
--
ALTER TABLE `antiplagiat_report_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `antiplagiat_report_service_sources`
--
ALTER TABLE `antiplagiat_report_service_sources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `antiplagiat_report_statuses`
--
ALTER TABLE `antiplagiat_report_statuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `authors`
--
ALTER TABLE `authors`
  MODIFY `author_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `auth_sources`
--
ALTER TABLE `auth_sources`
  MODIFY `auth_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `citations`
--
ALTER TABLE `citations`
  MODIFY `citation_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `completed_payments`
--
ALTER TABLE `completed_payments`
  MODIFY `completed_payment_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `controlled_vocabs`
--
ALTER TABLE `controlled_vocabs`
  MODIFY `controlled_vocab_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9981;

--
-- AUTO_INCREMENT для таблицы `controlled_vocab_entries`
--
ALTER TABLE `controlled_vocab_entries`
  MODIFY `controlled_vocab_entry_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT для таблицы `data_object_tombstones`
--
ALTER TABLE `data_object_tombstones`
  MODIFY `tombstone_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `data_object_tombstone_oai_set_objects`
--
ALTER TABLE `data_object_tombstone_oai_set_objects`
  MODIFY `object_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `edit_decisions`
--
ALTER TABLE `edit_decisions`
  MODIFY `edit_decision_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `email_log`
--
ALTER TABLE `email_log`
  MODIFY `log_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `email_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `email_templates_default`
--
ALTER TABLE `email_templates_default`
  MODIFY `email_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT для таблицы `event_log`
--
ALTER TABLE `event_log`
  MODIFY `log_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `files`
--
ALTER TABLE `files`
  MODIFY `file_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `filters`
--
ALTER TABLE `filters`
  MODIFY `filter_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT для таблицы `filter_groups`
--
ALTER TABLE `filter_groups`
  MODIFY `filter_group_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT для таблицы `genres`
--
ALTER TABLE `genres`
  MODIFY `genre_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `institutional_subscriptions`
--
ALTER TABLE `institutional_subscriptions`
  MODIFY `institutional_subscription_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `institutional_subscription_ip`
--
ALTER TABLE `institutional_subscription_ip`
  MODIFY `institutional_subscription_ip_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `issues`
--
ALTER TABLE `issues`
  MODIFY `issue_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `issue_files`
--
ALTER TABLE `issue_files`
  MODIFY `file_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `issue_galleys`
--
ALTER TABLE `issue_galleys`
  MODIFY `galley_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `journals`
--
ALTER TABLE `journals`
  MODIFY `journal_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `library_files`
--
ALTER TABLE `library_files`
  MODIFY `file_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `metadata_descriptions`
--
ALTER TABLE `metadata_descriptions`
  MODIFY `metadata_description_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `navigation_menus`
--
ALTER TABLE `navigation_menus`
  MODIFY `navigation_menu_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `navigation_menu_items`
--
ALTER TABLE `navigation_menu_items`
  MODIFY `navigation_menu_item_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT для таблицы `navigation_menu_item_assignments`
--
ALTER TABLE `navigation_menu_item_assignments`
  MODIFY `navigation_menu_item_assignment_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `notes`
--
ALTER TABLE `notes`
  MODIFY `note_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT для таблицы `notification_mail_list`
--
ALTER TABLE `notification_mail_list`
  MODIFY `notification_mail_list_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `notification_subscription_settings`
--
ALTER TABLE `notification_subscription_settings`
  MODIFY `setting_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `publications`
--
ALTER TABLE `publications`
  MODIFY `publication_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `publication_galleys`
--
ALTER TABLE `publication_galleys`
  MODIFY `galley_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `queries`
--
ALTER TABLE `queries`
  MODIFY `query_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `queued_payments`
--
ALTER TABLE `queued_payments`
  MODIFY `queued_payment_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `review_assignments`
--
ALTER TABLE `review_assignments`
  MODIFY `review_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `review_forms`
--
ALTER TABLE `review_forms`
  MODIFY `review_form_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `review_form_elements`
--
ALTER TABLE `review_form_elements`
  MODIFY `review_form_element_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `review_rounds`
--
ALTER TABLE `review_rounds`
  MODIFY `review_round_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `sections`
--
ALTER TABLE `sections`
  MODIFY `section_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `stage_assignments`
--
ALTER TABLE `stage_assignments`
  MODIFY `stage_assignment_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `static_pages`
--
ALTER TABLE `static_pages`
  MODIFY `static_page_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `submissions`
--
ALTER TABLE `submissions`
  MODIFY `submission_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `submission_comments`
--
ALTER TABLE `submission_comments`
  MODIFY `comment_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `submission_files`
--
ALTER TABLE `submission_files`
  MODIFY `submission_file_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `submission_file_logs`
--
ALTER TABLE `submission_file_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `submission_file_revisions`
--
ALTER TABLE `submission_file_revisions`
  MODIFY `revision_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `submission_search_keyword_list`
--
ALTER TABLE `submission_search_keyword_list`
  MODIFY `keyword_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `submission_search_objects`
--
ALTER TABLE `submission_search_objects`
  MODIFY `object_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `submission_tombstones`
--
ALTER TABLE `submission_tombstones`
  MODIFY `tombstone_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `subscription_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `subscription_types`
--
ALTER TABLE `subscription_types`
  MODIFY `type_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `temporary_files`
--
ALTER TABLE `temporary_files`
  MODIFY `file_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `user_group_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `publication_galleys`
--
ALTER TABLE `publication_galleys`
  ADD CONSTRAINT `publication_galleys_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`);

--
-- Ограничения внешнего ключа таблицы `review_files`
--
ALTER TABLE `review_files`
  ADD CONSTRAINT `review_files_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`);

--
-- Ограничения внешнего ключа таблицы `review_round_files`
--
ALTER TABLE `review_round_files`
  ADD CONSTRAINT `review_round_files_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`);

--
-- Ограничения внешнего ключа таблицы `submission_files`
--
ALTER TABLE `submission_files`
  ADD CONSTRAINT `submission_files_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`file_id`);

--
-- Ограничения внешнего ключа таблицы `submission_file_revisions`
--
ALTER TABLE `submission_file_revisions`
  ADD CONSTRAINT `submission_file_revisions_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`file_id`),
  ADD CONSTRAINT `submission_file_revisions_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
